import { createContext, useContext, useState, type ReactNode } from "react";

export interface ClientUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  nationality: string;
  idUploaded: boolean;
  avatar: string;
}

interface ClientAuthCtx {
  user: ClientUser | null;
  login: (email: string, password: string) => { ok: boolean; user?: ClientUser; error?: string };
  signup: (name: string, email: string, password: string, phone: string) => { ok: boolean; user?: ClientUser; error?: string };
  logout: () => void;
  updateProfile: (updates: Partial<ClientUser>) => void;
}

const ClientAuthContext = createContext<ClientAuthCtx>({} as ClientAuthCtx);

const DEMO_ACCOUNTS: Array<ClientUser & { password: string }> = [
  {
    id: "CLI-001", name: "Sophia Reeves", email: "s.reeves@email.com", password: "demo123",
    phone: "+1 (305) 555-0192", nationality: "United States", idUploaded: true,
    avatar: "SR",
  },
  {
    id: "CLI-002", name: "Robert Kim", email: "rkim@email.com", password: "demo123",
    phone: "+1 (212) 555-0341", nationality: "South Korea", idUploaded: false,
    avatar: "RK",
  },
  {
    id: "CLI-003", name: "Demo Client", email: "demo@meridian.com", password: "demo123",
    phone: "", nationality: "", idUploaded: false,
    avatar: "DC",
  },
];

export function ClientAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<ClientUser | null>(null);
  const [accounts, setAccounts] = useState(DEMO_ACCOUNTS);

  function login(email: string, password: string): { ok: boolean; user?: ClientUser; error?: string } {
    const found = accounts.find(a => a.email.toLowerCase() === email.toLowerCase() && a.password === password);
    if (!found) return { ok: false, error: "Invalid email or password." };
    const { password: _, ...u } = found;
    setUser(u);
    return { ok: true, user: u };
  }

  function signup(name: string, email: string, password: string, phone: string): { ok: boolean; user?: ClientUser; error?: string } {
    if (accounts.find(a => a.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: "An account with this email already exists." };
    }
    const newUser: ClientUser & { password: string } = {
      id: `CLI-${String(accounts.length + 1).padStart(3, "0")}`,
      name, email, phone, nationality: "", idUploaded: false,
      avatar: name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase(),
      password,
    };
    setAccounts(a => [...a, newUser]);
    const { password: _, ...u } = newUser;
    setUser(u);
    return { ok: true, user: u };
  }

  function logout() { setUser(null); }

  function updateProfile(updates: Partial<ClientUser>) {
    setUser(u => u ? { ...u, ...updates } : u);
  }

  return (
    <ClientAuthContext.Provider value={{ user, login, signup, logout, updateProfile }}>
      {children}
    </ClientAuthContext.Provider>
  );
}

export const useClientAuth = () => useContext(ClientAuthContext);
