import { createContext, useContext, useState, type ReactNode } from "react";
import { BUILDING_UNITS, type Unit, type UnitStatus } from "../data/buildingData";

export type DealStage = "New Inquiry" | "Tour Scheduled" | "Hold Placed" | "Deposit Cleared" | "Under Contract" | "Closed";

export interface Deal {
  id: string;
  unitId: string;
  clientName: string;
  clientEmail: string;
  value: number;
  stage: DealStage;
  createdAt: string;
  agent: string;
  tourDatetime?: string;
  notes?: string;
}

export interface Deposit {
  id: string;
  unitId: string;
  clientName: string;
  amount: number;
  type: "Hold Fee" | "Initial Deposit" | "Escrow" | "Monthly Rent";
  status: "Pending" | "Cleared" | "Held in Escrow";
  date: string;
  dealId: string;
}

interface BookingCtx {
  units: Unit[];
  deals: Deal[];
  deposits: Deposit[];
  scheduleTour: (unitId: string, client: { name: string; email: string }, datetime: string) => Deal;
  placeHold: (unitId: string, client: { name: string; email: string }) => Deal;
  checkout: (unitId: string, client: { name: string; email: string }, depositAmount: number) => { deal: Deal; deposit: Deposit };
  getDealForUnit: (unitId: string) => Deal | undefined;
}

const BookingContext = createContext<BookingCtx>({} as BookingCtx);

const SEED_DEALS: Deal[] = [
  { id: "DL-0001", unitId: "1321-A", clientName: "Sophia Reeves", clientEmail: "s.reeves@meridiangroup.com", value: 4_800_000, stage: "Under Contract", createdAt: "Sep 1, 2026", agent: "A. Chen", notes: "Pre-approved financing" },
  { id: "DL-0002", unitId: "0704-B", clientName: "Robert & Lisa Kim", clientEmail: "rkim@kimventures.co", value: 2_120_000, stage: "Hold Placed", createdAt: "Sep 2, 2026", agent: "M. Torres", tourDatetime: "Sep 5, 2026 2:00 PM" },
  { id: "DL-0003", unitId: "0915-C", clientName: "Harlan Frost LLC", clientEmail: "hfrost@frostcapital.com", value: 1_960_000, stage: "Tour Scheduled", createdAt: "Sep 3, 2026", agent: "J. Carter", tourDatetime: "Sep 6, 2026 10:00 AM" },
  { id: "DL-0004", unitId: "1524-D", clientName: "Dana Osei", clientEmail: "dana.osei@gmail.com", value: 2_440_000, stage: "Deposit Cleared", createdAt: "Aug 28, 2026", agent: "P. Singh" },
];

const SEED_DEPOSITS: Deposit[] = [
  { id: "DEP-0001", unitId: "1321-A", clientName: "Sophia Reeves", amount: 480_000, type: "Initial Deposit", status: "Cleared", date: "Sep 1, 2026", dealId: "DL-0001" },
  { id: "DEP-0002", unitId: "0704-B", clientName: "Robert & Lisa Kim", amount: 5_000, type: "Hold Fee", status: "Cleared", date: "Sep 2, 2026", dealId: "DL-0002" },
  { id: "DEP-0003", unitId: "1524-D", clientName: "Dana Osei", amount: 244_000, type: "Initial Deposit", status: "Held in Escrow", date: "Aug 28, 2026", dealId: "DL-0004" },
];

let dealCounter = 10;
let depositCounter = 10;

export function BookingProvider({ children }: { children: ReactNode }) {
  const [units, setUnits] = useState<Unit[]>(BUILDING_UNITS);
  const [deals, setDeals] = useState<Deal[]>(SEED_DEALS);
  const [deposits, setDeposits] = useState<Deposit[]>(SEED_DEPOSITS);

  const AGENTS = ["A. Chen", "M. Torres", "J. Carter", "P. Singh", "L. Brauer"];

  function setUnitStatus(unitId: string, status: UnitStatus, extra?: Partial<Unit>) {
    setUnits(us => us.map(u => u.id === unitId ? { ...u, status, ...extra } : u));
  }

  function scheduleTour(unitId: string, client: { name: string; email: string }, datetime: string): Deal {
    const unit = units.find(u => u.id === unitId)!;
    const deal: Deal = {
      id: `DL-${String(++dealCounter).padStart(4, "0")}`,
      unitId,
      clientName: client.name,
      clientEmail: client.email,
      value: unit.price,
      stage: "Tour Scheduled",
      createdAt: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      agent: AGENTS[Math.floor(Math.random() * AGENTS.length)],
      tourDatetime: datetime,
    };
    setDeals(ds => [deal, ...ds]);
    return deal;
  }

  function placeHold(unitId: string, client: { name: string; email: string }): Deal {
    const unit = units.find(u => u.id === unitId)!;
    setUnitStatus(unitId, "Held", { holdClient: client.name, holdExpiry: "48 hours remaining" });
    const deal: Deal = {
      id: `DL-${String(++dealCounter).padStart(4, "0")}`,
      unitId,
      clientName: client.name,
      clientEmail: client.email,
      value: unit.price,
      stage: "Hold Placed",
      createdAt: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      agent: AGENTS[Math.floor(Math.random() * AGENTS.length)],
    };
    const dep: Deposit = {
      id: `DEP-${String(++depositCounter).padStart(4, "0")}`,
      unitId,
      clientName: client.name,
      amount: 5_000,
      type: "Hold Fee",
      status: "Cleared",
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      dealId: deal.id,
    };
    setDeals(ds => [deal, ...ds]);
    setDeposits(ds => [dep, ...ds]);
    return deal;
  }

  function checkout(unitId: string, client: { name: string; email: string }, depositAmount: number) {
    const unit = units.find(u => u.id === unitId)!;
    setUnitStatus(unitId, "Reserved", { holdClient: client.name });
    const deal: Deal = {
      id: `DL-${String(++dealCounter).padStart(4, "0")}`,
      unitId,
      clientName: client.name,
      clientEmail: client.email,
      value: unit.price,
      stage: "Deposit Cleared",
      createdAt: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      agent: AGENTS[Math.floor(Math.random() * AGENTS.length)],
    };
    const dep: Deposit = {
      id: `DEP-${String(++depositCounter).padStart(4, "0")}`,
      unitId,
      clientName: client.name,
      amount: depositAmount,
      type: "Initial Deposit",
      status: "Held in Escrow",
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      dealId: deal.id,
    };
    setDeals(ds => [deal, ...ds]);
    setDeposits(ds => [dep, ...ds]);
    return { deal, deposit: dep };
  }

  function getDealForUnit(unitId: string): Deal | undefined {
    return deals.find(d => d.unitId === unitId);
  }

  return (
    <BookingContext.Provider value={{ units, deals, deposits, scheduleTour, placeHold, checkout, getDealForUnit }}>
      {children}
    </BookingContext.Provider>
  );
}

export const useBooking = () => useContext(BookingContext);
