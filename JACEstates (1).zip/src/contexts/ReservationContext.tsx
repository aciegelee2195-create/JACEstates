import { createContext, useContext, useState, type ReactNode } from "react";

export type ReservationType = "Short Stay" | "Long-Term Lease" | "Purchase Inquiry";
export type ReservationStatus = "Pending" | "Confirmed" | "Cancelled" | "Completed";

export interface Reservation {
  id: string;
  unitId: string;
  unitLabel: string;
  unitType: string;
  floor: number;
  img: string;
  price: number;
  monthlyRent: number;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  type: ReservationType;
  checkIn: string;
  checkOut: string;
  nights: number;
  depositAmount: number;
  paymentMethod: string;
  status: ReservationStatus;
  agent: string;
  createdAt: string;
  notes: string;
}

interface ReservationCtx {
  reservations: Reservation[];
  addReservation: (r: Omit<Reservation, "id" | "createdAt" | "agent" | "status">) => Reservation;
  updateStatus: (id: string, status: ReservationStatus) => void;
  assignAgent: (id: string, agent: string) => void;
}

const ReservationContext = createContext<ReservationCtx>({} as ReservationCtx);

const AGENTS = ["Alexandra Chen", "Marcus Torres", "Jordan Carter", "Priya Singh", "Lena Brauer"];

const SEED: Reservation[] = [
  {
    id: "RES-0001", unitId: "1321-A", unitLabel: "Unit 1321-A", unitType: "3BR", floor: 13,
    img: "photo-1502672260266-1c1ef2d93688",
    price: 4_800_000, monthlyRent: 12_500,
    clientName: "Sophia Reeves", clientEmail: "s.reeves@email.com", clientPhone: "+1 (305) 555-0192",
    type: "Purchase Inquiry", checkIn: "2026-09-10", checkOut: "2026-09-10", nights: 0,
    depositAmount: 480_000, paymentMethod: "Wire Transfer",
    status: "Confirmed", agent: "Alexandra Chen", createdAt: "2026-09-01",
    notes: "Pre-approved financing. Interested in penthouse view units.",
  },
  {
    id: "RES-0002", unitId: "0704-B", unitLabel: "Unit 0704-B", unitType: "2BR", floor: 7,
    img: "photo-1560448204-603b3fc33ddc",
    price: 2_120_000, monthlyRent: 6_800,
    clientName: "Robert Kim", clientEmail: "rkim@email.com", clientPhone: "+1 (212) 555-0341",
    type: "Short Stay", checkIn: "2026-09-15", checkOut: "2026-09-22", nights: 7,
    depositAmount: 5_000, paymentMethod: "Credit Card",
    status: "Confirmed", agent: "Marcus Torres", createdAt: "2026-09-02",
    notes: "Business trip. Requests early check-in.",
  },
  {
    id: "RES-0003", unitId: "0915-C", unitLabel: "Unit 0915-C", unitType: "1BR", floor: 9,
    img: "photo-1522708323590-d24dbb6b0267",
    price: 1_960_000, monthlyRent: 5_400,
    clientName: "Harlan Frost", clientEmail: "hfrost@email.com", clientPhone: "+1 (617) 555-0087",
    type: "Long-Term Lease", checkIn: "2026-10-01", checkOut: "2027-09-30", nights: 364,
    depositAmount: 10_800, paymentMethod: "Wire Transfer",
    status: "Pending", agent: "Jordan Carter", createdAt: "2026-09-03",
    notes: "Annual lease. Legal team reviewing contract.",
  },
  {
    id: "RES-0004", unitId: "1524-D", unitLabel: "Unit 1524-D", unitType: "2BR", floor: 15,
    img: "photo-1600585154340-be6161a56a0c",
    price: 2_440_000, monthlyRent: 7_200,
    clientName: "Dana Osei", clientEmail: "dana.osei@email.com", clientPhone: "+1 (404) 555-0219",
    type: "Purchase Inquiry", checkIn: "2026-09-20", checkOut: "2026-09-20", nights: 0,
    depositAmount: 244_000, paymentMethod: "Crypto (USDC)",
    status: "Pending", agent: "Priya Singh", createdAt: "2026-08-28",
    notes: "High-net-worth client. Prefers weekend appointments.",
  },
];

let counter = 10;

export function ReservationProvider({ children }: { children: ReactNode }) {
  const [reservations, setReservations] = useState<Reservation[]>(SEED);

  function addReservation(r: Omit<Reservation, "id" | "createdAt" | "agent" | "status">): Reservation {
    const res: Reservation = {
      ...r,
      id: `RES-${String(++counter).padStart(4, "0")}`,
      status: "Pending",
      agent: AGENTS[Math.floor(Math.random() * AGENTS.length)],
      createdAt: new Date().toISOString().slice(0, 10),
    };
    setReservations(rs => [res, ...rs]);
    return res;
  }

  function updateStatus(id: string, status: ReservationStatus) {
    setReservations(rs => rs.map(r => r.id === id ? { ...r, status } : r));
  }

  function assignAgent(id: string, agent: string) {
    setReservations(rs => rs.map(r => r.id === id ? { ...r, agent } : r));
  }

  return (
    <ReservationContext.Provider value={{ reservations, addReservation, updateStatus, assignAgent }}>
      {children}
    </ReservationContext.Provider>
  );
}

export const useReservations = () => useContext(ReservationContext);
