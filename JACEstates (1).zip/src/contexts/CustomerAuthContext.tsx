import { createContext, useContext, useState, type ReactNode } from "react";

export interface CustomerPreferences {
  propertyTypes: string[];
  budgetMin: number;
  budgetMax: number;
  locations: string[];
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  verified: boolean;
  idUploaded: boolean;
  preferences: CustomerPreferences;
  avatarInitials: string;
  joinedAt: string;
}

export type ReservationStatus = "upcoming" | "active" | "completed" | "cancelled";

export interface CheckoutState {
  keysReturned: boolean;
  trashDisposed: boolean;
  lightsOff: boolean;
  acOff: boolean;
  damageNotes: string;
  photoUploaded: boolean;
  completedAt: string | null;
}

export interface Reservation {
  id: string;
  unitId: string;
  propertyName: string;
  propertyAddress: string;
  floor: number;
  unitType: string;
  img: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  baseRate: number;
  cleaningFee: number;
  serviceFee: number;
  securityDeposit: number;
  total: number;
  status: ReservationStatus;
  accessCode: string;
  wifiName: string;
  wifiPassword: string;
  checkInInstructions: string;
  agent: string;
  checkoutState: CheckoutState | null;
}

interface CustomerAuthCtx {
  customer: Customer | null;
  reservations: Reservation[];
  login: (email: string, _password: string) => boolean;
  signup: (data: { name: string; email: string; phone: string; preferences: CustomerPreferences }) => Customer;
  logout: () => void;
  makeReservation: (params: {
    unitId: string; propertyName: string; propertyAddress: string; floor: number; unitType: string; img: string;
    checkIn: string; checkOut: string; nights: number; baseRate: number;
  }) => Reservation;
  startCheckout: (reservationId: string) => void;
  updateCheckoutState: (reservationId: string, state: Partial<CheckoutState>) => void;
  completeCheckout: (reservationId: string) => void;
}

const CustomerAuthContext = createContext<CustomerAuthCtx>({} as CustomerAuthCtx);

const DEMO_CUSTOMER: Customer = {
  id: "CUST-0001",
  name: "Alexandra Voss",
  email: "alex.voss@email.com",
  phone: "+1 (305) 555-0192",
  verified: true,
  idUploaded: true,
  preferences: { propertyTypes: ["Residential", "Vacation Villa"], budgetMin: 1_000_000, budgetMax: 5_000_000, locations: ["Miami", "Brickell", "Edgewater"] },
  avatarInitials: "AV",
  joinedAt: "Aug 15, 2026",
};

const genCode = () => String(Math.floor(1000 + Math.random() * 9000));
const WIFI_NAMES = ["MeridianGuest_5G", "MeridianResidences", "JACEstates_WiFi"];
const AGENTS = ["A. Chen", "M. Torres", "J. Carter", "P. Singh"];

const SEED_RESERVATIONS: Reservation[] = [
  {
    id: "RES-0001", unitId: "0804-B", propertyName: "Meridian Residences", propertyAddress: "301 Meridian Tower, Unit 804-B, Miami FL 33131",
    floor: 8, unitType: "2BR", img: "photo-1502672260266-1c1ef2d93688",
    checkIn: "2026-09-10", checkOut: "2026-09-17", nights: 7,
    baseRate: 850, cleaningFee: 150, serviceFee: 714, securityDeposit: 500, total: 6864,
    status: "upcoming", accessCode: "4829", wifiName: "MeridianGuest_5G", wifiPassword: "Stay2026!",
    checkInInstructions: "Concierge will greet you at the lobby. Smart lock code activated 2h before check-in. Parking on Level B2, space #47.",
    agent: "A. Chen", checkoutState: null,
  },
  {
    id: "RES-0002", unitId: "1104-C", propertyName: "Meridian Residences", propertyAddress: "301 Meridian Tower, Unit 1104-C, Miami FL 33131",
    floor: 11, unitType: "1BR", img: "photo-1560448204-603b3fc33ddc",
    checkIn: "2026-08-01", checkOut: "2026-08-08", nights: 7,
    baseRate: 620, cleaningFee: 120, serviceFee: 521, securityDeposit: 500, total: 5491,
    status: "completed", accessCode: "7732", wifiName: "MeridianResidences", wifiPassword: "Summer2026",
    checkInInstructions: "Use smart lock code on door. Amenity access card in the welcome envelope on the kitchen counter.",
    agent: "M. Torres",
    checkoutState: {
      keysReturned: true, trashDisposed: true, lightsOff: true, acOff: true,
      damageNotes: "", photoUploaded: false, completedAt: "2026-08-08T11:30:00",
    },
  },
];

let resCounter = 10;

function generateAccessDetails() {
  return {
    accessCode: genCode(),
    wifiName: WIFI_NAMES[Math.floor(Math.random() * WIFI_NAMES.length)],
    wifiPassword: `Meridian${new Date().getFullYear()}!`,
    checkInInstructions: "Concierge available 24/7 in the main lobby. Smart lock code active 2 hours before check-in. Please register your vehicle at the front desk for complimentary valet.",
  };
}

export function CustomerAuthProvider({ children }: { children: ReactNode }) {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [reservations, setReservations] = useState<Reservation[]>(SEED_RESERVATIONS);

  function login(email: string, _password: string): boolean {
    if (email === DEMO_CUSTOMER.email || email.includes("@")) {
      setCustomer(email === DEMO_CUSTOMER.email ? DEMO_CUSTOMER : { ...DEMO_CUSTOMER, email, id: `CUST-${Date.now()}` });
      return true;
    }
    return false;
  }

  function signup(data: { name: string; email: string; phone: string; preferences: CustomerPreferences }): Customer {
    const c: Customer = {
      id: `CUST-${Date.now()}`,
      name: data.name, email: data.email, phone: data.phone,
      verified: false, idUploaded: false,
      preferences: data.preferences,
      avatarInitials: data.name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase(),
      joinedAt: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    };
    setCustomer(c);
    return c;
  }

  function logout() { setCustomer(null); }

  function makeReservation(params: {
    unitId: string; propertyName: string; propertyAddress: string; floor: number; unitType: string; img: string;
    checkIn: string; checkOut: string; nights: number; baseRate: number;
  }): Reservation {
    const { accessCode, wifiName, wifiPassword, checkInInstructions } = generateAccessDetails();
    const serviceFee = Math.round(params.baseRate * params.nights * 0.12);
    const cleaningFee = 150;
    const securityDeposit = 500;
    const total = params.baseRate * params.nights + cleaningFee + serviceFee + securityDeposit;
    const res: Reservation = {
      id: `RES-${String(++resCounter).padStart(4, "0")}`,
      ...params,
      cleaningFee, serviceFee, securityDeposit, total,
      status: "upcoming",
      accessCode, wifiName, wifiPassword, checkInInstructions,
      agent: AGENTS[Math.floor(Math.random() * AGENTS.length)],
      checkoutState: null,
    };
    setReservations(rs => [res, ...rs]);
    return res;
  }

  function startCheckout(reservationId: string) {
    setReservations(rs => rs.map(r => r.id === reservationId ? {
      ...r, checkoutState: { keysReturned: false, trashDisposed: false, lightsOff: false, acOff: false, damageNotes: "", photoUploaded: false, completedAt: null }
    } : r));
  }

  function updateCheckoutState(reservationId: string, state: Partial<CheckoutState>) {
    setReservations(rs => rs.map(r => r.id === reservationId && r.checkoutState
      ? { ...r, checkoutState: { ...r.checkoutState, ...state } } : r));
  }

  function completeCheckout(reservationId: string) {
    setReservations(rs => rs.map(r => r.id === reservationId ? {
      ...r, status: "completed" as ReservationStatus,
      checkoutState: r.checkoutState ? { ...r.checkoutState, completedAt: new Date().toISOString() } : null,
    } : r));
  }

  return (
    <CustomerAuthContext.Provider value={{ customer, reservations, login, signup, logout, makeReservation, startCheckout, updateCheckoutState, completeCheckout }}>
      {children}
    </CustomerAuthContext.Provider>
  );
}

export const useCustomerAuth = () => useContext(CustomerAuthContext);
