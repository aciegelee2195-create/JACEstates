import { createContext, useContext, useState, type ReactNode } from "react";

export interface Message {
  id: string;
  from: "client" | "agent";
  senderName: string;
  text: string;
  timestamp: string;
  read: boolean;
}

export interface Thread {
  id: string;
  reservationId: string | null;
  unitLabel: string;
  agentName: string;
  agentInitials: string;
  agentColor: string;
  messages: Message[];
}

interface MessageCtx {
  threads: Thread[];
  sendMessage: (threadId: string, text: string, senderName: string) => void;
  addThread: (thread: Omit<Thread, "messages">) => void;
  markRead: (threadId: string) => void;
  unreadCount: number;
}

const MessageContext = createContext<MessageCtx>({} as MessageCtx);

const SEED_THREADS: Thread[] = [
  {
    id: "THR-001",
    reservationId: "RES-0001",
    unitLabel: "Unit 1321-A · 3BR · Floor 13",
    agentName: "Alexandra Chen",
    agentInitials: "AC",
    agentColor: "#059669",
    messages: [
      { id: "M-001", from: "agent", senderName: "Alexandra Chen", text: "Hello! I received your purchase inquiry for Unit 1321-A. I would love to schedule a viewing at your convenience. When are you available?", timestamp: "2026-09-01T10:30:00", read: true },
      { id: "M-002", from: "client", senderName: "Sophia Reeves", text: "Hi Alexandra! I am available this weekend, preferably Saturday morning.", timestamp: "2026-09-01T11:15:00", read: true },
      { id: "M-003", from: "agent", senderName: "Alexandra Chen", text: "Saturday at 10am works perfectly. I'll send a calendar invite. The unit has stunning city views — I think you'll love it!", timestamp: "2026-09-01T11:40:00", read: false },
    ],
  },
  {
    id: "THR-002",
    reservationId: "RES-0003",
    unitLabel: "Unit 0915-C · 1BR · Floor 9",
    agentName: "Jordan Carter",
    agentInitials: "JC",
    agentColor: "#7C3AED",
    messages: [
      { id: "M-004", from: "agent", senderName: "Jordan Carter", text: "Your lease agreement for Unit 0915-C is under review by our legal team. Estimated completion is 3-5 business days.", timestamp: "2026-09-03T09:00:00", read: true },
      { id: "M-005", from: "client", senderName: "Harlan Frost", text: "Thank you for the update. Please let me know if you need any additional documents.", timestamp: "2026-09-03T14:22:00", read: false },
    ],
  },
];

let msgCounter = 100;

export function MessageProvider({ children }: { children: ReactNode }) {
  const [threads, setThreads] = useState<Thread[]>(SEED_THREADS);

  function sendMessage(threadId: string, text: string, senderName: string) {
    const msg: Message = {
      id: `M-${String(++msgCounter).padStart(3, "0")}`,
      from: "client",
      senderName,
      text,
      timestamp: new Date().toISOString(),
      read: true,
    };
    setThreads(ts => ts.map(t => t.id === threadId ? { ...t, messages: [...t.messages, msg] } : t));

    // Simulate agent reply after 1.5s
    setTimeout(() => {
      const agentReplies = [
        "Thank you for your message. I'll look into that right away.",
        "Noted! I'll get back to you with more details shortly.",
        "Great question. Let me check with the property team and follow up.",
        "Absolutely, I'll make a note of that for your reservation.",
        "Understood. I'll prepare the relevant documents for your review.",
      ];
      const reply: Message = {
        id: `M-${String(++msgCounter).padStart(3, "0")}`,
        from: "agent",
        senderName: threads.find(t => t.id === threadId)?.agentName ?? "Agent",
        text: agentReplies[Math.floor(Math.random() * agentReplies.length)],
        timestamp: new Date().toISOString(),
        read: false,
      };
      setThreads(ts => ts.map(t => t.id === threadId ? { ...t, messages: [...t.messages, reply] } : t));
    }, 1500);
  }

  function addThread(thread: Omit<Thread, "messages">) {
    setThreads(ts => {
      if (ts.find(t => t.reservationId === thread.reservationId)) return ts;
      return [...ts, { ...thread, messages: [
        {
          id: `M-${String(++msgCounter).padStart(3, "0")}`,
          from: "agent",
          senderName: thread.agentName,
          text: `Hi! I'm ${thread.agentName}, your dedicated agent for ${thread.unitLabel}. Your reservation has been received and I'll be in touch shortly with next steps. Feel free to message me any time!`,
          timestamp: new Date().toISOString(),
          read: false,
        }
      ] }];
    });
  }

  function markRead(threadId: string) {
    setThreads(ts => ts.map(t => t.id === threadId ? { ...t, messages: t.messages.map(m => ({ ...m, read: true })) } : t));
  }

  const unreadCount = threads.reduce((n, t) => n + t.messages.filter(m => m.from === "agent" && !m.read).length, 0);

  return (
    <MessageContext.Provider value={{ threads, sendMessage, addThread, markRead, unreadCount }}>
      {children}
    </MessageContext.Provider>
  );
}

export const useMessages = () => useContext(MessageContext);
