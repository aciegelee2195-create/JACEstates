export type UnitStatus = "Available" | "Held" | "Reserved" | "Sold";
export type UnitType = "Studio" | "1BR" | "2BR" | "3BR" | "Penthouse";
export type Orientation = "N" | "NE" | "E" | "SE" | "S" | "SW" | "W" | "NW";

export interface Unit {
  id: string;
  floor: number;
  position: "A" | "B" | "C" | "D";
  type: UnitType;
  sqft: number;
  price: number;
  monthlyRent: number;
  status: UnitStatus;
  orientation: Orientation;
  features: string[];
  view: string;
  img: string;
  holdExpiry?: string;
  holdClient?: string;
}

const UNIT_IMGS = [
  "photo-1493246507139-91e8fad9978e",
  "photo-1512917774080-9991f1c4c750",
  "photo-1556909114-f6e7ad7d3136",
  "photo-1560448204-e02f11c3d0e2",
  "photo-1502672260266-1c1ef2d93688",
];

type StatusSeed = { [key: string]: UnitStatus };
const STATUS_SEED: StatusSeed = {
  "0202-B": "Sold", "0203-C": "Sold", "0305-A": "Sold", "0406-D": "Sold",
  "0508-B": "Sold", "0612-A": "Sold", "0714-C": "Sold", "0815-D": "Sold",
  "1018-B": "Sold", "1120-A": "Sold", "1222-C": "Sold",
  "0302-A": "Held", "0704-B": "Held", "0915-C": "Held",
  "1321-A": "Reserved", "1524-D": "Reserved", "1820-B": "Reserved",
};

function generateUnits(): Unit[] {
  const units: Unit[] = [];
  const orientations: Orientation[] = ["NE", "NW", "SE", "SW"];
  const positions: ["A", "B", "C", "D"] = ["A", "B", "C", "D"];

  for (let floor = 2; floor <= 24; floor++) {
    const isPenthouse = floor >= 23;
    const isHighRise = floor >= 17;
    const isMidRise = floor >= 10;
    const unitCount = isPenthouse ? 2 : 4;

    for (let pi = 0; pi < unitCount; pi++) {
      const pos = positions[pi];
      const id = `${String(floor).padStart(2, "0")}${String(pi + 1).padStart(2, "0")}-${pos}`;
      const idKey = id;

      let type: UnitType;
      let sqft: number;
      let price: number;

      if (isPenthouse) {
        type = "Penthouse";
        sqft = pi === 0 ? 4200 : 3600;
        price = pi === 0 ? 12_400_000 : 9_800_000;
      } else if (isHighRise) {
        type = pi < 2 ? "3BR" : "2BR";
        sqft = pi < 2 ? 2400 + pi * 180 : 1650 + pi * 100;
        price = pi < 2 ? 4_200_000 + floor * 80_000 : 2_800_000 + floor * 60_000;
      } else if (isMidRise) {
        type = pi === 0 ? "2BR" : pi === 3 ? "1BR" : "2BR";
        sqft = pi === 0 ? 1820 : pi === 3 ? 980 : 1420 + pi * 80;
        price = 1_600_000 + floor * 40_000 + pi * 120_000;
      } else {
        type = pi < 2 ? "1BR" : "Studio";
        sqft = pi < 2 ? 1050 + pi * 120 : 620 + pi * 40;
        price = 850_000 + floor * 20_000 + pi * 80_000;
      }

      const status: UnitStatus = STATUS_SEED[idKey] ?? "Available";

      units.push({
        id,
        floor,
        position: pos,
        type,
        sqft,
        price,
        monthlyRent: Math.round(price * 0.0042),
        status,
        orientation: orientations[pi % 4],
        features: getFeatures(type, floor),
        view: getView(orientations[pi % 4], floor),
        img: UNIT_IMGS[(floor + pi) % UNIT_IMGS.length],
        holdExpiry: status === "Held" ? "48 hours remaining" : undefined,
        holdClient: status === "Held" ? ["Sarah M.", "Chen F.", "David K."][pi % 3] : undefined,
      });
    }
  }
  return units;
}

function getFeatures(type: UnitType, floor: number): string[] {
  const base = ["Floor-to-ceiling windows", "Private balcony", "In-unit laundry"];
  if (type === "Penthouse") return [...base, "Private rooftop terrace", "Smart home system", "Wine cellar", "Chef's kitchen"];
  if (type === "3BR") return [...base, "Walk-in closets", "Dual vanity master bath", "Media room"];
  if (type === "2BR") return [...base, "Walk-in closet", "Stone countertops"];
  if (type === "1BR") return [...base.slice(0, 2), "Built-in storage"];
  return ["Juliet balcony", "Open-plan kitchen"];
}

function getView(orientation: Orientation, floor: number): string {
  const views: Record<Orientation, string> = {
    NE: "Bay and city skyline panorama",
    NW: "Mountain range and park views",
    SE: "Ocean horizon and marina",
    SW: "Sunset over the financial district",
    N: "City skyline",
    S: "Ocean views",
    E: "Sunrise bay views",
    W: "City sunset views",
  };
  const prefix = floor >= 17 ? "Unobstructed " : floor >= 10 ? "Elevated " : "";
  return prefix + views[orientation];
}

export const BUILDING_UNITS: Unit[] = generateUnits();

export const BUILDING_META = {
  name: "Meridian Residences",
  address: "301 Meridian Tower, Harbor District",
  city: "Miami, FL 33131",
  totalFloors: 24,
  totalUnits: BUILDING_UNITS.length,
  completionDate: "Q3 2027",
  developer: "JACEstates Development Group",
  architect: "Foster & Partners",
  amenities: ["Rooftop infinity pool", "Private concierge", "Underground valet parking", "Fitness center & spa", "Private dining room", "Co-working lounge", "EV charging stations"],
  img: "photo-1486325212027-8081e485255e",
};

export function getFloorUnits(floor: number): Unit[] {
  return BUILDING_UNITS.filter(u => u.floor === floor);
}

export function getFloorLabel(floor: number): string {
  if (floor >= 23) return "Penthouse Collection";
  if (floor >= 17) return "Signature Residences";
  if (floor >= 10) return "Premier Collection";
  return "Horizon Collection";
}

export function fmtPrice(n: number): string {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  return `$${(n / 1_000).toFixed(0)}K`;
}
