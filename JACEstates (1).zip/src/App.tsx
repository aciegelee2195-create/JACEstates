import { useState } from "react";
import { ThemeProvider } from "./contexts/ThemeContext";
import { BookingProvider } from "./contexts/BookingContext";
import { ReservationProvider } from "./contexts/ReservationContext";
import { ClientAuthProvider } from "./contexts/ClientAuthContext";
import { MessageProvider } from "./contexts/MessageContext";
import LoginGate, { type SessionType } from "./components/LoginGate";
import ClientApp from "./components/ClientPortal/ClientApp";
import AdminApp from "./components/AdminPortal/CommandCenter";

export type Portal = "client" | "admin" | null;

export interface AppUser {
  name: string;
  role: string;
  email: string;
  roleKey: "super_admin" | "broker" | "property_manager" | "finance" | "client";
}

export default function App() {
  const [session, setSession] = useState<SessionType | null>(null);

  function handleLogout() { setSession(null); }

  return (
    <ThemeProvider>
      <BookingProvider>
        <ReservationProvider>
          <ClientAuthProvider>
            <MessageProvider>
              {session === null && (
                <LoginGate onLogin={setSession} />
              )}
              {session?.type === "client" && (
                <ClientApp user={session.user} onLogout={handleLogout} />
              )}
              {session?.type === "admin" && (
                <AdminApp adminUser={session.user} onLogout={handleLogout} onSwitchPortal={handleLogout} />
              )}
            </MessageProvider>
          </ClientAuthProvider>
        </ReservationProvider>
      </BookingProvider>
    </ThemeProvider>
  );
}
