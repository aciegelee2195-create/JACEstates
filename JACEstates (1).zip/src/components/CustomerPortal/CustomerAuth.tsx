import { useState } from "react";
import { useCustomerAuth, type CustomerPreferences } from "../../contexts/CustomerAuthContext";

type AuthMode = "login" | "signup" | "forgot";
type SignupStep = 1 | 2 | 3;

interface Props { onSuccess: () => void; onBack: () => void; }

const PROPERTY_TYPES = ["Residential", "Vacation Villa", "Commercial Space", "Studio Loft"];
const LOCATION_TAGS = ["Miami", "Brickell", "Edgewater", "Wynwood", "Coconut Grove", "South Beach"];

function PasswordStrength({ password }: { password: string }) {
  const score = [password.length >= 8, /[A-Z]/.test(password), /[0-9]/.test(password), /[^A-Za-z0-9]/.test(password)].filter(Boolean).length;
  const labels = ["", "Weak", "Fair", "Good", "Strong"];
  const colors = ["#E2E8F0", "#DC2626", "#D97706", "#0284C7", "#059669"];
  return (
    <div style={{ marginTop: "6px" }}>
      <div style={{ display: "flex", gap: "3px", marginBottom: "3px" }}>
        {[1, 2, 3, 4].map(i => (
          <div key={i} style={{ flex: 1, height: "3px", borderRadius: "100px", background: i <= score ? colors[score] : "#E2E8F0", transition: "background 0.2s" }} />
        ))}
      </div>
      {password && <p style={{ fontSize: "11px", color: colors[score] }}>{labels[score]}</p>}
    </div>
  );
}

function OTPInput({ onComplete }: { onComplete: (code: string) => void }) {
  const [digits, setDigits] = useState(["", "", "", "", "", ""]);
  function handleChange(i: number, v: string) {
    if (!/^\d?$/.test(v)) return;
    const next = [...digits]; next[i] = v;
    setDigits(next);
    if (v && i < 5) (document.getElementById(`otp-${i + 1}`) as HTMLInputElement)?.focus();
    if (next.every(d => d)) onComplete(next.join(""));
  }
  return (
    <div style={{ display: "flex", gap: "8px", justifyContent: "center" }}>
      {digits.map((d, i) => (
        <input id={`otp-${i}`} key={i} value={d} onChange={e => handleChange(i, e.target.value)}
          maxLength={1} inputMode="numeric"
          style={{ width: "44px", height: "52px", textAlign: "center", fontSize: "20px", fontWeight: 700, border: `1.5px solid ${d ? "#0D7A52" : "#E8E4DC"}`, borderRadius: "8px", background: "#FAFAF7", color: "#1A1714", outline: "none", fontFamily: "JetBrains Mono, monospace", transition: "border-color 0.15s" }}
          onFocus={e => (e.target.style.borderColor = "#B8832A")} onBlur={e => (e.target.style.borderColor = d ? "#0D7A52" : "#E8E4DC")}
        />
      ))}
    </div>
  );
}

export default function CustomerAuth({ onSuccess, onBack }: Props) {
  const { login, signup } = useCustomerAuth();
  const [mode, setMode] = useState<AuthMode>("login");
  const [step, setStep] = useState<SignupStep>(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [otpVerified, setOtpVerified] = useState(false);

  // Login fields
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [showPw, setShowPw] = useState(false);

  // Signup step 1
  const [fullName, setFullName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [signupPw, setSignupPw] = useState("");

  // Signup step 2 (verification — handled in UI, treated as complete after OTP)
  const [idUploaded, setIdUploaded] = useState(false);

  // Signup step 3 — preferences
  const [prefTypes, setPrefTypes] = useState<string[]>([]);
  const [budgetMin, setBudgetMin] = useState(500_000);
  const [budgetMax, setBudgetMax] = useState(5_000_000);
  const [locations, setLocations] = useState<string[]>([]);

  const inp: React.CSSProperties = {
    width: "100%", padding: "11px 13px", border: "1px solid #E8E4DC", borderRadius: "8px",
    background: "#FAFAF7", color: "#1A1714", fontSize: "14px", outline: "none",
    fontFamily: "Inter, sans-serif", boxSizing: "border-box", transition: "border-color 0.15s",
  };

  const focus = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => (e.target.style.borderColor = "#B8832A");
  const blur = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => (e.target.style.borderColor = "#E8E4DC");

  function handleLogin(ev: React.FormEvent) {
    ev.preventDefault();
    setLoading(true); setError("");
    setTimeout(() => {
      const ok = login(email, password);
      if (ok) onSuccess();
      else { setError("Invalid email or password. Try: alex.voss@email.com"); setLoading(false); }
    }, 700);
  }

  function handleSignupNext() {
    if (step === 1) {
      if (!fullName || !signupEmail || !phone || signupPw.length < 6) { setError("Please fill all fields (min 6 char password)."); return; }
      setError(""); setStep(2);
    } else if (step === 2) {
      if (!otpVerified) { setError("Please verify your phone number."); return; }
      setError(""); setStep(3);
    } else {
      setLoading(true);
      setTimeout(() => {
        const prefs: CustomerPreferences = { propertyTypes: prefTypes, budgetMin, budgetMax, locations };
        signup({ name: fullName, email: signupEmail, phone, preferences: prefs });
        onSuccess();
      }, 900);
    }
  }

  const STEP_LABELS = ["Account Details", "Verification", "Preferences"];

  return (
    <div style={{ minHeight: "100vh", display: "flex", background: "#FAFAF7", fontFamily: "Inter, sans-serif" }}>
      {/* Left image panel */}
      <div style={{ flex: "0 0 45%", position: "relative", overflow: "hidden" }}>
        <img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900&h=1400&fit=crop&auto=format"
          alt="Luxury interior" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(26,23,20,0.2) 0%, rgba(26,23,20,0.75) 100%)" }} />
        <div style={{ position: "absolute", bottom: "48px", left: "40px", right: "40px" }}>
          <div style={{ marginBottom: "20px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "16px" }}>
              <div style={{ width: "28px", height: "28px", borderRadius: "7px", background: "#0D7A52", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <span style={{ color: "#fff", fontWeight: 800, fontSize: "12px", fontFamily: "Plus Jakarta Sans, sans-serif" }}>J</span>
              </div>
              <span style={{ color: "#FAF8F5", fontSize: "15px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif" }}>JACEstates</span>
            </div>
            <h2 style={{ fontSize: "32px", fontWeight: 400, color: "#FAF8F5", fontFamily: "Instrument Serif, serif", lineHeight: 1.2, marginBottom: "12px" }}>
              Your luxury<br /><em>home awaits</em>
            </h2>
            <p style={{ fontSize: "14px", color: "rgba(250,248,245,0.7)", lineHeight: 1.6 }}>
              Browse premium residences, book instant stays, manage your leases — all in one place.
            </p>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {["Instant online reservations", "Digital access & smart lock codes", "Lease management dashboard"].map(f => (
              <div key={f} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <span style={{ color: "#B8832A", fontSize: "12px" }}>✦</span>
                <span style={{ fontSize: "13px", color: "rgba(250,248,245,0.75)" }}>{f}</span>
              </div>
            ))}
          </div>
        </div>
        <button onClick={onBack} style={{ position: "absolute", top: "24px", left: "24px", display: "flex", alignItems: "center", gap: "6px", background: "rgba(26,23,20,0.45)", border: "1px solid rgba(255,255,255,0.15)", borderRadius: "8px", padding: "7px 14px", color: "rgba(250,248,245,0.85)", fontSize: "12px", cursor: "pointer", backdropFilter: "blur(8px)" }}>
          ← All Portals
        </button>
      </div>

      {/* Right form panel */}
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "48px 40px", overflowY: "auto" }}>
        <div style={{ width: "100%", maxWidth: "420px" }}>

          {/* ── LOGIN ── */}
          {mode === "login" && (
            <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: "0" }}>
              <h1 style={{ fontSize: "28px", fontWeight: 400, color: "#1A1714", fontFamily: "Instrument Serif, serif", marginBottom: "6px" }}>Welcome back</h1>
              <p style={{ fontSize: "14px", color: "#78726A", marginBottom: "28px" }}>Sign in to manage your reservations and stays.</p>

              {error && <div style={{ padding: "10px 13px", background: "rgba(220,38,38,0.07)", border: "1px solid rgba(220,38,38,0.2)", borderRadius: "8px", fontSize: "13px", color: "#DC2626", marginBottom: "16px" }}>{error}</div>}

              <div style={{ marginBottom: "14px" }}>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "#78726A", marginBottom: "6px", letterSpacing: "0.04em" }}>EMAIL ADDRESS</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="you@example.com" style={inp} onFocus={focus} onBlur={blur} />
              </div>

              <div style={{ marginBottom: "6px" }}>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "#78726A", marginBottom: "6px", letterSpacing: "0.04em" }}>PASSWORD</label>
                <div style={{ position: "relative" }}>
                  <input type={showPw ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)} required placeholder="••••••••" style={{ ...inp, paddingRight: "44px" }} onFocus={focus} onBlur={blur} />
                  <button type="button" onClick={() => setShowPw(v => !v)} style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "#A89E96", fontSize: "13px" }}>
                    {showPw ? "Hide" : "Show"}
                  </button>
                </div>
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                <label style={{ display: "flex", alignItems: "center", gap: "6px", cursor: "pointer", fontSize: "13px", color: "#78726A" }}>
                  <input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} style={{ accentColor: "#B8832A" }} /> Remember me
                </label>
                <button type="button" onClick={() => setMode("forgot")} style={{ background: "none", border: "none", cursor: "pointer", fontSize: "13px", color: "#B8832A", fontWeight: 500 }}>Forgot password?</button>
              </div>

              <button type="submit" disabled={loading} style={{ padding: "12px", background: loading ? "#D4CFC5" : "#B8832A", border: "none", borderRadius: "8px", color: "#fff", fontSize: "14px", fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "16px", transition: "background 0.15s" }}>
                {loading ? "Signing in…" : "Sign In →"}
              </button>

              <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
                {[["G", "Continue with Google", "#4285F4"], ["", "Continue with Apple", "#000"]].map(([icon, label, color]) => (
                  <button key={label as string} type="button" onClick={() => { login("demo@gmail.com", ""); setTimeout(onSuccess, 400); }} style={{ flex: 1, padding: "10px 8px", border: "1px solid #E8E4DC", borderRadius: "8px", background: "#fff", fontSize: "12.5px", color: "#1A1714", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px", fontWeight: 500 }}>
                    <span style={{ fontSize: icon ? "13px" : "11px", fontWeight: 700, color: color as string }}>{icon || "🍎"}</span> {label as string}
                  </button>
                ))}
              </div>

              <div style={{ textAlign: "center", paddingTop: "16px", borderTop: "1px solid #E8E4DC" }}>
                <span style={{ fontSize: "13px", color: "#78726A" }}>Don't have an account? </span>
                <button type="button" onClick={() => { setMode("signup"); setStep(1); }} style={{ background: "none", border: "none", cursor: "pointer", fontSize: "13px", color: "#B8832A", fontWeight: 600 }}>Create one</button>
              </div>

              <div style={{ marginTop: "20px", padding: "10px 14px", background: "rgba(13,122,82,0.06)", borderRadius: "8px", border: "1px solid rgba(13,122,82,0.15)" }}>
                <p style={{ fontSize: "11px", color: "#0D7A52", fontWeight: 600, marginBottom: "2px" }}>Demo access</p>
                <p style={{ fontSize: "11px", color: "#78726A" }}>Email: alex.voss@email.com · Any password</p>
              </div>
            </form>
          )}

          {/* ── FORGOT PASSWORD ── */}
          {mode === "forgot" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              <div>
                <h1 style={{ fontSize: "26px", fontWeight: 400, color: "#1A1714", fontFamily: "Instrument Serif, serif", marginBottom: "6px" }}>Reset password</h1>
                <p style={{ fontSize: "14px", color: "#78726A" }}>Enter your email and we'll send a reset link within 2 minutes.</p>
              </div>
              <div>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "#78726A", marginBottom: "6px", letterSpacing: "0.04em" }}>EMAIL ADDRESS</label>
                <input type="email" placeholder="you@example.com" style={inp} onFocus={focus} onBlur={blur} />
              </div>
              <button style={{ padding: "12px", background: "#B8832A", border: "none", borderRadius: "8px", color: "#fff", fontSize: "14px", fontWeight: 700, cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
                Send Reset Link →
              </button>
              <button onClick={() => setMode("login")} style={{ background: "none", border: "none", cursor: "pointer", fontSize: "13px", color: "#B8832A", fontWeight: 500 }}>← Back to Sign In</button>
            </div>
          )}

          {/* ── SIGNUP ── */}
          {mode === "signup" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "0" }}>
              <h1 style={{ fontSize: "28px", fontWeight: 400, color: "#1A1714", fontFamily: "Instrument Serif, serif", marginBottom: "6px" }}>Create account</h1>
              <p style={{ fontSize: "14px", color: "#78726A", marginBottom: "20px" }}>Step {step} of 3 — {STEP_LABELS[step - 1]}</p>

              {/* Step indicator */}
              <div style={{ display: "flex", gap: "4px", marginBottom: "24px" }}>
                {[1, 2, 3].map(s => (
                  <div key={s} style={{ flex: 1, height: "3px", borderRadius: "100px", background: s <= step ? "#B8832A" : "#E8E4DC", transition: "background 0.3s" }} />
                ))}
              </div>

              {error && <div style={{ padding: "10px 13px", background: "rgba(220,38,38,0.07)", border: "1px solid rgba(220,38,38,0.2)", borderRadius: "8px", fontSize: "13px", color: "#DC2626", marginBottom: "16px" }}>{error}</div>}

              {/* Step 1: Account Details */}
              {step === 1 && (
                <div style={{ display: "flex", flexDirection: "column", gap: "13px" }}>
                  {[["FULL NAME", fullName, setFullName, "Alexandra Voss", "text"], ["EMAIL ADDRESS", signupEmail, setSignupEmail, "you@example.com", "email"], ["PHONE NUMBER", phone, setPhone, "+1 (305) 555-0000", "tel"]].map(([label, val, setter, placeholder, type]) => (
                    <div key={label as string}>
                      <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "#78726A", marginBottom: "6px", letterSpacing: "0.04em" }}>{label as string}</label>
                      <input type={type as string} value={val as string} onChange={e => (setter as Function)(e.target.value)} placeholder={placeholder as string} style={inp} onFocus={focus} onBlur={blur} />
                    </div>
                  ))}
                  <div>
                    <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "#78726A", marginBottom: "6px", letterSpacing: "0.04em" }}>PASSWORD</label>
                    <input type="password" value={signupPw} onChange={e => setSignupPw(e.target.value)} placeholder="Minimum 8 characters" style={inp} onFocus={focus} onBlur={blur} />
                    <PasswordStrength password={signupPw} />
                  </div>
                </div>
              )}

              {/* Step 2: Verification */}
              {step === 2 && (
                <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
                  <div>
                    <p style={{ fontSize: "13px", fontWeight: 600, color: "#1A1714", marginBottom: "8px" }}>1. Phone verification</p>
                    <p style={{ fontSize: "12px", color: "#78726A", marginBottom: "14px" }}>Enter the 6-digit code sent to {phone || "+1 (305) 555-0000"}</p>
                    <OTPInput onComplete={() => setOtpVerified(true)} />
                    {otpVerified && <p style={{ textAlign: "center", fontSize: "12px", color: "#0D7A52", marginTop: "8px", fontWeight: 600 }}>✓ Phone verified</p>}
                    <button type="button" style={{ width: "100%", marginTop: "10px", padding: "8px", background: "none", border: "1px solid #E8E4DC", borderRadius: "8px", fontSize: "12px", color: "#78726A", cursor: "pointer" }}>Resend code</button>
                  </div>
                  <div>
                    <p style={{ fontSize: "13px", fontWeight: 600, color: "#1A1714", marginBottom: "8px" }}>2. Government ID</p>
                    <p style={{ fontSize: "12px", color: "#78726A", marginBottom: "10px" }}>Required for lease agreement compliance. Securely encrypted.</p>
                    <div onClick={() => setIdUploaded(true)} style={{ padding: "20px", border: `2px dashed ${idUploaded ? "#0D7A52" : "#E8E4DC"}`, borderRadius: "8px", textAlign: "center", cursor: "pointer", background: idUploaded ? "rgba(13,122,82,0.04)" : "#FAFAF7", transition: "all 0.2s" }}>
                      {idUploaded ? <><p style={{ fontSize: "20px" }}>✅</p><p style={{ fontSize: "13px", color: "#0D7A52", fontWeight: 600 }}>ID uploaded successfully</p></> : <><p style={{ fontSize: "24px", marginBottom: "6px" }}>📎</p><p style={{ fontSize: "13px", color: "#78726A" }}>Click to upload Passport, Driver's License, or National ID</p><p style={{ fontSize: "11px", color: "#A89E96", marginTop: "4px" }}>PDF, JPG, PNG · Max 10MB</p></>}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Preferences */}
              {step === 3 && (
                <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
                  <div>
                    <p style={{ fontSize: "11px", fontWeight: 700, color: "#A89E96", letterSpacing: "0.06em", marginBottom: "10px" }}>PREFERRED PROPERTY TYPES</p>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "7px" }}>
                      {PROPERTY_TYPES.map(t => {
                        const on = prefTypes.includes(t);
                        return (
                          <button key={t} type="button" onClick={() => setPrefTypes(p => on ? p.filter(x => x !== t) : [...p, t])} style={{ padding: "6px 14px", border: `1px solid ${on ? "#B8832A" : "#E8E4DC"}`, borderRadius: "100px", background: on ? "rgba(184,131,42,0.1)" : "#fff", color: on ? "#B8832A" : "#78726A", fontSize: "13px", fontWeight: on ? 600 : 400, cursor: "pointer", transition: "all 0.15s" }}>
                            {t}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div>
                    <p style={{ fontSize: "11px", fontWeight: 700, color: "#A89E96", letterSpacing: "0.06em", marginBottom: "10px" }}>BUDGET RANGE</p>
                    <div style={{ display: "flex", gap: "10px" }}>
                      <select value={budgetMin} onChange={e => setBudgetMin(Number(e.target.value))} style={{ ...inp, flex: 1, cursor: "pointer" }} onFocus={focus} onBlur={blur}>
                        {[250_000, 500_000, 1_000_000, 2_000_000, 3_000_000].map(v => <option key={v} value={v}>${(v / 1_000_000).toFixed(1)}M min</option>)}
                      </select>
                      <select value={budgetMax} onChange={e => setBudgetMax(Number(e.target.value))} style={{ ...inp, flex: 1, cursor: "pointer" }} onFocus={focus} onBlur={blur}>
                        {[2_000_000, 5_000_000, 8_000_000, 15_000_000].map(v => <option key={v} value={v}>${(v / 1_000_000).toFixed(0)}M max</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <p style={{ fontSize: "11px", fontWeight: 700, color: "#A89E96", letterSpacing: "0.06em", marginBottom: "10px" }}>PREFERRED LOCATIONS</p>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "7px" }}>
                      {LOCATION_TAGS.map(l => {
                        const on = locations.includes(l);
                        return (
                          <button key={l} type="button" onClick={() => setLocations(p => on ? p.filter(x => x !== l) : [...p, l])} style={{ padding: "5px 12px", border: `1px solid ${on ? "#0D7A52" : "#E8E4DC"}`, borderRadius: "100px", background: on ? "rgba(13,122,82,0.08)" : "#fff", color: on ? "#0D7A52" : "#78726A", fontSize: "12.5px", fontWeight: on ? 600 : 400, cursor: "pointer", transition: "all 0.15s" }}>
                            {l}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              <button type="button" onClick={handleSignupNext} disabled={loading} style={{ marginTop: "22px", padding: "12px", background: loading ? "#D4CFC5" : "#B8832A", border: "none", borderRadius: "8px", color: "#fff", fontSize: "14px", fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", fontFamily: "Plus Jakarta Sans, sans-serif", transition: "background 0.15s" }}>
                {loading ? "Creating account…" : step < 3 ? "Continue →" : "Complete Setup →"}
              </button>

              <div style={{ textAlign: "center", marginTop: "14px", paddingTop: "14px", borderTop: "1px solid #E8E4DC" }}>
                <span style={{ fontSize: "13px", color: "#78726A" }}>Already have an account? </span>
                <button type="button" onClick={() => setMode("login")} style={{ background: "none", border: "none", cursor: "pointer", fontSize: "13px", color: "#B8832A", fontWeight: 600 }}>Sign in</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
