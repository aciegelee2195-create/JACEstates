import { useState } from "react";
import { useCustomerAuth } from "../../contexts/CustomerAuthContext";
import { fmtPrice } from "../../data/buildingData";
import type { Unit } from "../../data/buildingData";

interface Props { unit: Unit; onBack: () => void; onBooked: () => void; }

type CalendarDay = { date: string; day: number; available: boolean; selected: boolean; blocked: boolean };

const BOOKED_DATES = ["2026-09-05", "2026-09-06", "2026-09-07", "2026-09-18", "2026-09-19", "2026-09-20", "2026-09-21", "2026-09-22"];

function buildCalendar(year: number, month: number, checkIn: string | null, checkOut: string | null): CalendarDay[] {
  const days: CalendarDay[] = [];
  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  for (let d = 1; d <= last.getDate(); d++) {
    const dt = new Date(year, month, d);
    const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    const blocked = BOOKED_DATES.includes(dateStr) || dt < today;
    const selected = !blocked && !!checkIn && !!checkOut && dateStr >= checkIn && dateStr <= checkOut;
    days.push({ date: dateStr, day: d, available: !blocked, selected, blocked });
  }
  return days;
}

const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const DAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function dateDiff(a: string, b: string): number {
  return Math.round((new Date(b).getTime() - new Date(a).getTime()) / (1000 * 60 * 60 * 24));
}

const FEATURES = {
  Studio:    ["Smart home controls", "Concierge service", "Rooftop pool access", "Gym & spa"],
  "1BR":     ["Smart home controls", "Concierge service", "Rooftop pool access", "Gym & spa", "Covered parking"],
  "2BR":     ["Smart home controls", "Concierge service", "Rooftop pool access", "Gym & spa", "Covered parking", "Private terrace"],
  "3BR":     ["Smart home controls", "Concierge service", "Private pool access", "Gym & spa", "Two parking spaces", "Private terrace", "Wine storage"],
  Penthouse: ["Smart home controls", "24/7 dedicated concierge", "Private infinity pool", "Private gym", "Three parking spaces", "Wraparound terrace", "Wine cellar", "Home theater"],
};

export default function PropertyDetail({ unit, onBack, onBooked }: Props) {
  const { makeReservation, customer } = useCustomerAuth();
  const now = new Date();
  const [calYear, setCalYear] = useState(now.getFullYear());
  const [calMonth, setCalMonth] = useState(now.getMonth());
  const [checkIn, setCheckIn] = useState<string | null>(null);
  const [checkOut, setCheckOut] = useState<string | null>(null);
  const [activeImg, setActiveImg] = useState(0);
  const [bookingMode, setBookingMode] = useState<"stay" | "tour" | null>(null);
  const [confirmLoading, setConfirmLoading] = useState(false);

  const firstDay = new Date(calYear, calMonth, 1).getDay();
  const days = buildCalendar(calYear, calMonth, checkIn, checkOut);
  const nights = checkIn && checkOut ? dateDiff(checkIn, checkOut) : 0;

  const nightlyRate = Math.round(unit.monthlyRent / 30);
  const cleaningFee = 150;
  const serviceFee = nights > 0 ? Math.round(nightlyRate * nights * 0.12) : 0;
  const securityDeposit = 500;
  const total = nightlyRate * nights + cleaningFee + serviceFee + securityDeposit;

  function handleDayClick(day: CalendarDay) {
    if (day.blocked) return;
    if (!checkIn || (checkIn && checkOut)) {
      setCheckIn(day.date); setCheckOut(null);
    } else {
      if (day.date > checkIn) setCheckOut(day.date);
      else { setCheckIn(day.date); setCheckOut(null); }
    }
  }

  function prevMonth() {
    if (calMonth === 0) { setCalYear(y => y - 1); setCalMonth(11); }
    else setCalMonth(m => m - 1);
  }
  function nextMonth() {
    if (calMonth === 11) { setCalYear(y => y + 1); setCalMonth(0); }
    else setCalMonth(m => m + 1);
  }

  function handleBook() {
    if (!checkIn || !checkOut || nights < 1) return;
    setConfirmLoading(true);
    setTimeout(() => {
      makeReservation({
        unitId: unit.id, propertyName: "Meridian Residences",
        propertyAddress: `301 Meridian Tower, Unit ${unit.id}, Miami FL 33131`,
        floor: unit.floor, unitType: unit.type, img: unit.img,
        checkIn, checkOut, nights, baseRate: nightlyRate,
      });
      onBooked();
    }, 1000);
  }

  const IMGS = [unit.img, "photo-1600585154340-be6161a56a0c", "photo-1560448204-603b3fc33ddc", "photo-1502672260266-1c1ef2d93688"];
  const features = FEATURES[unit.type as keyof typeof FEATURES] ?? FEATURES["2BR"];

  return (
    <div data-portal="client" style={{ background: "var(--cp-bg)", minHeight: "100vh", color: "var(--cp-text)", fontFamily: "Inter, sans-serif" }}>
      <div style={{ maxWidth: "1180px", margin: "0 auto", padding: "24px 32px 60px" }}>
        <button onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: "6px", background: "none", border: "none", cursor: "pointer", fontSize: "13px", color: "var(--cp-text-muted)", marginBottom: "20px", padding: 0 }}>← All properties</button>

        {/* Image gallery */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 260px", gap: "8px", height: "380px", marginBottom: "32px", borderRadius: "14px", overflow: "hidden" }}>
          <div style={{ background: "#E8E4DC", position: "relative" }}>
            <img src={`https://images.unsplash.com/${IMGS[activeImg]}?w=900&h=600&fit=crop&auto=format`} alt="Unit interior"
              style={{ width: "100%", height: "100%", objectFit: "cover", transition: "opacity 0.3s" }} />
            <div style={{ position: "absolute", bottom: "14px", left: "14px", display: "flex", gap: "6px" }}>
              {IMGS.map((_, i) => (
                <button key={i} onClick={() => setActiveImg(i)} style={{ width: "8px", height: "8px", borderRadius: "50%", border: "none", background: i === activeImg ? "#FAF8F5" : "rgba(250,248,245,0.4)", cursor: "pointer", padding: 0, transition: "background 0.15s" }} />
              ))}
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateRows: "1fr 1fr", gap: "8px" }}>
            {IMGS.slice(1, 3).map((img, i) => (
              <div key={i} style={{ background: "#E8E4DC", cursor: "pointer" }} onClick={() => setActiveImg(i + 1)}>
                <img src={`https://images.unsplash.com/${img}?w=400&h=240&fit=crop&auto=format`} alt={`Interior ${i + 2}`} style={{ width: "100%", height: "100%", objectFit: "cover", opacity: activeImg === i + 1 ? 0.85 : 1, transition: "opacity 0.15s" }} />
              </div>
            ))}
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: "32px", alignItems: "start" }}>
          {/* Left column */}
          <div>
            <div style={{ marginBottom: "24px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                <h1 style={{ fontSize: "32px", fontWeight: 400, color: "var(--cp-text)", fontFamily: "Instrument Serif, serif", letterSpacing: "-0.01em" }}>
                  {unit.type} — Unit {unit.id}
                </h1>
                <span style={{ padding: "3px 10px", background: "rgba(13,122,82,0.1)", color: "#0D7A52", borderRadius: "100px", fontSize: "12px", fontWeight: 600, flexShrink: 0 }}>
                  {unit.status === "Available" ? "Available" : unit.status}
                </span>
              </div>
              <p style={{ fontSize: "14px", color: "var(--cp-text-muted)" }}>
                301 Meridian Tower · Floor {unit.floor} · Miami, FL 33131
              </p>
              <div style={{ display: "flex", gap: "16px", marginTop: "14px" }}>
                {[["🏙️", `${unit.sqft.toLocaleString()} sqft`], ["🧭", `${unit.orientation} facing`], ["🌅", unit.view], ["📍", `Floor ${unit.floor}`]].map(([icon, label]) => (
                  <div key={label as string} style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                    <span style={{ fontSize: "14px" }}>{icon}</span>
                    <span style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>{label as string}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Description */}
            <div style={{ paddingBottom: "24px", borderBottom: "1px solid var(--cp-border)", marginBottom: "24px" }}>
              <h3 style={{ fontSize: "18px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "10px" }}>About this residence</h3>
              <p style={{ fontSize: "14px", color: "var(--cp-text-muted)", lineHeight: 1.7 }}>
                This exquisite {unit.type} residence on the {unit.floor}{unit.floor === 1 ? "st" : unit.floor === 2 ? "nd" : unit.floor === 3 ? "rd" : "th"} floor of Meridian Tower offers unparalleled {unit.view.toLowerCase()} across the Miami skyline. Designed by award-winning architects, every detail reflects the highest standard of luxury living. The residence features floor-to-ceiling glass, premium Italian-imported finishes, and integrated smart home technology throughout.
              </p>
            </div>

            {/* Features */}
            <div style={{ paddingBottom: "24px", borderBottom: "1px solid var(--cp-border)", marginBottom: "24px" }}>
              <h3 style={{ fontSize: "18px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "14px" }}>What's included</h3>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
                {features.map(f => (
                  <div key={f} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <span style={{ color: "#0D7A52", fontSize: "12px" }}>✓</span>
                    <span style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>{f}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Availability Calendar */}
            <div>
              <h3 style={{ fontSize: "18px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "16px" }}>Live availability</h3>
              <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px" }}>
                {/* Month navigation */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
                  <button onClick={prevMonth} style={{ width: "32px", height: "32px", border: "1px solid var(--cp-border)", borderRadius: "8px", background: "none", cursor: "pointer", fontSize: "16px", color: "var(--cp-text-muted)", display: "flex", alignItems: "center", justifyContent: "center" }}>‹</button>
                  <p style={{ fontSize: "15px", fontWeight: 600, color: "var(--cp-text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{MONTH_NAMES[calMonth]} {calYear}</p>
                  <button onClick={nextMonth} style={{ width: "32px", height: "32px", border: "1px solid var(--cp-border)", borderRadius: "8px", background: "none", cursor: "pointer", fontSize: "16px", color: "var(--cp-text-muted)", display: "flex", alignItems: "center", justifyContent: "center" }}>›</button>
                </div>

                {/* Day labels */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "2px", marginBottom: "6px" }}>
                  {DAY_LABELS.map(d => <div key={d} style={{ textAlign: "center", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-dim)", padding: "4px 0" }}>{d}</div>)}
                </div>

                {/* Day grid */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: "2px" }}>
                  {Array(firstDay).fill(null).map((_, i) => <div key={`empty-${i}`} />)}
                  {days.map(d => {
                    const isCheckIn = d.date === checkIn;
                    const isCheckOut = d.date === checkOut;
                    return (
                      <button key={d.date} onClick={() => handleDayClick(d)} disabled={d.blocked}
                        style={{
                          aspectRatio: "1", border: "none", borderRadius: "8px", cursor: d.blocked ? "default" : "pointer", fontSize: "13px",
                          background: isCheckIn || isCheckOut ? "#1A1714" : d.selected ? "rgba(13,122,82,0.12)" : d.blocked ? "transparent" : "transparent",
                          color: isCheckIn || isCheckOut ? "#FAF8F5" : d.blocked ? "var(--cp-text-dim)" : "var(--cp-text)",
                          fontWeight: isCheckIn || isCheckOut ? 700 : 400,
                          textDecoration: d.blocked && !d.available ? "line-through" : "none",
                          opacity: d.blocked ? 0.4 : 1,
                          transition: "all 0.1s",
                          outline: d.selected ? "1px solid rgba(13,122,82,0.3)" : "none",
                          outlineOffset: "1px",
                        }}
                        onMouseEnter={e => { if (!d.blocked) (e.currentTarget.style.background = "var(--cp-bg)"); }}
                        onMouseLeave={e => { if (!d.blocked) (e.currentTarget.style.background = isCheckIn || isCheckOut ? "#1A1714" : d.selected ? "rgba(13,122,82,0.12)" : "transparent"); }}
                      >
                        {d.day}
                      </button>
                    );
                  })}
                </div>

                {/* Legend */}
                <div style={{ display: "flex", gap: "14px", marginTop: "14px", paddingTop: "12px", borderTop: "1px solid var(--cp-border)" }}>
                  {[["var(--cp-text)", "Available"], ["rgba(13,122,82,0.15)", "Selected"], ["#E8E4DC", "Booked"]].map(([bg, label]) => (
                    <div key={label} style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                      <div style={{ width: "12px", height: "12px", borderRadius: "3px", background: bg, border: "1px solid var(--cp-border)" }} />
                      <span style={{ fontSize: "11px", color: "var(--cp-text-muted)" }}>{label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right column — booking card */}
          <div style={{ position: "sticky", top: "88px" }}>
            <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "14px", padding: "24px", boxShadow: "var(--cp-shadow-md)" }}>
              <div style={{ marginBottom: "16px" }}>
                <div style={{ display: "flex", alignItems: "baseline", gap: "6px", marginBottom: "2px" }}>
                  <span style={{ fontSize: "26px", fontWeight: 800, color: "var(--cp-text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>${nightlyRate.toLocaleString()}</span>
                  <span style={{ fontSize: "14px", color: "var(--cp-text-muted)" }}>/night</span>
                </div>
                <p style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>or {fmtPrice(unit.price)} purchase price</p>
              </div>

              {/* Date display */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", marginBottom: "14px" }}>
                {[["CHECK-IN", checkIn], ["CHECK-OUT", checkOut]].map(([label, val]) => (
                  <div key={label as string} style={{ padding: "10px 12px", border: "1px solid var(--cp-border)", borderRadius: "8px", background: val ? "rgba(13,122,82,0.04)" : "var(--cp-bg)", borderColor: val ? "rgba(13,122,82,0.3)" : "var(--cp-border)" }}>
                    <p style={{ fontSize: "10px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "3px" }}>{label as string}</p>
                    <p style={{ fontSize: "13px", fontWeight: val ? 600 : 400, color: val ? "var(--cp-text)" : "var(--cp-text-dim)" }}>
                      {val ? new Date(val + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "Select"}
                    </p>
                  </div>
                ))}
              </div>

              {/* Price breakdown */}
              {nights > 0 && (
                <div style={{ background: "var(--cp-bg)", borderRadius: "10px", padding: "14px", marginBottom: "14px", border: "1px solid var(--cp-border)" }}>
                  <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "10px" }}>PRICE BREAKDOWN</p>
                  {[
                    [`$${nightlyRate.toLocaleString()} × ${nights} nights`, nightlyRate * nights],
                    ["Cleaning fee", cleaningFee],
                    ["Service fee (12%)", serviceFee],
                    ["Security deposit (refundable)", securityDeposit],
                  ].map(([label, val]) => (
                    <div key={label as string} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: "1px solid var(--cp-border)" }}>
                      <span style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>{label as string}</span>
                      <span style={{ fontSize: "13px", color: "var(--cp-text)" }}>${(val as number).toLocaleString()}</span>
                    </div>
                  ))}
                  <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 0 0" }}>
                    <span style={{ fontSize: "14px", fontWeight: 700, color: "var(--cp-text)" }}>Total</span>
                    <span style={{ fontSize: "14px", fontWeight: 800, color: "var(--cp-text)", fontFamily: "JetBrains Mono, monospace" }}>${total.toLocaleString()}</span>
                  </div>
                </div>
              )}

              {/* CTAs */}
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                <button
                  onClick={handleBook}
                  disabled={!checkIn || !checkOut || nights < 1 || confirmLoading || !customer}
                  style={{ padding: "13px", background: (checkIn && checkOut && nights > 0 && customer) ? "#1A1714" : "var(--cp-border)", border: "none", borderRadius: "8px", fontSize: "14px", fontWeight: 700, color: (checkIn && checkOut && nights > 0 && customer) ? "#FAF8F5" : "var(--cp-text-dim)", cursor: (checkIn && checkOut && nights > 0 && customer) ? "pointer" : "not-allowed", fontFamily: "Plus Jakarta Sans, sans-serif", transition: "all 0.15s" }}>
                  {confirmLoading ? "Reserving…" : "Reserve Now →"}
                </button>
                <button
                  onClick={() => setBookingMode("tour")}
                  style={{ padding: "11px", background: "none", border: "1px solid var(--cp-border-strong)", borderRadius: "8px", fontSize: "14px", fontWeight: 500, color: "var(--cp-text-2)", cursor: "pointer", transition: "all 0.15s" }}>
                  Schedule a Tour
                </button>
              </div>
              {!customer && <p style={{ fontSize: "11px", color: "#B45309", marginTop: "8px", textAlign: "center" }}>Sign in to make a reservation</p>}
              {!checkIn && <p style={{ fontSize: "11px", color: "var(--cp-text-muted)", marginTop: "8px", textAlign: "center" }}>Select check-in and check-out dates above</p>}

              {/* Tour booked confirmation */}
              {bookingMode === "tour" && (
                <div style={{ marginTop: "12px", padding: "12px 14px", background: "rgba(13,122,82,0.08)", border: "1px solid rgba(13,122,82,0.2)", borderRadius: "8px" }}>
                  <p style={{ fontSize: "13px", color: "#0D7A52", fontWeight: 600, marginBottom: "2px" }}>✓ Tour request sent</p>
                  <p style={{ fontSize: "11px", color: "var(--cp-text-muted)" }}>Your agent will confirm within 2 hours at your registered email.</p>
                </div>
              )}

              <p style={{ fontSize: "11px", color: "var(--cp-text-dim)", textAlign: "center", marginTop: "12px" }}>Free cancellation up to 48h before check-in</p>
            </div>

            {/* Quick stats */}
            <div style={{ marginTop: "12px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
              {[["4.8★", "Avg rating", "#B8832A"], ["98%", "Check-in rate", "#0D7A52"]].map(([v, l, c]) => (
                <div key={l} style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "10px", padding: "12px", textAlign: "center" }}>
                  <p style={{ fontSize: "18px", fontWeight: 700, color: c, fontFamily: "JetBrains Mono, monospace" }}>{v}</p>
                  <p style={{ fontSize: "11px", color: "var(--cp-text-muted)", marginTop: "2px" }}>{l}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
