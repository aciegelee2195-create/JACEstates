import { useState } from "react";
import { useBooking } from "../../contexts/BookingContext";
import { fmtPrice } from "../../data/buildingData";
import type { Unit } from "../../data/buildingData";

interface Props { onSelectUnit: (unit: Unit) => void; }

const TYPES = ["All", "Studio", "1BR", "2BR", "3BR", "Penthouse"];
const SORT_OPTS = ["Price: Low to High", "Price: High to Low", "Newest Floor", "Best Rated"];

const STAR_RATINGS: Record<string, number> = {
  Studio: 4.6, "1BR": 4.7, "2BR": 4.8, "3BR": 4.9, Penthouse: 5.0,
};

const REVIEW_COUNTS: Record<string, number> = {
  Studio: 34, "1BR": 58, "2BR": 71, "3BR": 29, Penthouse: 8,
};

function Stars({ rating }: { rating: number }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "2px" }}>
      {[1, 2, 3, 4, 5].map(i => (
        <svg key={i} width="11" height="11" viewBox="0 0 12 12">
          <polygon points="6,1 7.8,4.2 11.4,4.7 8.7,7.3 9.4,11 6,9.3 2.6,11 3.3,7.3 0.6,4.7 4.2,4.2"
            fill={i <= Math.floor(rating) ? "#B8832A" : i - 0.5 <= rating ? "url(#half)" : "#E8E4DC"}
            stroke="none" />
        </svg>
      ))}
    </div>
  );
}

export default function PropertyDirectory({ onSelectUnit }: Props) {
  const { units } = useBooking();
  const [typeFilter, setTypeFilter] = useState("All");
  const [sortBy, setSortBy] = useState(SORT_OPTS[0]);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [showAvailableOnly, setShowAvailableOnly] = useState(false);
  const [query, setQuery] = useState("");

  let filtered = units.filter(u =>
    (typeFilter === "All" || u.type === typeFilter) &&
    (!showAvailableOnly || u.status === "Available") &&
    (query === "" || u.id.toLowerCase().includes(query.toLowerCase()) || u.type.toLowerCase().includes(query.toLowerCase()) || u.view.toLowerCase().includes(query.toLowerCase()))
  );

  filtered = [...filtered].sort((a, b) => {
    if (sortBy === "Price: Low to High") return a.price - b.price;
    if (sortBy === "Price: High to Low") return b.price - a.price;
    if (sortBy === "Newest Floor") return b.floor - a.floor;
    return (STAR_RATINGS[b.type] ?? 4.5) - (STAR_RATINGS[a.type] ?? 4.5);
  });

  const STATUS_COLORS: Record<string, { bg: string; color: string; label: string }> = {
    Available: { bg: "rgba(13,122,82,0.1)", color: "#0D7A52", label: "Available" },
    Held:      { bg: "rgba(180,83,9,0.1)",  color: "#B45309", label: "On Hold" },
    Reserved:  { bg: "rgba(109,40,217,0.1)", color: "#6D28D9", label: "Reserved" },
    Sold:      { bg: "rgba(100,116,139,0.1)", color: "#64748B", label: "Sold" },
  };

  const nightlyRate = (u: Unit) => Math.round(u.monthlyRent / 30);

  return (
    <div data-portal="client" style={{ minHeight: "100vh", background: "var(--cp-bg)", color: "var(--cp-text)", fontFamily: "Inter, sans-serif" }}>
      {/* Hero search bar */}
      <div style={{ background: "#1A1714", padding: "40px 32px 44px" }}>
        <div style={{ maxWidth: "820px", margin: "0 auto", textAlign: "center" }}>
          <h2 style={{ fontSize: "34px", fontWeight: 400, color: "#FAF8F5", fontFamily: "Instrument Serif, serif", marginBottom: "6px" }}>Find your <em>perfect residence</em></h2>
          <p style={{ fontSize: "14px", color: "rgba(250,248,245,0.6)", marginBottom: "22px" }}>Meridian Residences · {units.filter(u => u.status === "Available").length} units available now</p>
          <div style={{ display: "flex", gap: "10px", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "12px", padding: "8px" }}>
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search by unit, type, view, or floor…"
              style={{ flex: 1, padding: "10px 14px", background: "#fff", border: "none", borderRadius: "8px", fontSize: "14px", color: "#1A1714", outline: "none", fontFamily: "Inter, sans-serif" }} />
            <button style={{ padding: "10px 24px", background: "#B8832A", border: "none", borderRadius: "8px", color: "#fff", fontSize: "14px", fontWeight: 700, cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>Search</button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: "1280px", margin: "0 auto", padding: "28px 32px" }}>
        {/* Filters row */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "20px", flexWrap: "wrap", gap: "10px" }}>
          <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
            {TYPES.map(t => {
              const on = typeFilter === t;
              return (
                <button key={t} onClick={() => setTypeFilter(t)} style={{ padding: "6px 14px", border: `1px solid ${on ? "#B8832A" : "var(--cp-border)"}`, borderRadius: "100px", background: on ? "rgba(184,131,42,0.1)" : "var(--cp-card)", color: on ? "#B8832A" : "var(--cp-text-muted)", fontSize: "13px", fontWeight: on ? 600 : 400, cursor: "pointer", transition: "all 0.15s" }}>
                  {t}
                </button>
              );
            })}
            <label style={{ display: "flex", alignItems: "center", gap: "6px", padding: "6px 14px", border: `1px solid ${showAvailableOnly ? "#0D7A52" : "var(--cp-border)"}`, borderRadius: "100px", cursor: "pointer", background: showAvailableOnly ? "rgba(13,122,82,0.08)" : "var(--cp-card)", color: showAvailableOnly ? "#0D7A52" : "var(--cp-text-muted)", fontSize: "13px", fontWeight: showAvailableOnly ? 600 : 400 }}>
              <input type="checkbox" checked={showAvailableOnly} onChange={e => setShowAvailableOnly(e.target.checked)} style={{ accentColor: "#0D7A52", margin: 0 }} /> Available only
            </label>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ padding: "7px 12px", border: "1px solid var(--cp-border)", borderRadius: "8px", background: "var(--cp-card)", color: "var(--cp-text)", fontSize: "13px", outline: "none", cursor: "pointer" }}>
              {SORT_OPTS.map(o => <option key={o}>{o}</option>)}
            </select>
            <div style={{ display: "flex", border: "1px solid var(--cp-border)", borderRadius: "8px", overflow: "hidden" }}>
              {(["grid", "list"] as const).map(v => (
                <button key={v} onClick={() => setViewMode(v)} style={{ padding: "7px 12px", border: "none", background: viewMode === v ? "#1A1714" : "var(--cp-card)", color: viewMode === v ? "#fff" : "var(--cp-text-muted)", cursor: "pointer", fontSize: "13px" }}>
                  {v === "grid" ? "⊞" : "☰"}
                </button>
              ))}
            </div>
          </div>
        </div>

        <p style={{ fontSize: "13px", color: "var(--cp-text-muted)", marginBottom: "16px" }}>
          <strong style={{ color: "var(--cp-text)" }}>{filtered.length}</strong> properties found
        </p>

        {/* Grid */}
        {viewMode === "grid" ? (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "20px" }}>
            {filtered.slice(0, 24).map(u => {
              const sc = STATUS_COLORS[u.status];
              const rating = STAR_RATINGS[u.type] ?? 4.5;
              const reviews = REVIEW_COUNTS[u.type] ?? 20;
              const nightly = nightlyRate(u);
              const avail = u.status === "Available";
              return (
                <div key={u.id} onClick={() => avail && onSelectUnit(u)}
                  style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", overflow: "hidden", cursor: avail ? "pointer" : "default", transition: "all 0.2s", boxShadow: "var(--cp-shadow)" }}
                  onMouseEnter={e => avail && Object.assign((e.currentTarget as HTMLElement).style, { boxShadow: "var(--cp-shadow-md)", borderColor: "var(--cp-border-strong)", transform: "translateY(-2px)" })}
                  onMouseLeave={e => avail && Object.assign((e.currentTarget as HTMLElement).style, { boxShadow: "var(--cp-shadow)", borderColor: "var(--cp-border)", transform: "none" })}
                >
                  <div style={{ height: "200px", position: "relative", background: "#E8E4DC", overflow: "hidden" }}>
                    <img src={`https://images.unsplash.com/${u.img}?w=600&h=350&fit=crop&auto=format`} alt={`Unit ${u.id}`}
                      style={{ width: "100%", height: "100%", objectFit: "cover", filter: !avail ? "grayscale(50%)" : "none", transition: "transform 0.3s" }} />
                    <div style={{ position: "absolute", top: "10px", left: "10px" }}>
                      <span style={{ padding: "3px 9px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, background: sc.bg, color: sc.color, backdropFilter: "blur(8px)" }}>{sc.label}</span>
                    </div>
                    <div style={{ position: "absolute", bottom: "10px", right: "10px", padding: "4px 8px", background: "rgba(26,23,20,0.65)", borderRadius: "6px", fontSize: "11px", color: "#FAF8F5", fontFamily: "JetBrains Mono, monospace" }}>
                      Floor {u.floor}
                    </div>
                  </div>
                  <div style={{ padding: "16px 18px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "4px" }}>
                      <h3 style={{ fontSize: "17px", fontWeight: 400, color: "var(--cp-text)", fontFamily: "Instrument Serif, serif" }}>{u.type} — Unit {u.id}</h3>
                      <p style={{ fontSize: "16px", fontWeight: 700, color: avail ? "var(--cp-text)" : "var(--cp-text-dim)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{fmtPrice(u.price)}</p>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "8px" }}>
                      <Stars rating={rating} />
                      <span style={{ fontSize: "12px", color: "var(--cp-text-muted)" }}>{rating.toFixed(1)} ({reviews} reviews)</span>
                    </div>
                    <p style={{ fontSize: "12px", color: "var(--cp-text-muted)", marginBottom: "10px", lineHeight: 1.4 }}>{u.view}</p>
                    <div style={{ display: "flex", gap: "6px", flexWrap: "wrap", marginBottom: "14px" }}>
                      <span style={{ fontSize: "11px", padding: "2px 8px", background: "var(--cp-gold-dim)", color: "var(--cp-gold)", borderRadius: "4px", fontWeight: 600 }}>{u.sqft.toLocaleString()} sqft</span>
                      <span style={{ fontSize: "11px", padding: "2px 8px", background: "var(--cp-bg)", border: "1px solid var(--cp-border)", color: "var(--cp-text-muted)", borderRadius: "4px" }}>{u.orientation} facing</span>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: "12px", borderTop: "1px solid var(--cp-border)" }}>
                      <div>
                        <span style={{ fontSize: "15px", fontWeight: 700, color: "var(--cp-gold)" }}>${nightly.toLocaleString()}</span>
                        <span style={{ fontSize: "12px", color: "var(--cp-text-muted)" }}>/night</span>
                        <span style={{ fontSize: "11px", color: "var(--cp-text-dim)", marginLeft: "8px" }}>or ${u.monthlyRent.toLocaleString()}/mo</span>
                      </div>
                      {avail ? (
                        <button onClick={e => { e.stopPropagation(); onSelectUnit(u); }} style={{ padding: "7px 14px", background: "#1A1714", border: "none", borderRadius: "8px", color: "#FAF8F5", fontSize: "12px", fontWeight: 600, cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
                          View →
                        </button>
                      ) : (
                        <span style={{ fontSize: "12px", color: "var(--cp-text-dim)", fontStyle: "italic" }}>Unavailable</span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* List view */
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            {filtered.slice(0, 24).map(u => {
              const sc = STATUS_COLORS[u.status];
              const rating = STAR_RATINGS[u.type] ?? 4.5;
              const avail = u.status === "Available";
              const nightly = nightlyRate(u);
              return (
                <div key={u.id} onClick={() => avail && onSelectUnit(u)}
                  style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "10px", display: "flex", gap: "0", overflow: "hidden", cursor: avail ? "pointer" : "default", transition: "all 0.15s" }}
                  onMouseEnter={e => avail && ((e.currentTarget as HTMLElement).style.borderColor = "var(--cp-border-strong)")}
                  onMouseLeave={e => ((e.currentTarget as HTMLElement).style.borderColor = "var(--cp-border)")}
                >
                  <div style={{ width: "160px", flexShrink: 0, background: "#E8E4DC" }}>
                    <img src={`https://images.unsplash.com/${u.img}?w=320&h=200&fit=crop&auto=format`} alt={`Unit ${u.id}`} style={{ width: "100%", height: "100%", objectFit: "cover", filter: !avail ? "grayscale(50%)" : "none" }} />
                  </div>
                  <div style={{ flex: 1, padding: "16px 18px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                        <h3 style={{ fontSize: "16px", fontWeight: 400, color: "var(--cp-text)", fontFamily: "Instrument Serif, serif" }}>{u.type} · Unit {u.id}</h3>
                        <span style={{ padding: "2px 8px", borderRadius: "100px", fontSize: "10px", fontWeight: 600, background: sc.bg, color: sc.color }}>{sc.label}</span>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
                        <Stars rating={rating} /><span style={{ fontSize: "11px", color: "var(--cp-text-muted)" }}>{rating.toFixed(1)}</span>
                      </div>
                      <p style={{ fontSize: "12px", color: "var(--cp-text-muted)" }}>Floor {u.floor} · {u.sqft.toLocaleString()} sqft · {u.orientation} facing · {u.view}</p>
                    </div>
                    <div style={{ textAlign: "right", flexShrink: 0, paddingLeft: "20px" }}>
                      <p style={{ fontSize: "18px", fontWeight: 700, color: "var(--cp-text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{fmtPrice(u.price)}</p>
                      <p style={{ fontSize: "12px", color: "var(--cp-gold)", fontWeight: 600 }}>${nightly}/night</p>
                      {avail && <button style={{ marginTop: "8px", padding: "6px 14px", background: "#1A1714", border: "none", borderRadius: "7px", color: "#FAF8F5", fontSize: "12px", fontWeight: 600, cursor: "pointer" }}>View Details →</button>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {filtered.length === 0 && (
          <div style={{ padding: "60px", textAlign: "center" }}>
            <p style={{ fontSize: "28px", marginBottom: "10px" }}>🔍</p>
            <h3 style={{ fontSize: "20px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "6px" }}>No properties found</h3>
            <p style={{ fontSize: "14px", color: "var(--cp-text-muted)" }}>Try adjusting your filters or search query.</p>
          </div>
        )}
      </div>
    </div>
  );
}
