import { useState } from "react";
import { useCustomerAuth, type Reservation } from "../../contexts/CustomerAuthContext";
import CustomerAuth from "./CustomerAuth";
import PropertyDirectory from "./PropertyDirectory";
import PropertyDetail from "./PropertyDetail";
import MyStays from "./MyStays";
import SelfCheckout from "./SelfCheckout";
import type { Unit } from "../../data/buildingData";

type CustomerView = "browse" | "detail" | "stays" | "checkout";

interface Props { onSwitchPortal: () => void; }

export default function CustomerApp({ onSwitchPortal }: Props) {
  const { customer, logout, reservations } = useCustomerAuth();
  const [view, setView] = useState<CustomerView>("browse");
  const [selectedUnit, setSelectedUnit] = useState<Unit | null>(null);
  const [checkoutRes, setCheckoutRes] = useState<Reservation | null>(null);
  const [showAuth, setShowAuth] = useState(!customer);

  const upcomingCount = reservations.filter(r => r.status === "upcoming" || r.status === "active").length;

  function handleAuthSuccess() { setShowAuth(false); }

  function handleUnitSelect(unit: Unit) {
    setSelectedUnit(unit);
    setView("detail");
  }

  function handleBooked() {
    setView("stays");
  }

  function handleCheckout(res: Reservation) {
    setCheckoutRes(res);
    setView("checkout");
  }

  const navLink = (id: CustomerView, label: string, badge?: number): React.CSSProperties => ({
    background: "none", border: "none", cursor: "pointer", padding: "6px 2px",
    fontSize: "13.5px", fontWeight: view === id ? 600 : 400,
    color: view === id ? "#1A1714" : "#78726A",
    borderBottom: view === id ? "2px solid #B8832A" : "2px solid transparent",
    transition: "all 0.15s", fontFamily: "Inter, sans-serif", position: "relative",
  });

  if (showAuth || !customer) {
    return <CustomerAuth onSuccess={handleAuthSuccess} onBack={onSwitchPortal} />;
  }

  return (
    <div data-portal="client" style={{ minHeight: "100vh", background: "var(--cp-bg)", color: "var(--cp-text)" }}>
      {/* Header */}
      <header style={{ position: "sticky", top: 0, zIndex: 50, background: "rgba(250,250,247,0.94)", backdropFilter: "blur(12px)", borderBottom: "1px solid var(--cp-border)" }}>
        <div style={{ maxWidth: "1280px", margin: "0 auto", padding: "0 32px", height: "64px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          {/* Brand */}
          <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
            <button onClick={onSwitchPortal} style={{ display: "flex", alignItems: "center", gap: "8px", background: "none", border: "none", cursor: "pointer" }}>
              <div style={{ width: "30px", height: "30px", borderRadius: "7px", background: "#0D7A52", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <span style={{ color: "#fff", fontWeight: 800, fontSize: "13px", fontFamily: "Plus Jakarta Sans, sans-serif" }}>J</span>
              </div>
              <span style={{ fontSize: "16px", fontWeight: 400, color: "var(--cp-text)", fontFamily: "Instrument Serif, serif" }}>JACEstates</span>
            </button>
            <div style={{ height: "16px", width: "1px", background: "var(--cp-border-strong)" }} />
            <span style={{ fontSize: "12px", padding: "2px 8px", background: "rgba(184,131,42,0.1)", color: "#B8832A", borderRadius: "100px", fontWeight: 600, border: "1px solid rgba(184,131,42,0.2)" }}>Customer Portal</span>
          </div>

          {/* Nav */}
          <nav style={{ display: "flex", gap: "24px" }}>
            <button style={navLink("browse", "Browse Properties")} onClick={() => setView("browse")}>Browse Properties</button>
            <button style={{ ...navLink("stays", "My Stays"), position: "relative" }} onClick={() => setView("stays")}>
              My Stays
              {upcomingCount > 0 && (
                <span style={{ position: "absolute", top: "0", right: "-14px", width: "16px", height: "16px", background: "#B8832A", color: "#fff", borderRadius: "50%", fontSize: "9px", fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  {upcomingCount}
                </span>
              )}
            </button>
          </nav>

          {/* User menu */}
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", padding: "5px 12px", background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "8px" }}>
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: "#1A1714", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "10px", fontWeight: 700, color: "#FAF8F5", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
                {customer.name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()}
              </div>
              <span style={{ fontSize: "13px", color: "var(--cp-text)", fontWeight: 500 }}>{customer.name.split(" ")[0]}</span>
              {customer.verified && <span title="Verified" style={{ fontSize: "13px" }}>✓</span>}
            </div>
            <button onClick={() => { logout(); setShowAuth(true); }} style={{ padding: "6px 12px", background: "none", border: "1px solid var(--cp-border)", borderRadius: "8px", fontSize: "12px", color: "var(--cp-text-muted)", cursor: "pointer" }}>
              Sign out
            </button>
          </div>
        </div>
      </header>

      {/* View routing */}
      {view === "browse" && <PropertyDirectory onSelectUnit={handleUnitSelect} />}

      {view === "detail" && selectedUnit && (
        <PropertyDetail
          unit={selectedUnit}
          onBack={() => setView("browse")}
          onBooked={handleBooked}
        />
      )}

      {view === "stays" && (
        <MyStays onCheckout={handleCheckout} />
      )}

      {view === "checkout" && checkoutRes && (
        <SelfCheckout
          reservation={checkoutRes}
          onComplete={() => setView("stays")}
          onBack={() => setView("stays")}
        />
      )}
    </div>
  );
}
