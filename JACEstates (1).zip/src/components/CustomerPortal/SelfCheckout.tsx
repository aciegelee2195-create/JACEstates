import { useState } from "react";
import { useCustomerAuth, type Reservation } from "../../contexts/CustomerAuthContext";

interface Props { reservation: Reservation; onComplete: () => void; onBack: () => void; }

interface ChecklistItem { key: keyof { keysReturned: boolean; trashDisposed: boolean; lightsOff: boolean; acOff: boolean }; label: string; description: string; icon: string; }

const CHECKLIST: ChecklistItem[] = [
  { key: "keysReturned",  label: "Keys returned to lockbox", description: "Place all keys and access cards in the lobby lockbox (code 7734).", icon: "🔑" },
  { key: "trashDisposed", label: "Trash disposed",           description: "Empty all bins and leave trash bags in the designated chute area on your floor.", icon: "🗑️" },
  { key: "lightsOff",     label: "Lights & appliances off",  description: "Confirm all lights, TVs, and non-essential appliances are switched off.", icon: "💡" },
  { key: "acOff",         label: "AC & climate controls off", description: "Set thermostat to 78°F (eco mode) before departing. Smart home panel in the hallway.", icon: "❄️" },
];

function formatDate(s: string) {
  return new Date(s + "T12:00:00").toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });
}

export default function SelfCheckout({ reservation: res, onComplete, onBack }: Props) {
  const { updateCheckoutState, completeCheckout, startCheckout } = useCustomerAuth();
  const [started, setStarted] = useState(!!res.checkoutState);
  const [step, setStep] = useState<"checklist" | "damage" | "settlement" | "done">("checklist");
  const [damageNotes, setDamageNotes] = useState(res.checkoutState?.damageNotes ?? "");
  const [photoUploaded, setPhotoUploaded] = useState(res.checkoutState?.photoUploaded ?? false);
  const [submitting, setSubmitting] = useState(false);

  const state = res.checkoutState ?? { keysReturned: false, trashDisposed: false, lightsOff: false, acOff: false, damageNotes: "", photoUploaded: false, completedAt: null };
  const allChecked = state.keysReturned && state.trashDisposed && state.lightsOff && state.acOff;
  const nights = Math.round((new Date(res.checkOut + "T12:00:00").getTime() - new Date(res.checkIn + "T12:00:00").getTime()) / (1000 * 60 * 60 * 24));

  function beginCheckout() {
    startCheckout(res.id);
    setStarted(true);
  }

  function toggleItem(key: ChecklistItem["key"]) {
    updateCheckoutState(res.id, { [key]: !state[key] });
  }

  function proceedToDamage() {
    updateCheckoutState(res.id, { damageNotes });
    setStep("damage");
  }

  function proceedToSettlement() {
    updateCheckoutState(res.id, { damageNotes, photoUploaded });
    setStep("settlement");
  }

  function handleExpressCheckout() {
    setSubmitting(true);
    updateCheckoutState(res.id, { damageNotes, photoUploaded });
    setTimeout(() => {
      completeCheckout(res.id);
      setStep("done");
      setSubmitting(false);
    }, 1200);
  }

  const depositRefund = damageNotes.trim() ? 350 : 500;
  const hasDamage = !!damageNotes.trim();

  const inp: React.CSSProperties = {
    width: "100%", padding: "11px 13px", border: "1px solid var(--cp-border)", borderRadius: "8px",
    background: "var(--cp-card)", color: "var(--cp-text)", fontSize: "14px", outline: "none",
    fontFamily: "Inter, sans-serif", boxSizing: "border-box", resize: "vertical",
  };

  return (
    <div data-portal="client" style={{ minHeight: "100vh", background: "var(--cp-bg)", color: "var(--cp-text)", fontFamily: "Inter, sans-serif" }}>
      <div style={{ maxWidth: "680px", margin: "0 auto", padding: "32px" }}>
        <button onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: "6px", background: "none", border: "none", cursor: "pointer", fontSize: "13px", color: "var(--cp-text-muted)", marginBottom: "20px", padding: 0 }}>
          ← My Stays
        </button>

        {/* Property summary */}
        <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "18px 20px", marginBottom: "24px", display: "flex", gap: "14px" }}>
          <div style={{ width: "80px", height: "72px", borderRadius: "8px", overflow: "hidden", flexShrink: 0 }}>
            <img src={`https://images.unsplash.com/${res.img}?w=200&h=160&fit=crop&auto=format`} alt={res.propertyName} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
          <div>
            <h3 style={{ fontSize: "16px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "3px" }}>{res.propertyName} — {res.unitType}</h3>
            <p style={{ fontSize: "12px", color: "var(--cp-text-muted)", marginBottom: "6px" }}>Unit {res.unitId} · {res.propertyAddress.split(",")[1]?.trim()}</p>
            <div style={{ display: "flex", gap: "12px" }}>
              {[["Check-in", formatDate(res.checkIn)], ["Check-out", formatDate(res.checkOut)]].map(([l, v]) => (
                <div key={l}>
                  <p style={{ fontSize: "10px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.05em" }}>{l.toUpperCase()}</p>
                  <p style={{ fontSize: "12px", fontWeight: 500, color: "var(--cp-text)" }}>{v}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Start gate */}
        {!started && (
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "14px", padding: "36px", textAlign: "center" }}>
            <p style={{ fontSize: "40px", marginBottom: "14px" }}>🏁</p>
            <h2 style={{ fontSize: "26px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "8px" }}>Ready to check out?</h2>
            <p style={{ fontSize: "14px", color: "var(--cp-text-muted)", lineHeight: 1.6, marginBottom: "24px", maxWidth: "400px", margin: "0 auto 24px" }}>
              This quick digital checkout takes 2–3 minutes. Completing it notifies our housekeeping team and triggers your deposit settlement.
            </p>
            <button onClick={beginCheckout} style={{ padding: "13px 32px", background: "#1A1714", border: "none", borderRadius: "8px", fontSize: "14px", fontWeight: 700, color: "#FAF8F5", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
              Begin Checkout →
            </button>
          </div>
        )}

        {/* ── STEP 1: Checklist ── */}
        {started && step === "checklist" && (
          <div>
            <div style={{ marginBottom: "20px" }}>
              <h2 style={{ fontSize: "24px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "4px" }}>Departure checklist</h2>
              <p style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>Please confirm each item before proceeding.</p>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "10px", marginBottom: "24px" }}>
              {CHECKLIST.map(item => {
                const checked = state[item.key];
                return (
                  <div key={item.key} onClick={() => toggleItem(item.key)}
                    style={{ display: "flex", gap: "14px", padding: "16px 18px", background: checked ? "rgba(13,122,82,0.05)" : "var(--cp-card)", border: `1px solid ${checked ? "rgba(13,122,82,0.25)" : "var(--cp-border)"}`, borderRadius: "10px", cursor: "pointer", transition: "all 0.15s", alignItems: "flex-start" }}
                  >
                    <div style={{ width: "24px", height: "24px", borderRadius: "50%", border: `2px solid ${checked ? "#0D7A52" : "var(--cp-border)"}`, background: checked ? "#0D7A52" : "transparent", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: "1px", transition: "all 0.15s" }}>
                      {checked && <span style={{ color: "#fff", fontSize: "12px", fontWeight: 700 }}>✓</span>}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "3px" }}>
                        <span style={{ fontSize: "18px" }}>{item.icon}</span>
                        <span style={{ fontSize: "14px", fontWeight: 600, color: "var(--cp-text)" }}>{item.label}</span>
                      </div>
                      <p style={{ fontSize: "12px", color: "var(--cp-text-muted)", lineHeight: 1.5 }}>{item.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            <button disabled={!allChecked} onClick={proceedToDamage} style={{ width: "100%", padding: "13px", background: allChecked ? "#1A1714" : "var(--cp-border)", border: "none", borderRadius: "8px", fontSize: "14px", fontWeight: 700, color: allChecked ? "#FAF8F5" : "var(--cp-text-dim)", cursor: allChecked ? "pointer" : "not-allowed", fontFamily: "Plus Jakarta Sans, sans-serif", transition: "all 0.15s" }}>
              {allChecked ? "Continue to Damage Report →" : `Complete checklist (${[state.keysReturned, state.trashDisposed, state.lightsOff, state.acOff].filter(Boolean).length}/4)`}
            </button>
          </div>
        )}

        {/* ── STEP 2: Damage Report ── */}
        {started && step === "damage" && (
          <div>
            <div style={{ marginBottom: "20px" }}>
              <h2 style={{ fontSize: "24px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "4px" }}>Damage report</h2>
              <p style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>Report any pre-departure issues. This protects you from post-checkout claims.</p>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "14px", marginBottom: "24px" }}>
              <div>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", letterSpacing: "0.05em", marginBottom: "6px" }}>DESCRIBE ANY ISSUES (OPTIONAL)</label>
                <textarea value={damageNotes} onChange={e => setDamageNotes(e.target.value)} rows={4}
                  placeholder="e.g. Small scratch on kitchen counter, loose cabinet hinge in bathroom…"
                  style={{ ...inp, minHeight: "100px" }}
                  onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")}
                  onBlur={e => (e.target.style.borderColor = "var(--cp-border)")}
                />
              </div>

              <div>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", letterSpacing: "0.05em", marginBottom: "6px" }}>PHOTO UPLOAD (RECOMMENDED)</label>
                <div onClick={() => setPhotoUploaded(true)}
                  style={{ padding: "24px", border: `2px dashed ${photoUploaded ? "#0D7A52" : "var(--cp-border)"}`, borderRadius: "8px", textAlign: "center", cursor: "pointer", background: photoUploaded ? "rgba(13,122,82,0.04)" : "var(--cp-bg)", transition: "all 0.2s" }}
                  onMouseEnter={e => { if (!photoUploaded) (e.currentTarget.style.borderColor = "var(--cp-gold)"); }}
                  onMouseLeave={e => { if (!photoUploaded) (e.currentTarget.style.borderColor = "var(--cp-border)"); }}
                >
                  {photoUploaded ? (
                    <><p style={{ fontSize: "24px" }}>✅</p><p style={{ fontSize: "13px", color: "#0D7A52", fontWeight: 600 }}>Photos uploaded successfully</p></>
                  ) : (
                    <><p style={{ fontSize: "28px", marginBottom: "6px" }}>📸</p><p style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>Click to upload photos of the unit</p><p style={{ fontSize: "11px", color: "var(--cp-text-dim)", marginTop: "4px" }}>JPG or PNG · Up to 10 files</p></>
                  )}
                </div>
              </div>

              {damageNotes.trim() && (
                <div style={{ padding: "12px 14px", background: "rgba(217,119,6,0.07)", border: "1px solid rgba(217,119,6,0.2)", borderRadius: "8px" }}>
                  <p style={{ fontSize: "12px", color: "#D97706" }}>⚠️ Reported damages may affect your security deposit refund. Our team will review within 48 hours.</p>
                </div>
              )}
            </div>

            <div style={{ display: "flex", gap: "8px" }}>
              <button onClick={() => setStep("checklist")} style={{ padding: "11px 18px", border: "1px solid var(--cp-border)", borderRadius: "8px", background: "none", fontSize: "13px", color: "var(--cp-text-2)", cursor: "pointer" }}>← Back</button>
              <button onClick={proceedToSettlement} style={{ flex: 1, padding: "12px", background: "#1A1714", border: "none", borderRadius: "8px", fontSize: "14px", fontWeight: 700, color: "#FAF8F5", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
                View Settlement →
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 3: Settlement ── */}
        {started && step === "settlement" && (
          <div>
            <div style={{ marginBottom: "20px" }}>
              <h2 style={{ fontSize: "24px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "4px" }}>Final settlement</h2>
              <p style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>Review your stay charges and estimated deposit refund.</p>
            </div>

            {/* Itemized breakdown */}
            <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px", marginBottom: "16px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "14px" }}>STAY SUMMARY</p>
              {[
                [`Base rate ($${res.baseRate}/night × ${nights} nights)`, res.baseRate * nights],
                ["Cleaning fee", res.cleaningFee],
                ["Service fee", res.serviceFee],
              ].map(([l, v]) => (
                <div key={l as string} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid var(--cp-border)" }}>
                  <span style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>{l as string}</span>
                  <span style={{ fontSize: "13px", color: "var(--cp-text)" }}>${(v as number).toLocaleString()}</span>
                </div>
              ))}
              <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0 0" }}>
                <span style={{ fontSize: "14px", fontWeight: 700, color: "var(--cp-text)" }}>Total charged</span>
                <span style={{ fontSize: "14px", fontWeight: 800, color: "var(--cp-text)", fontFamily: "JetBrains Mono, monospace" }}>${(res.total - res.securityDeposit).toLocaleString()}</span>
              </div>
            </div>

            {/* Deposit refund */}
            <div style={{ background: hasDamage ? "rgba(217,119,6,0.06)" : "rgba(13,122,82,0.06)", border: `1px solid ${hasDamage ? "rgba(217,119,6,0.2)" : "rgba(13,122,82,0.2)"}`, borderRadius: "12px", padding: "18px 20px", marginBottom: "20px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, color: hasDamage ? "#D97706" : "#0D7A52", letterSpacing: "0.06em", marginBottom: "8px" }}>SECURITY DEPOSIT REFUND</p>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <p style={{ fontSize: "14px", color: "var(--cp-text-muted)" }}>Original deposit held: <strong>$500.00</strong></p>
                  {hasDamage && <p style={{ fontSize: "13px", color: "#D97706", marginTop: "4px" }}>Damage assessment: −$150.00 (estimated)</p>}
                </div>
                <div style={{ textAlign: "right" }}>
                  <p style={{ fontSize: "28px", fontWeight: 800, color: hasDamage ? "#D97706" : "#0D7A52", fontFamily: "JetBrains Mono, monospace" }}>${depositRefund}</p>
                  <p style={{ fontSize: "11px", color: "var(--cp-text-muted)" }}>{hasDamage ? "Est. refund after review" : "Full refund in 5–7 business days"}</p>
                </div>
              </div>
            </div>

            {/* Checklist confirmation */}
            <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "10px", padding: "14px 16px", marginBottom: "20px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "8px" }}>CHECKLIST CONFIRMED</p>
              <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                {CHECKLIST.map(item => (
                  <span key={item.key} style={{ padding: "3px 10px", background: "rgba(13,122,82,0.08)", border: "1px solid rgba(13,122,82,0.2)", borderRadius: "100px", fontSize: "11px", color: "#0D7A52" }}>✓ {item.label}</span>
                ))}
              </div>
            </div>

            <button onClick={handleExpressCheckout} disabled={submitting} style={{ width: "100%", padding: "14px", background: submitting ? "var(--cp-border)" : "#1A1714", border: "none", borderRadius: "10px", fontSize: "15px", fontWeight: 700, color: submitting ? "var(--cp-text-dim)" : "#FAF8F5", cursor: submitting ? "not-allowed" : "pointer", fontFamily: "Plus Jakarta Sans, sans-serif", transition: "all 0.15s" }}>
              {submitting ? "Processing…" : "✓ Express Checkout — Generate Receipt"}
            </button>
            <p style={{ fontSize: "11px", color: "var(--cp-text-muted)", textAlign: "center", marginTop: "8px" }}>Your digital receipt and deposit refund details will be emailed to you.</p>
          </div>
        )}

        {/* ── DONE ── */}
        {step === "done" && (
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "14px", padding: "44px", textAlign: "center" }}>
            <p style={{ fontSize: "52px", marginBottom: "16px" }}>🎉</p>
            <h2 style={{ fontSize: "28px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "8px" }}>Checkout complete!</h2>
            <p style={{ fontSize: "14px", color: "var(--cp-text-muted)", lineHeight: 1.6, marginBottom: "24px", maxWidth: "380px", margin: "0 auto 24px" }}>
              Thank you for staying at Meridian Residences. Our housekeeping team has been notified. Your digital receipt and deposit refund details have been sent to your email.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: "8px", marginBottom: "28px" }}>
              {[["📧", "Digital receipt sent to your email"], ["🏠", "Housekeeping team notified"], ["💳", "$" + depositRefund.toString() + " deposit refund initiated"]].map(([icon, text]) => (
                <div key={text as string} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px 16px", background: "var(--cp-bg)", border: "1px solid var(--cp-border)", borderRadius: "8px" }}>
                  <span style={{ fontSize: "16px" }}>{icon}</span>
                  <span style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>{text as string}</span>
                  <span style={{ marginLeft: "auto", color: "#0D7A52", fontSize: "12px", fontWeight: 600 }}>✓</span>
                </div>
              ))}
            </div>
            <button onClick={onComplete} style={{ padding: "12px 32px", background: "#B8832A", border: "none", borderRadius: "8px", fontSize: "14px", fontWeight: 700, color: "#fff", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
              ← Return to My Stays
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
