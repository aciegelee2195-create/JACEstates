import { useState } from "react";
import { useCustomerAuth, type Reservation } from "../../contexts/CustomerAuthContext";

interface Props { onCheckout: (res: Reservation) => void; }

const STATUS_META = {
  upcoming:  { label: "Upcoming",  color: "#0284C7", bg: "rgba(2,132,199,0.08)",   border: "rgba(2,132,199,0.18)"   },
  active:    { label: "Active",    color: "#059669", bg: "rgba(5,150,105,0.08)",    border: "rgba(5,150,105,0.18)"   },
  completed: { label: "Completed", color: "#64748B", bg: "rgba(100,116,139,0.08)", border: "rgba(100,116,139,0.18)" },
  cancelled: { label: "Cancelled", color: "#DC2626", bg: "rgba(220,38,38,0.08)",   border: "rgba(220,38,38,0.18)"   },
};

function formatDate(s: string) {
  return new Date(s + "T12:00:00").toLocaleDateString("en-US", { weekday: "short", month: "long", day: "numeric", year: "numeric" });
}

function daysTil(s: string): number {
  return Math.ceil((new Date(s + "T12:00:00").getTime() - Date.now()) / (1000 * 60 * 60 * 24));
}

function isUnlocked(checkIn: string): boolean {
  return daysTil(checkIn) <= 1;
}

function DigitalAccessCard({ res }: { res: Reservation }) {
  const [revealed, setRevealed] = useState(false);
  const unlocked = isUnlocked(res.checkIn);

  return (
    <div style={{ background: "linear-gradient(135deg, #1A1714 0%, #2D2820 100%)", borderRadius: "14px", padding: "24px", color: "#FAF8F5", position: "relative", overflow: "hidden" }}>
      {/* Decorative dots */}
      <div style={{ position: "absolute", top: "-20px", right: "-20px", width: "120px", height: "120px", borderRadius: "50%", background: "rgba(184,131,42,0.08)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: "-30px", left: "30%", width: "80px", height: "80px", borderRadius: "50%", background: "rgba(13,122,82,0.1)", pointerEvents: "none" }} />

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "20px" }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "6px" }}>
            <div style={{ width: "22px", height: "22px", borderRadius: "5px", background: "#0D7A52", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#fff", fontWeight: 800, fontSize: "10px", fontFamily: "Plus Jakarta Sans, sans-serif" }}>J</span>
            </div>
            <span style={{ fontSize: "12px", fontWeight: 600, color: "rgba(250,248,245,0.6)" }}>JACEstates Digital Access</span>
          </div>
          <p style={{ fontSize: "16px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "#FAF8F5" }}>{res.propertyName}</p>
          <p style={{ fontSize: "12px", color: "rgba(250,248,245,0.55)", marginTop: "2px" }}>{res.propertyAddress}</p>
        </div>
        <div style={{ textAlign: "right" }}>
          <span style={{ padding: "3px 9px", borderRadius: "100px", fontSize: "10px", fontWeight: 700, background: unlocked ? "rgba(5,150,105,0.25)" : "rgba(255,255,255,0.08)", color: unlocked ? "#34D399" : "rgba(250,248,245,0.45)", border: `1px solid ${unlocked ? "rgba(5,150,105,0.3)" : "rgba(255,255,255,0.1)"}` }}>
            {unlocked ? "🔓 UNLOCKED" : "🔒 LOCKED"}
          </span>
          {!unlocked && <p style={{ fontSize: "10px", color: "rgba(250,248,245,0.4)", marginTop: "4px" }}>Unlocks 24h before check-in</p>}
        </div>
      </div>

      {unlocked ? (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
          {/* Smart lock */}
          <div style={{ background: "rgba(255,255,255,0.06)", borderRadius: "10px", padding: "14px", border: "1px solid rgba(255,255,255,0.08)" }}>
            <p style={{ fontSize: "10px", fontWeight: 700, color: "rgba(250,248,245,0.5)", letterSpacing: "0.06em", marginBottom: "8px" }}>SMART LOCK CODE</p>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <p style={{ fontSize: "28px", fontWeight: 800, color: "#B8832A", fontFamily: "JetBrains Mono, monospace", letterSpacing: "0.12em" }}>
                {revealed ? res.accessCode : "••••"}
              </p>
              <button onClick={() => setRevealed(v => !v)} style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "6px", padding: "4px 8px", color: "rgba(250,248,245,0.6)", cursor: "pointer", fontSize: "11px" }}>
                {revealed ? "Hide" : "Reveal"}
              </button>
            </div>
            <p style={{ fontSize: "10px", color: "rgba(250,248,245,0.4)", marginTop: "4px" }}>Tap to copy · Changes at checkout</p>
          </div>

          {/* WiFi */}
          <div style={{ background: "rgba(255,255,255,0.06)", borderRadius: "10px", padding: "14px", border: "1px solid rgba(255,255,255,0.08)" }}>
            <p style={{ fontSize: "10px", fontWeight: 700, color: "rgba(250,248,245,0.5)", letterSpacing: "0.06em", marginBottom: "8px" }}>WI-FI NETWORK</p>
            <p style={{ fontSize: "13px", fontWeight: 600, color: "#FAF8F5", marginBottom: "3px" }}>{res.wifiName}</p>
            <p style={{ fontSize: "13px", color: "#B8832A", fontFamily: "JetBrains Mono, monospace" }}>{revealed ? res.wifiPassword : "••••••••"}</p>
          </div>

          {/* Check-in instructions */}
          <div style={{ gridColumn: "1/-1", background: "rgba(255,255,255,0.04)", borderRadius: "10px", padding: "14px", border: "1px solid rgba(255,255,255,0.06)" }}>
            <p style={{ fontSize: "10px", fontWeight: 700, color: "rgba(250,248,245,0.5)", letterSpacing: "0.06em", marginBottom: "6px" }}>CHECK-IN INSTRUCTIONS</p>
            <p style={{ fontSize: "12px", color: "rgba(250,248,245,0.7)", lineHeight: 1.6 }}>{res.checkInInstructions}</p>
          </div>
        </div>
      ) : (
        <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: "10px", padding: "18px", border: "1px dashed rgba(255,255,255,0.1)", textAlign: "center" }}>
          <p style={{ fontSize: "28px", marginBottom: "8px" }}>🔒</p>
          <p style={{ fontSize: "13px", color: "rgba(250,248,245,0.5)" }}>
            Access details unlock <strong style={{ color: "rgba(250,248,245,0.8)" }}>24 hours</strong> before your check-in<br />
            <span style={{ fontSize: "12px" }}>Check-in: {formatDate(res.checkIn)}</span>
          </p>
        </div>
      )}

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "16px", paddingTop: "14px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
        <div>
          <p style={{ fontSize: "10px", color: "rgba(250,248,245,0.4)" }}>Agent</p>
          <p style={{ fontSize: "12px", color: "rgba(250,248,245,0.7)" }}>{res.agent}</p>
        </div>
        <div style={{ textAlign: "right" }}>
          <p style={{ fontSize: "10px", color: "rgba(250,248,245,0.4)" }}>Reservation</p>
          <p style={{ fontSize: "12px", fontFamily: "JetBrains Mono, monospace", color: "rgba(250,248,245,0.7)" }}>{res.id}</p>
        </div>
      </div>
    </div>
  );
}

function ReservationCard({ res, onCheckout }: { res: Reservation; onCheckout: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const meta = STATUS_META[res.status];
  const nights = Math.round((new Date(res.checkOut + "T12:00:00").getTime() - new Date(res.checkIn + "T12:00:00").getTime()) / (1000 * 60 * 60 * 24));
  const til = daysTil(res.checkIn);
  const showAccess = res.status === "upcoming" || res.status === "active";

  return (
    <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "14px", overflow: "hidden", boxShadow: "var(--cp-shadow)" }}>
      <div style={{ display: "flex", gap: "0", cursor: "pointer" }} onClick={() => setExpanded(v => !v)}>
        {/* Thumbnail */}
        <div style={{ width: "180px", flexShrink: 0, background: "#E8E4DC" }}>
          <img src={`https://images.unsplash.com/${res.img}?w=360&h=240&fit=crop&auto=format`} alt={res.propertyName} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>

        {/* Info */}
        <div style={{ flex: 1, padding: "18px 20px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "6px" }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                <h3 style={{ fontSize: "17px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)" }}>{res.propertyName} — {res.unitType}</h3>
                <span style={{ padding: "2px 8px", borderRadius: "100px", fontSize: "10px", fontWeight: 700, background: meta.bg, color: meta.color, border: `1px solid ${meta.border}` }}>{meta.label}</span>
              </div>
              <p style={{ fontSize: "12px", color: "var(--cp-text-muted)" }}>Unit {res.unitId} · Floor {res.floor} · {res.propertyAddress.split(",")[1]?.trim()}</p>
            </div>
            <div style={{ textAlign: "right" }}>
              <p style={{ fontSize: "18px", fontWeight: 700, color: "var(--cp-text)", fontFamily: "JetBrains Mono, monospace" }}>${res.total.toLocaleString()}</p>
              <p style={{ fontSize: "11px", color: "var(--cp-text-muted)" }}>{nights} nights</p>
            </div>
          </div>

          {/* Dates */}
          <div style={{ display: "flex", gap: "16px", marginTop: "10px" }}>
            {[["CHECK-IN", formatDate(res.checkIn)], ["CHECK-OUT", formatDate(res.checkOut)]].map(([l, v]) => (
              <div key={l as string}>
                <p style={{ fontSize: "10px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em" }}>{l as string}</p>
                <p style={{ fontSize: "13px", fontWeight: 500, color: "var(--cp-text)" }}>{v as string}</p>
              </div>
            ))}
            {res.status === "upcoming" && til > 0 && (
              <div style={{ marginLeft: "auto", padding: "6px 12px", background: "rgba(2,132,199,0.08)", border: "1px solid rgba(2,132,199,0.18)", borderRadius: "8px", textAlign: "center" }}>
                <p style={{ fontSize: "18px", fontWeight: 800, color: "#0284C7", fontFamily: "JetBrains Mono, monospace", lineHeight: 1 }}>{til}</p>
                <p style={{ fontSize: "10px", color: "#0284C7" }}>days away</p>
              </div>
            )}
          </div>
        </div>

        {/* Expand arrow */}
        <div style={{ padding: "18px 16px", display: "flex", alignItems: "center" }}>
          <span style={{ color: "var(--cp-text-muted)", fontSize: "18px", transition: "transform 0.2s", display: "block", transform: expanded ? "rotate(180deg)" : "none" }}>⌄</span>
        </div>
      </div>

      {/* Expanded content */}
      {expanded && (
        <div style={{ padding: "20px", borderTop: "1px solid var(--cp-border)", display: "flex", flexDirection: "column", gap: "16px" }}>
          {/* Digital access card */}
          {showAccess && <DigitalAccessCard res={res} />}

          {/* Price breakdown */}
          <div style={{ background: "var(--cp-bg)", borderRadius: "10px", padding: "16px", border: "1px solid var(--cp-border)" }}>
            <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "10px" }}>STAY BREAKDOWN</p>
            {[
              [`$${res.baseRate.toLocaleString()} × ${nights} nights`, res.baseRate * nights],
              ["Cleaning fee", res.cleaningFee],
              ["Service fee", res.serviceFee],
              ["Security deposit", res.securityDeposit],
            ].map(([l, v]) => (
              <div key={l as string} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: "1px solid var(--cp-border)" }}>
                <span style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>{l as string}</span>
                <span style={{ fontSize: "13px", color: "var(--cp-text)" }}>${(v as number).toLocaleString()}</span>
              </div>
            ))}
            <div style={{ display: "flex", justifyContent: "space-between", paddingTop: "8px" }}>
              <span style={{ fontSize: "14px", fontWeight: 700, color: "var(--cp-text)" }}>Total paid</span>
              <span style={{ fontSize: "14px", fontWeight: 800, color: "var(--cp-text)", fontFamily: "JetBrains Mono, monospace" }}>${res.total.toLocaleString()}</span>
            </div>
          </div>

          {/* Actions */}
          <div style={{ display: "flex", gap: "8px" }}>
            {res.status === "upcoming" && (
              <button style={{ flex: 1, padding: "10px", border: "1px solid var(--cp-border)", borderRadius: "8px", background: "none", fontSize: "13px", color: "var(--cp-text-2)", cursor: "pointer" }}>
                Modify booking
              </button>
            )}
            {res.status === "upcoming" && (
              <button style={{ flex: 1, padding: "10px", border: "1px solid rgba(220,38,38,0.25)", borderRadius: "8px", background: "rgba(220,38,38,0.04)", fontSize: "13px", color: "#DC2626", cursor: "pointer" }}>
                Cancel stay
              </button>
            )}
            {(res.status === "active" || (res.status === "upcoming" && daysTil(res.checkOut) <= 1)) && !res.checkoutState?.completedAt && (
              <button onClick={onCheckout} style={{ flex: 1, padding: "10px", background: "#1A1714", border: "none", borderRadius: "8px", fontSize: "13px", fontWeight: 600, color: "#FAF8F5", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
                Begin Self-Checkout →
              </button>
            )}
            {res.checkoutState?.completedAt && (
              <div style={{ flex: 1, padding: "10px 14px", background: "rgba(5,150,105,0.08)", border: "1px solid rgba(5,150,105,0.2)", borderRadius: "8px", fontSize: "13px", color: "#0D7A52", fontWeight: 600, textAlign: "center" }}>
                ✓ Checked out · {new Date(res.checkoutState.completedAt).toLocaleDateString()}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function MyStays({ onCheckout }: Props) {
  const { reservations, customer } = useCustomerAuth();
  const [tab, setTab] = useState<"all" | "upcoming" | "completed">("all");

  const filtered = reservations.filter(r =>
    tab === "all" || (tab === "upcoming" && (r.status === "upcoming" || r.status === "active")) || (tab === "completed" && r.status === "completed")
  );

  const upcoming = reservations.filter(r => r.status === "upcoming" || r.status === "active");
  const nextStay = upcoming.sort((a, b) => a.checkIn.localeCompare(b.checkIn))[0];

  return (
    <div data-portal="client" style={{ minHeight: "100vh", background: "var(--cp-bg)", color: "var(--cp-text)", fontFamily: "Inter, sans-serif" }}>
      <div style={{ maxWidth: "960px", margin: "0 auto", padding: "32px" }}>
        {/* Header */}
        <div style={{ marginBottom: "28px" }}>
          <h1 style={{ fontSize: "32px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "6px" }}>My Stays</h1>
          <p style={{ fontSize: "14px", color: "var(--cp-text-muted)" }}>Welcome back, {customer?.name.split(" ")[0]}. You have {upcoming.length} upcoming reservation{upcoming.length !== 1 ? "s" : ""}.</p>
        </div>

        {/* Next stay highlight */}
        {nextStay && (
          <div style={{ background: "linear-gradient(135deg, #1A1714 0%, #2D2820 60%, #1A2318 100%)", borderRadius: "14px", padding: "22px 26px", marginBottom: "28px", display: "flex", justifyContent: "space-between", alignItems: "center", boxShadow: "var(--cp-shadow-md)" }}>
            <div>
              <p style={{ fontSize: "11px", fontWeight: 700, color: "rgba(250,248,245,0.45)", letterSpacing: "0.07em", marginBottom: "4px" }}>NEXT UPCOMING STAY</p>
              <h3 style={{ fontSize: "20px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "#FAF8F5", marginBottom: "4px" }}>{nextStay.propertyName} — {nextStay.unitType}</h3>
              <p style={{ fontSize: "13px", color: "rgba(250,248,245,0.55)" }}>{formatDate(nextStay.checkIn)} → {formatDate(nextStay.checkOut)}</p>
            </div>
            <div style={{ textAlign: "right", flexShrink: 0 }}>
              <p style={{ fontSize: "44px", fontWeight: 800, color: "#B8832A", fontFamily: "JetBrains Mono, monospace", lineHeight: 1 }}>{daysTil(nextStay.checkIn)}</p>
              <p style={{ fontSize: "12px", color: "rgba(250,248,245,0.5)", marginTop: "2px" }}>days away</p>
            </div>
          </div>
        )}

        {/* Booking calendar strip */}
        {reservations.length > 0 && (
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "18px 20px", marginBottom: "24px" }}>
            <p style={{ fontSize: "12px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "14px" }}>BOOKING SCHEDULE</p>
            <div style={{ display: "flex", gap: "8px", overflowX: "auto", paddingBottom: "4px" }}>
              {reservations.map(r => {
                const meta = STATUS_META[r.status];
                return (
                  <div key={r.id} style={{ flexShrink: 0, padding: "10px 14px", background: "var(--cp-bg)", border: `1px solid ${meta.border}`, borderRadius: "10px", minWidth: "160px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "5px", marginBottom: "5px" }}>
                      <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: meta.color, flexShrink: 0 }} />
                      <span style={{ fontSize: "10px", fontWeight: 700, color: meta.color }}>{meta.label.toUpperCase()}</span>
                    </div>
                    <p style={{ fontSize: "12px", fontWeight: 600, color: "var(--cp-text)", marginBottom: "2px" }}>{r.unitType} · {r.unitId}</p>
                    <p style={{ fontSize: "10px", color: "var(--cp-text-muted)", fontFamily: "JetBrains Mono, monospace" }}>
                      {new Date(r.checkIn + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" })} – {new Date(r.checkOut + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tabs */}
        <div style={{ display: "flex", gap: "4px", marginBottom: "20px", background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "10px", padding: "4px", width: "fit-content" }}>
          {([["all", "All Stays"], ["upcoming", "Upcoming"], ["completed", "Completed"]] as const).map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)} style={{ padding: "7px 18px", border: "none", borderRadius: "7px", background: tab === id ? "#1A1714" : "none", color: tab === id ? "#FAF8F5" : "var(--cp-text-muted)", fontSize: "13px", fontWeight: tab === id ? 600 : 400, cursor: "pointer", transition: "all 0.15s" }}>
              {label}
            </button>
          ))}
        </div>

        {/* Reservations list */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
          {filtered.map(r => <ReservationCard key={r.id} res={r} onCheckout={() => onCheckout(r)} />)}
          {filtered.length === 0 && (
            <div style={{ padding: "60px", textAlign: "center", background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "14px" }}>
              <p style={{ fontSize: "32px", marginBottom: "12px" }}>🏡</p>
              <h3 style={{ fontSize: "20px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "6px" }}>No stays yet</h3>
              <p style={{ fontSize: "14px", color: "var(--cp-text-muted)" }}>Browse properties and make your first reservation.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
