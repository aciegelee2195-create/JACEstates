import { useState } from "react";
import { useBooking } from "../../contexts/BookingContext";
import { fmtPrice, getFloorLabel, type Unit } from "../../data/buildingData";

interface Props {
  unit: Unit;
  onBack: () => void;
  onConfirm: () => void;
}

const AGENTS = [
  { name: "Alexandra Chen", initials: "AC", color: "#0D7A52", role: "Senior Sales Agent", img: "photo-1494790108377-be9c29b29330" },
  { name: "Marcus Torres", initials: "MT", color: "#2563EB", role: "Sales Agent", img: "photo-1500648767791-00dcc994a43e" },
  { name: "Priya Singh", initials: "PS", color: "#B45309", role: "Sales Agent", img: "photo-1487412720507-e7ab37603c6f" },
];

const TIME_SLOTS = ["9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"];
const DATES = Array.from({ length: 7 }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() + i + 1);
  return { label: d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }), value: d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) };
});

export default function TourScheduler({ unit, onBack, onConfirm }: Props) {
  const { scheduleTour } = useBooking();
  const [tourType, setTourType] = useState<"in-person" | "virtual">("in-person");
  const [selectedDate, setSelectedDate] = useState(DATES[1].value);
  const [selectedTime, setSelectedTime] = useState("10:00 AM");
  const [selectedAgent, setSelectedAgent] = useState(AGENTS[0].name);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name || !email) return;
    setLoading(true);
    setTimeout(() => {
      scheduleTour(unit.id, { name, email }, `${selectedDate} ${selectedTime}`);
      setSubmitted(true);
      setLoading(false);
    }, 800);
  }

  const inp: React.CSSProperties = {
    width: "100%", padding: "10px 12px", border: "1px solid var(--cp-border)", borderRadius: "8px",
    background: "var(--cp-card)", color: "var(--cp-text)", fontSize: "14px", outline: "none",
    fontFamily: "Inter, sans-serif", boxSizing: "border-box",
  };

  if (submitted) {
    return (
      <div style={{ maxWidth: "560px", margin: "0 auto", padding: "60px 0", textAlign: "center" }}>
        <div style={{ width: "64px", height: "64px", borderRadius: "50%", background: "var(--cp-emerald-dim)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", fontSize: "28px" }}>✓</div>
        <h2 style={{ fontSize: "26px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "8px" }}>Tour Confirmed</h2>
        <p style={{ fontSize: "14px", color: "var(--cp-text-muted)", marginBottom: "24px" }}>
          Your {tourType} tour for Unit <strong>{unit.id}</strong> has been scheduled for<br />
          <strong>{selectedDate} at {selectedTime}</strong> with {selectedAgent}.
        </p>
        <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px", marginBottom: "24px", textAlign: "left" }}>
          <p style={{ fontSize: "12px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "12px" }}>CONFIRMATION DETAILS</p>
          {[["Unit", `${unit.id} · ${unit.type} · Floor ${unit.floor}`], ["Date & Time", `${selectedDate} · ${selectedTime}`], ["Agent", selectedAgent], ["Tour Type", tourType === "in-person" ? "In-Person Walkthrough" : "Virtual Tour"], ["Client", `${name} · ${email}`]].map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid var(--cp-border)" }}>
              <span style={{ fontSize: "12px", color: "var(--cp-text-dim)" }}>{k}</span>
              <span style={{ fontSize: "13px", fontWeight: 600, color: "var(--cp-text)" }}>{v}</span>
            </div>
          ))}
        </div>
        <p style={{ fontSize: "13px", color: "var(--cp-text-muted)", marginBottom: "20px" }}>A confirmation email has been sent to <strong>{email}</strong>. Your agent will reach out 24 hours before your tour.</p>
        <button onClick={onConfirm} style={{ padding: "12px 32px", background: "var(--cp-gold)", border: "none", borderRadius: "8px", fontSize: "14px", fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
          ← Return to Floor Plan
        </button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: "900px", margin: "0 auto" }}>
      <button onClick={onBack} style={{ display: "flex", alignItems: "center", gap: "6px", background: "none", border: "none", cursor: "pointer", fontSize: "13px", color: "var(--cp-text-muted)", marginBottom: "24px", padding: 0 }}>
        ← Back to Floor Plan
      </button>

      <div style={{ marginBottom: "28px" }}>
        <h2 style={{ fontSize: "28px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)" }}>Schedule a Private Tour</h2>
        <p style={{ fontSize: "14px", color: "var(--cp-text-muted)", marginTop: "4px" }}>Unit {unit.id} · {unit.type} · Floor {unit.floor} · {getFloorLabel(unit.floor)}</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: "24px" }}>
        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>

          {/* Tour type */}
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px" }}>
            <p style={{ fontSize: "12px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "12px" }}>TOUR FORMAT</p>
            <div style={{ display: "flex", gap: "10px" }}>
              {(["in-person", "virtual"] as const).map(t => (
                <button key={t} type="button" onClick={() => setTourType(t)} style={{
                  flex: 1, padding: "14px", borderRadius: "10px", cursor: "pointer",
                  border: `1px solid ${tourType === t ? "var(--cp-gold)" : "var(--cp-border)"}`,
                  background: tourType === t ? "var(--cp-gold-dim)" : "var(--cp-bg)",
                  textAlign: "center", transition: "all 0.15s",
                }}>
                  <div style={{ fontSize: "22px", marginBottom: "6px" }}>{t === "in-person" ? "🏢" : "💻"}</div>
                  <div style={{ fontSize: "13px", fontWeight: 600, color: tourType === t ? "var(--cp-gold)" : "var(--cp-text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{t === "in-person" ? "In-Person" : "Virtual Tour"}</div>
                  <div style={{ fontSize: "11px", color: "var(--cp-text-muted)", marginTop: "2px" }}>{t === "in-person" ? "On-site walkthrough" : "Video call with agent"}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Date & Time */}
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px" }}>
            <p style={{ fontSize: "12px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "14px" }}>SELECT DATE & TIME</p>
            <div style={{ display: "flex", gap: "6px", overflowX: "auto", marginBottom: "14px", paddingBottom: "2px" }}>
              {DATES.map(d => (
                <button key={d.value} type="button" onClick={() => setSelectedDate(d.value)} style={{
                  flexShrink: 0, padding: "8px 12px", borderRadius: "8px", cursor: "pointer", textAlign: "center",
                  border: `1px solid ${selectedDate === d.value ? "var(--cp-gold)" : "var(--cp-border)"}`,
                  background: selectedDate === d.value ? "var(--cp-gold-dim)" : "var(--cp-bg)",
                  transition: "all 0.15s",
                }}>
                  <div style={{ fontSize: "11px", color: selectedDate === d.value ? "var(--cp-gold)" : "var(--cp-text-muted)" }}>{d.label.split(",")[0]}</div>
                  <div style={{ fontSize: "13px", fontWeight: 600, color: selectedDate === d.value ? "var(--cp-gold)" : "var(--cp-text)" }}>{d.label.split(", ")[1]}</div>
                </button>
              ))}
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
              {TIME_SLOTS.map(t => (
                <button key={t} type="button" onClick={() => setSelectedTime(t)} style={{
                  padding: "6px 12px", borderRadius: "7px", cursor: "pointer", fontSize: "13px",
                  border: `1px solid ${selectedTime === t ? "var(--cp-gold)" : "var(--cp-border)"}`,
                  background: selectedTime === t ? "var(--cp-gold)" : "var(--cp-bg)",
                  color: selectedTime === t ? "#fff" : "var(--cp-text-2)",
                  fontWeight: selectedTime === t ? 600 : 400, transition: "all 0.15s",
                }}>{t}</button>
              ))}
            </div>
          </div>

          {/* Agent */}
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px" }}>
            <p style={{ fontSize: "12px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "12px" }}>YOUR AGENT</p>
            <div style={{ display: "flex", gap: "10px" }}>
              {AGENTS.map(a => (
                <button key={a.name} type="button" onClick={() => setSelectedAgent(a.name)} style={{
                  flex: 1, padding: "12px 8px", borderRadius: "10px", cursor: "pointer", textAlign: "center",
                  border: `1px solid ${selectedAgent === a.name ? a.color : "var(--cp-border)"}`,
                  background: selectedAgent === a.name ? `${a.color}10` : "var(--cp-bg)",
                  transition: "all 0.15s",
                }}>
                  <div style={{ width: "36px", height: "36px", borderRadius: "50%", overflow: "hidden", margin: "0 auto 6px", background: "#E8E4DC" }}>
                    <img src={`https://images.unsplash.com/${a.img}?w=60&h=60&fit=crop&auto=format`} alt={a.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  </div>
                  <div style={{ fontSize: "11px", fontWeight: 600, color: selectedAgent === a.name ? a.color : "var(--cp-text)" }}>{a.name.split(" ")[0]}</div>
                  <div style={{ fontSize: "10px", color: "var(--cp-text-dim)", marginTop: "1px" }}>{a.role.split(" ")[0]}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Contact info */}
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px" }}>
            <p style={{ fontSize: "12px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "14px" }}>YOUR DETAILS</p>
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                <div>
                  <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>FULL NAME *</label>
                  <input value={name} onChange={e => setName(e.target.value)} required placeholder="Jane Smith" style={inp}
                    onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")}
                    onBlur={e => (e.target.style.borderColor = "var(--cp-border)")}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>PHONE</label>
                  <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+1 (555) 000-0000" style={inp}
                    onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")}
                    onBlur={e => (e.target.style.borderColor = "var(--cp-border)")}
                  />
                </div>
              </div>
              <div>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>EMAIL ADDRESS *</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="jane@example.com" style={inp}
                  onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")}
                  onBlur={e => (e.target.style.borderColor = "var(--cp-border)")}
                />
              </div>
              <div>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>ADDITIONAL NOTES</label>
                <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Any questions or special requirements…" rows={2} style={{ ...inp, resize: "vertical" }}
                  onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")}
                  onBlur={e => (e.target.style.borderColor = "var(--cp-border)")}
                />
              </div>
            </div>
          </div>

          <button type="submit" disabled={loading || !name || !email} style={{
            padding: "14px", background: (!name || !email) ? "var(--cp-border)" : "var(--cp-gold)",
            border: "none", borderRadius: "8px", fontSize: "14px", fontWeight: 700, color: "#fff",
            cursor: (!name || !email) ? "not-allowed" : "pointer", fontFamily: "Plus Jakarta Sans, sans-serif",
          }}>
            {loading ? "Scheduling Tour…" : `Confirm ${tourType === "in-person" ? "In-Person" : "Virtual"} Tour →`}
          </button>
        </form>

        {/* Summary card */}
        <div style={{ position: "sticky", top: "88px" }}>
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", overflow: "hidden", boxShadow: "var(--cp-shadow-md)" }}>
            <div style={{ height: "140px", background: "#E8E4DC", overflow: "hidden" }}>
              <img src={`https://images.unsplash.com/${unit.img}?w=400&h=200&fit=crop&auto=format`} alt={unit.id} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            </div>
            <div style={{ padding: "18px" }}>
              <p style={{ fontSize: "11px", fontFamily: "JetBrains Mono, monospace", color: "var(--cp-text-muted)", marginBottom: "4px" }}>{unit.id}</p>
              <p style={{ fontSize: "18px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "2px" }}>{unit.type}</p>
              <p style={{ fontSize: "13px", color: "var(--cp-text-muted)", marginBottom: "14px" }}>Floor {unit.floor} · {unit.sqft.toLocaleString()} sqft</p>
              <div style={{ borderTop: "1px solid var(--cp-border)", paddingTop: "14px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                  <span style={{ fontSize: "12px", color: "var(--cp-text-muted)" }}>Asking Price</span>
                  <span style={{ fontSize: "15px", fontWeight: 700, color: "var(--cp-text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{fmtPrice(unit.price)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ fontSize: "12px", color: "var(--cp-text-muted)" }}>Monthly Rent</span>
                  <span style={{ fontSize: "13px", color: "var(--cp-text-2)" }}>${unit.monthlyRent.toLocaleString()}/mo</span>
                </div>
              </div>
              <div style={{ marginTop: "14px", padding: "10px", background: "var(--cp-emerald-dim)", borderRadius: "8px", border: "1px solid rgba(13,122,82,0.2)" }}>
                <p style={{ fontSize: "12px", color: "var(--cp-emerald)", fontWeight: 600 }}>✓ No obligation</p>
                <p style={{ fontSize: "11px", color: "var(--cp-text-muted)", marginTop: "2px" }}>Tours are complimentary and require no commitment.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
