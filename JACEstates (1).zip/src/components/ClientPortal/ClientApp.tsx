import { useState, useRef, useEffect } from "react";
import { useBooking } from "../../contexts/BookingContext";
import { useReservations, type ReservationType, type Reservation } from "../../contexts/ReservationContext";
import { useMessages } from "../../contexts/MessageContext";
import type { ClientUser } from "../../contexts/ClientAuthContext";
import { fmtPrice, type Unit } from "../../data/buildingData";

type ClientView = "catalog" | "reservations" | "messages" | "account";

interface Props { user: ClientUser; onLogout: () => void; }

// ── Design tokens ─────────────────────────────────────────────────────────
const C = {
  bg:      "#F8FAFC",
  card:    "#FFFFFF",
  border:  "#E2E8F0",
  bst:     "#CBD5E1",
  text:    "#0F172A",
  text2:   "#334155",
  muted:   "#64748B",
  dim:     "#94A3B8",
  green:   "#059669",
  gBg:     "rgba(5,150,105,0.08)",
  gBdr:    "rgba(5,150,105,0.2)",
  amber:   "#D97706",
  aBg:     "rgba(217,119,6,0.08)",
  violet:  "#7C3AED",
  vBg:     "rgba(124,58,237,0.08)",
  red:     "#DC2626",
  rBg:     "rgba(220,38,38,0.07)",
  navy:    "#0F172A",
  blue:    "#0284C7",
  bBg:     "rgba(2,132,199,0.08)",
};
const FH = "Plus Jakarta Sans, sans-serif";
const FB = "Inter, sans-serif";
const FM = "JetBrains Mono, monospace";

const STATUS_C: Record<string, { color: string; bg: string; border: string }> = {
  Available: { color: C.green,  bg: C.gBg,  border: C.gBdr },
  Held:      { color: C.amber,  bg: C.aBg,  border: "rgba(217,119,6,0.2)" },
  Reserved:  { color: C.violet, bg: C.vBg,  border: "rgba(124,58,237,0.2)" },
  Sold:      { color: C.muted,  bg: "#F1F5F9", border: C.border },
};
const TYPE_C: Record<string, { color: string; bg: string }> = {
  "Short Stay":       { color: C.green,  bg: C.gBg },
  "Long-Term Lease":  { color: C.blue,   bg: C.bBg },
  "Purchase Inquiry": { color: C.violet, bg: C.vBg },
};
const STATUS_META = {
  Pending:   { color: C.amber,  bg: C.aBg,    label: "Pending"   },
  Confirmed: { color: C.green,  bg: C.gBg,    label: "Confirmed" },
  Cancelled: { color: C.red,    bg: C.rBg,    label: "Cancelled" },
  Completed: { color: C.muted,  bg: "#F1F5F9",label: "Completed" },
};

function fmtDt(s: string) {
  return new Date(s + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}
function fmtTime(s: string) {
  return new Date(s).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
}

function Badge({ label, color, bg, border }: { label: string; color: string; bg: string; border?: string }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", padding: "2px 9px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, color, background: bg, border: `1px solid ${border ?? color + "30"}`, whiteSpace: "nowrap", fontFamily: FB }}>
      {label}
    </span>
  );
}

// ── CATALOG ───────────────────────────────────────────────────────────────
function Catalog({ onOpenUnit }: { onOpenUnit: (unit: Unit, mode: "reserve" | "buy") => void }) {
  const { units } = useBooking();
  const [typeF, setTypeF] = useState("All");
  const [statusF, setStatusF] = useState("All");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("floor");
  const [detail, setDetail] = useState<Unit | null>(null);

  const TYPES = ["All", "Studio", "1BR", "2BR", "3BR", "Penthouse"];
  const STATUSES = ["All", "Available", "Held", "Reserved", "Sold"];

  let filtered = units.filter(u =>
    (typeF === "All" || u.type === typeF) &&
    (statusF === "All" || u.status === statusF) &&
    (search === "" || u.id.toLowerCase().includes(search.toLowerCase()) || u.type.toLowerCase().includes(search.toLowerCase()) || u.view.toLowerCase().includes(search.toLowerCase()))
  );
  if (sort === "price-asc")  filtered = [...filtered].sort((a, b) => a.price - b.price);
  if (sort === "price-desc") filtered = [...filtered].sort((a, b) => b.price - a.price);
  if (sort === "floor")      filtered = [...filtered].sort((a, b) => b.floor - a.floor);
  if (sort === "sqft")       filtered = [...filtered].sort((a, b) => b.sqft - a.sqft);

  const availCount = filtered.filter(u => u.status === "Available").length;

  return (
    <div>
      {/* Filter bar */}
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: "12px", padding: "16px 20px", marginBottom: "20px", boxShadow: "0 1px 3px rgba(15,23,42,0.04)" }}>
        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "center" }}>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by unit ID, type, or view…"
            style={{ flex: "1 1 200px", padding: "9px 13px", border: `1px solid ${C.border}`, borderRadius: "8px", background: "#F8FAFC", color: C.text, fontSize: "13px", outline: "none", fontFamily: FB }}
            onFocus={e => (e.target.style.borderColor = C.green)} onBlur={e => (e.target.style.borderColor = C.border)} />

          <div style={{ display: "flex", gap: "5px", flexWrap: "wrap" }}>
            {TYPES.map(t => (
              <button key={t} onClick={() => setTypeF(t)} style={{ padding: "6px 12px", border: `1px solid ${typeF === t ? C.green : C.border}`, borderRadius: "7px", background: typeF === t ? C.gBg : "#fff", fontSize: "12px", fontWeight: typeF === t ? 700 : 400, color: typeF === t ? C.green : C.muted, cursor: "pointer", fontFamily: FB, transition: "all 0.12s" }}>
                {t}
              </button>
            ))}
          </div>

          <select value={statusF} onChange={e => setStatusF(e.target.value)}
            style={{ padding: "8px 12px", border: `1px solid ${C.border}`, borderRadius: "8px", background: "#fff", color: C.text2, fontSize: "12px", outline: "none", fontFamily: FB, cursor: "pointer" }}>
            {STATUSES.map(s => <option key={s}>{s}</option>)}
          </select>

          <select value={sort} onChange={e => setSort(e.target.value)}
            style={{ padding: "8px 12px", border: `1px solid ${C.border}`, borderRadius: "8px", background: "#fff", color: C.text2, fontSize: "12px", outline: "none", fontFamily: FB, cursor: "pointer" }}>
            <option value="floor">Sort: Floor (High)</option>
            <option value="price-asc">Sort: Price (Low–High)</option>
            <option value="price-desc">Sort: Price (High–Low)</option>
            <option value="sqft">Sort: Size</option>
          </select>
        </div>
        <p style={{ fontSize: "12px", color: C.muted, marginTop: "10px", fontFamily: FB }}>
          <strong style={{ color: C.green }}>{availCount}</strong> available · {filtered.length} total results
        </p>
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div style={{ padding: "64px", textAlign: "center", background: C.card, border: `1px solid ${C.border}`, borderRadius: "12px" }}>
          <p style={{ fontSize: "26px", marginBottom: "10px" }}>🔍</p>
          <p style={{ fontSize: "16px", fontWeight: 700, color: C.text, fontFamily: FH }}>No units match your filters</p>
          <p style={{ fontSize: "13px", color: C.muted, marginTop: "4px", fontFamily: FB }}>Try adjusting your search criteria.</p>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(290px, 1fr))", gap: "18px" }}>
          {filtered.map(unit => {
            const sc = STATUS_C[unit.status] ?? STATUS_C.Available;
            const avail = unit.status === "Available";
            return (
              <div key={unit.id} onClick={() => setDetail(unit)} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: "12px", overflow: "hidden", cursor: "pointer", transition: "all 0.18s", boxShadow: "0 1px 3px rgba(15,23,42,0.05)" }}
                onMouseEnter={e => Object.assign((e.currentTarget as HTMLElement).style, { transform: "translateY(-3px)", boxShadow: "0 8px 24px rgba(15,23,42,0.10)", borderColor: C.bst })}
                onMouseLeave={e => Object.assign((e.currentTarget as HTMLElement).style, { transform: "none", boxShadow: "0 1px 3px rgba(15,23,42,0.05)", borderColor: C.border })}>
                <div style={{ position: "relative", height: "188px", background: "#E2E8F0", overflow: "hidden" }}>
                  <img src={`https://images.unsplash.com/${unit.img}?w=580&h=340&fit=crop&auto=format`} alt={`Unit ${unit.id}`}
                    style={{ width: "100%", height: "100%", objectFit: "cover", filter: !avail ? "grayscale(30%) brightness(0.95)" : "none" }} />
                  <div style={{ position: "absolute", top: "10px", left: "10px" }}>
                    <Badge label={unit.status} color={sc.color} bg={sc.bg} border={sc.border} />
                  </div>
                  <div style={{ position: "absolute", bottom: "10px", right: "10px", padding: "3px 8px", background: "rgba(15,23,42,0.7)", borderRadius: "5px", fontSize: "11px", color: "#F1F5F9", fontFamily: FM }}>
                    Floor {unit.floor} · {unit.orientation}
                  </div>
                </div>
                <div style={{ padding: "16px 18px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "4px" }}>
                    <div>
                      <p style={{ fontSize: "15px", fontWeight: 700, color: C.text, fontFamily: FH }}>{unit.type} · Unit {unit.id}</p>
                      <p style={{ fontSize: "12px", color: C.muted, marginTop: "1px", fontFamily: FB }}>{unit.sqft.toLocaleString()} sqft</p>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <p style={{ fontSize: "15px", fontWeight: 700, color: C.text, fontFamily: FH }}>{fmtPrice(unit.price)}</p>
                      <p style={{ fontSize: "11px", color: C.green, fontWeight: 600, fontFamily: FB }}>${Math.round(unit.monthlyRent / 30).toLocaleString()}/night</p>
                    </div>
                  </div>
                  <p style={{ fontSize: "11px", color: C.muted, marginBottom: "13px", lineHeight: 1.4, fontFamily: FB }}>{unit.view}</p>
                  {avail ? (
                    <div style={{ display: "flex", gap: "7px" }}>
                      <button onClick={e => { e.stopPropagation(); onOpenUnit(unit, "reserve"); }} style={{ flex: 1, padding: "8px", background: C.gBg, border: `1px solid ${C.gBdr}`, borderRadius: "8px", fontSize: "12px", fontWeight: 700, color: C.green, cursor: "pointer", fontFamily: FH, transition: "all 0.12s" }}
                        onMouseEnter={e => Object.assign((e.currentTarget as HTMLElement).style, { background: C.green, color: "#fff" })}
                        onMouseLeave={e => Object.assign((e.currentTarget as HTMLElement).style, { background: C.gBg, color: C.green })}>
                        Reserve
                      </button>
                      <button onClick={e => { e.stopPropagation(); onOpenUnit(unit, "buy"); }} style={{ flex: 1, padding: "8px", background: C.navy, border: `1px solid ${C.navy}`, borderRadius: "8px", fontSize: "12px", fontWeight: 700, color: "#fff", cursor: "pointer", fontFamily: FH, transition: "background 0.12s" }}
                        onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = "#1E293B")}
                        onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = C.navy)}>
                        Buy Now
                      </button>
                    </div>
                  ) : (
                    <div style={{ padding: "8px", background: "#F1F5F9", borderRadius: "8px", fontSize: "12px", color: C.dim, textAlign: "center", fontStyle: "italic", fontFamily: FB }}>
                      {unit.status === "Sold" ? "Sold" : unit.status === "Reserved" ? "Reserved" : "On Hold"}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Detail drawer */}
      {detail && (
        <div style={{ position: "fixed", inset: 0, zIndex: 100, background: "rgba(15,23,42,0.6)", backdropFilter: "blur(4px)", display: "flex", alignItems: "flex-end", justifyContent: "center" }}
          onClick={e => { if (e.target === e.currentTarget) setDetail(null); }}>
          <div style={{ background: C.card, borderRadius: "20px 20px 0 0", width: "100%", maxWidth: "680px", maxHeight: "90vh", overflow: "hidden", display: "flex", flexDirection: "column", boxShadow: "0 -20px 60px rgba(15,23,42,0.2)" }}>
            <div style={{ height: "240px", background: "#E2E8F0", flexShrink: 0, position: "relative", overflow: "hidden" }}>
              <img src={`https://images.unsplash.com/${detail.img}?w=1200&h=500&fit=crop&auto=format`} alt={detail.id} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(0deg, rgba(15,23,42,0.5) 0%, transparent 50%)" }} />
              <button onClick={() => setDetail(null)} style={{ position: "absolute", top: "14px", right: "14px", width: "32px", height: "32px", borderRadius: "50%", border: "none", background: "rgba(15,23,42,0.5)", color: "#fff", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
              <div style={{ position: "absolute", bottom: "14px", left: "18px" }}>
                <Badge label={detail.status} color={STATUS_C[detail.status]?.color ?? C.green} bg={STATUS_C[detail.status]?.bg ?? C.gBg} border={STATUS_C[detail.status]?.border} />
              </div>
            </div>
            <div style={{ padding: "22px 24px", overflowY: "auto", flex: 1 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "16px" }}>
                <div>
                  <h3 style={{ fontSize: "22px", fontWeight: 800, color: C.text, fontFamily: FH, letterSpacing: "-0.01em" }}>{detail.type} · Unit {detail.id}</h3>
                  <p style={{ fontSize: "13px", color: C.muted, fontFamily: FB }}>Floor {detail.floor} · {detail.orientation} facing · {detail.sqft.toLocaleString()} sqft</p>
                </div>
                <div style={{ textAlign: "right" }}>
                  <p style={{ fontSize: "24px", fontWeight: 800, color: C.text, fontFamily: FH, letterSpacing: "-0.02em" }}>{fmtPrice(detail.price)}</p>
                  <p style={{ fontSize: "13px", color: C.green, fontWeight: 600, fontFamily: FB }}>${Math.round(detail.monthlyRent / 30).toLocaleString()}/night · ${detail.monthlyRent.toLocaleString()}/month</p>
                </div>
              </div>

              <p style={{ fontSize: "14px", color: C.text2, lineHeight: 1.6, marginBottom: "16px", fontFamily: FB }}>{detail.view}</p>

              {/* Specs */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "10px", marginBottom: "18px" }}>
                {[["Unit ID", detail.id], ["Floor", String(detail.floor)], ["Size", `${detail.sqft.toLocaleString()} sqft`], ["Type", detail.type], ["Orientation", detail.orientation], ["Monthly Rent", `$${detail.monthlyRent.toLocaleString()}`]].map(([k, v]) => (
                  <div key={k} style={{ padding: "10px 12px", background: "#F8FAFC", border: `1px solid ${C.border}`, borderRadius: "8px" }}>
                    <p style={{ fontSize: "10px", fontWeight: 700, color: C.dim, letterSpacing: "0.05em", fontFamily: FB }}>{k.toUpperCase()}</p>
                    <p style={{ fontSize: "13px", fontWeight: 600, color: C.text, fontFamily: FM, marginTop: "2px" }}>{v}</p>
                  </div>
                ))}
              </div>

              {/* Features */}
              {detail.features.length > 0 && (
                <div style={{ marginBottom: "20px" }}>
                  <p style={{ fontSize: "11px", fontWeight: 700, color: C.muted, letterSpacing: "0.05em", marginBottom: "8px", fontFamily: FB }}>FEATURES & AMENITIES</p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
                    {detail.features.map(f => <Badge key={f} label={f} color={C.blue} bg={C.bBg} />)}
                  </div>
                </div>
              )}

              {/* Payment preview */}
              {detail.status === "Available" && (
                <div style={{ padding: "14px 16px", background: "#F0FDF4", border: `1px solid ${C.gBdr}`, borderRadius: "10px", marginBottom: "20px" }}>
                  <p style={{ fontSize: "11px", fontWeight: 700, color: C.green, letterSpacing: "0.05em", marginBottom: "10px", fontFamily: FB }}>PAYMENT PREVIEW (20% DEPOSIT)</p>
                  <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: "10px" }}>
                    {[["Reservation Deposit", `$${Math.round(detail.price * 0.20).toLocaleString()}`], ["Balance Remaining", `$${Math.round(detail.price * 0.80).toLocaleString()}`], ["Monthly (36mo)", `$${Math.round(detail.price * 0.80 / 36).toLocaleString()}/mo`]].map(([k, v]) => (
                      <div key={k}>
                        <p style={{ fontSize: "10px", color: C.green, fontWeight: 600, fontFamily: FB }}>{k}</p>
                        <p style={{ fontSize: "15px", fontWeight: 800, color: C.navy, fontFamily: FH }}>{v}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {detail.status === "Available" && (
                <div style={{ display: "flex", gap: "10px" }}>
                  <button onClick={() => { setDetail(null); onOpenUnit(detail, "reserve"); }} style={{ flex: 1, padding: "12px", background: C.gBg, border: `1px solid ${C.gBdr}`, borderRadius: "10px", fontSize: "14px", fontWeight: 700, color: C.green, cursor: "pointer", fontFamily: FH, transition: "all 0.15s" }}
                    onMouseEnter={e => Object.assign((e.currentTarget as HTMLElement).style, { background: C.green, color: "#fff" })}
                    onMouseLeave={e => Object.assign((e.currentTarget as HTMLElement).style, { background: C.gBg, color: C.green })}>
                    Reserve This Unit
                  </button>
                  <button onClick={() => { setDetail(null); onOpenUnit(detail, "buy"); }} style={{ flex: 1, padding: "12px", background: C.navy, border: `1px solid ${C.navy}`, borderRadius: "10px", fontSize: "14px", fontWeight: 700, color: "#fff", cursor: "pointer", fontFamily: FH, transition: "background 0.15s" }}
                    onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = "#1E293B")}
                    onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = C.navy)}>
                    Purchase Inquiry
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── RESERVATION MODAL (3-step) ─────────────────────────────────────────────
function ReservationModal({ unit, defaultMode, user, onClose, onSuccess }: {
  unit: Unit; defaultMode: "reserve" | "buy"; user: ClientUser;
  onClose: () => void; onSuccess: (r: Reservation) => void;
}) {
  const { addReservation } = useReservations();
  const { addThread } = useMessages();
  const [step, setStep] = useState(1);

  // Step 1 — Type & dates
  const [type, setType] = useState<ReservationType>(defaultMode === "buy" ? "Purchase Inquiry" : "Short Stay");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [term, setTerm] = useState(36);

  // Step 2 — Payment
  const [depositPct, setDepositPct] = useState(20);
  const [payMode, setPayMode] = useState("Wire Transfer");

  // Step 3 — Contact (pre-filled from user profile)
  const [cName, setCName] = useState(user.name);
  const [cEmail, setCEmail] = useState(user.email);
  const [cPhone, setCPhone] = useState(user.phone ?? "");
  const [notes, setNotes] = useState("");

  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [result, setResult] = useState<Reservation | null>(null);

  const nightly = Math.round(unit.monthlyRent / 30);
  const nights = checkIn && checkOut ? Math.max(0, Math.round((new Date(checkOut).getTime() - new Date(checkIn).getTime()) / 86_400_000)) : 0;
  const depositAmt = Math.round(unit.price * (depositPct / 100));
  const balance = unit.price - depositAmt;
  const monthly = term > 0 ? Math.round(balance / term) : 0;

  const INP: React.CSSProperties = { width: "100%", padding: "10px 12px", border: `1px solid ${C.border}`, borderRadius: "8px", background: "#fff", color: C.text, fontSize: "14px", outline: "none", fontFamily: FB, boxSizing: "border-box", transition: "border-color 0.15s" };
  const fo = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => (e.target.style.borderColor = C.green);
  const bl = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => (e.target.style.borderColor = C.border);
  const LBL: React.CSSProperties = { display: "block", fontSize: "11px", fontWeight: 700, color: C.muted, letterSpacing: "0.05em", marginBottom: "5px", fontFamily: FB };

  function handleConfirm() {
    setLoading(true);
    setTimeout(() => {
      const res = addReservation({
        unitId: unit.id, unitLabel: `Unit ${unit.id}`, unitType: unit.type,
        floor: unit.floor, img: unit.img, price: unit.price, monthlyRent: unit.monthlyRent,
        clientName: cName, clientEmail: cEmail, clientPhone: cPhone,
        type, checkIn: checkIn || new Date().toISOString().slice(0, 10),
        checkOut: checkOut || checkIn || new Date().toISOString().slice(0, 10),
        nights, depositAmount: depositAmt, paymentMethod: payMode, notes,
      });
      // Create message thread
      const agents = ["Alexandra Chen", "Marcus Torres", "Jordan Carter", "Priya Singh", "Lena Brauer"];
      const agentColors = ["#059669", "#0284C7", "#7C3AED", "#D97706", "#DC2626"];
      const idx = Math.floor(Math.random() * agents.length);
      addThread({ id: `THR-${res.id}`, reservationId: res.id, unitLabel: `Unit ${unit.id} · ${unit.type} · Floor ${unit.floor}`, agentName: agents[idx], agentInitials: agents[idx].split(" ").map(n => n[0]).join(""), agentColor: agentColors[idx] });
      setResult(res);
      setDone(true);
      setLoading(false);
    }, 900);
  }

  const STEP_LABELS = ["Type & Dates", "Payment Setup", "Contact Info", "Confirm & Pay"];

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 200, background: "rgba(15,23,42,0.65)", backdropFilter: "blur(6px)", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}
      onClick={e => { if (!done && e.target === e.currentTarget) onClose(); }}>
      <div style={{ background: C.card, borderRadius: "16px", width: "100%", maxWidth: "600px", maxHeight: "92vh", overflow: "hidden", display: "flex", flexDirection: "column", boxShadow: "0 24px 80px rgba(15,23,42,0.3)" }}>

        {/* Header */}
        <div style={{ padding: "20px 24px 16px", borderBottom: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 }}>
          <div>
            <h3 style={{ fontSize: "18px", fontWeight: 800, color: C.text, fontFamily: FH, letterSpacing: "-0.01em" }}>
              {defaultMode === "reserve" ? "Reserve Unit" : "Purchase Inquiry"} · {unit.id}
            </h3>
            {!done && (
              <div style={{ display: "flex", alignItems: "center", gap: "6px", marginTop: "6px" }}>
                {STEP_LABELS.map((s, i) => (
                  <div key={s} style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <div style={{ width: "20px", height: "20px", borderRadius: "50%", background: step > i + 1 ? C.green : step === i + 1 ? C.navy : C.border, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "10px", fontWeight: 700, color: step >= i + 1 ? "#fff" : C.dim, flexShrink: 0, transition: "background 0.2s" }}>
                      {step > i + 1 ? "✓" : i + 1}
                    </div>
                    <span style={{ fontSize: "10px", color: step === i + 1 ? C.text : C.dim, fontFamily: FB, fontWeight: step === i + 1 ? 600 : 400, whiteSpace: "nowrap" }}>{s}</span>
                    {i < STEP_LABELS.length - 1 && <div style={{ width: "16px", height: "1px", background: step > i + 1 ? C.green : C.border, marginLeft: "2px" }} />}
                  </div>
                ))}
              </div>
            )}
          </div>
          {!done && <button onClick={onClose} style={{ width: "32px", height: "32px", border: `1px solid ${C.border}`, borderRadius: "50%", background: "#F8FAFC", fontSize: "16px", cursor: "pointer", color: C.muted, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>×</button>}
        </div>

        {/* Body */}
        <div style={{ overflowY: "auto", flex: 1, padding: "20px 24px" }}>

          {/* Unit summary strip */}
          <div style={{ display: "flex", gap: "12px", padding: "12px 14px", background: "#F8FAFC", border: `1px solid ${C.border}`, borderRadius: "10px", marginBottom: "22px" }}>
            <div style={{ width: "68px", height: "54px", borderRadius: "7px", overflow: "hidden", flexShrink: 0, background: C.border }}>
              <img src={`https://images.unsplash.com/${unit.img}?w=160&h=120&fit=crop&auto=format`} alt={unit.id} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            </div>
            <div style={{ flex: 1 }}>
              <p style={{ fontSize: "14px", fontWeight: 700, color: C.text, fontFamily: FH }}>Unit {unit.id} · {unit.type} · Floor {unit.floor}</p>
              <p style={{ fontSize: "12px", color: C.muted, fontFamily: FB }}>{unit.sqft.toLocaleString()} sqft · {unit.orientation} · {unit.view}</p>
            </div>
            <div style={{ textAlign: "right", flexShrink: 0 }}>
              <p style={{ fontSize: "16px", fontWeight: 800, color: C.text, fontFamily: FH }}>{fmtPrice(unit.price)}</p>
              <p style={{ fontSize: "11px", color: C.green, fontWeight: 600, fontFamily: FB }}>${unit.monthlyRent.toLocaleString()}/mo</p>
            </div>
          </div>

          {/* ── SUCCESS ── */}
          {done && result && (
            <div>
              <div style={{ textAlign: "center", marginBottom: "24px" }}>
                <div style={{ width: "60px", height: "60px", borderRadius: "50%", background: C.gBg, border: `1px solid ${C.gBdr}`, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px", fontSize: "26px" }}>✓</div>
                <h3 style={{ fontSize: "22px", fontWeight: 800, color: C.text, fontFamily: FH, marginBottom: "6px" }}>
                  {type === "Purchase Inquiry" ? "Purchase Inquiry Submitted" : "Reservation Confirmed"}
                </h3>
                <p style={{ fontSize: "14px", color: C.muted, fontFamily: FB, lineHeight: 1.6 }}>
                  Reference <strong style={{ color: C.text, fontFamily: FM }}>{result.id}</strong> · An agent will contact you at {cEmail} within 2 business hours.
                </p>
              </div>

              {/* Full receipt */}
              <div style={{ background: "#F8FAFC", border: `1px solid ${C.border}`, borderRadius: "12px", overflow: "hidden" }}>
                <div style={{ padding: "12px 16px", background: C.navy, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <p style={{ fontSize: "13px", fontWeight: 700, color: "#F1F5F9", fontFamily: FH }}>PAYMENT RECEIPT</p>
                    <p style={{ fontSize: "10px", color: "rgba(241,245,249,0.5)", fontFamily: FM }}>{result.id} · {fmtDt(result.createdAt)}</p>
                  </div>
                  <Badge label={type} color={TYPE_C[type]?.color ?? C.green} bg="rgba(255,255,255,0.1)" border="rgba(255,255,255,0.15)" />
                </div>
                <div style={{ padding: "16px" }}>
                  {[
                    ["Property", `Unit ${unit.id} · ${unit.type} · Floor ${unit.floor}`],
                    ["Unit Price", fmtPrice(unit.price)],
                    null,
                    [`Reservation Deposit (${depositPct}%)`, `$${depositAmt.toLocaleString()}`],
                    ["Mode of Payment", payMode],
                    null,
                    ["Balance Remaining", `$${balance.toLocaleString()}`],
                    ["Payment Term", `${term} months`],
                    ["Monthly Payment", `$${monthly.toLocaleString()}/mo`],
                    null,
                    ["TOTAL PROPERTY COST", fmtPrice(unit.price)],
                  ].map((row, i) => {
                    if (!row) return <div key={i} style={{ borderTop: `1px dashed ${C.border}`, margin: "8px 0" }} />;
                    const [k, v] = row;
                    const isTotal = k.startsWith("TOTAL");
                    return (
                      <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "5px 0" }}>
                        <span style={{ fontSize: isTotal ? "13px" : "12px", fontWeight: isTotal ? 700 : 400, color: isTotal ? C.text : C.muted, fontFamily: isTotal ? FH : FB }}>{k}</span>
                        <span style={{ fontSize: isTotal ? "15px" : "13px", fontWeight: isTotal ? 800 : 600, color: isTotal ? C.green : C.text, fontFamily: FM }}>{v}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div style={{ display: "flex", gap: "10px", marginTop: "18px" }}>
                <button onClick={() => onSuccess(result)} style={{ flex: 1, padding: "11px", background: C.green, border: "none", borderRadius: "9px", fontSize: "13px", fontWeight: 700, color: "#fff", cursor: "pointer", fontFamily: FH }}>View My Reservations →</button>
                <button onClick={onClose} style={{ flex: 1, padding: "11px", background: "none", border: `1px solid ${C.border}`, borderRadius: "9px", fontSize: "13px", color: C.muted, cursor: "pointer", fontFamily: FB }}>Continue Browsing</button>
              </div>
            </div>
          )}

          {/* ── STEP 1: Type & Dates ── */}
          {!done && step === 1 && (
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              <div>
                <label style={LBL}>RESERVATION TYPE</label>
                <div style={{ display: "flex", gap: "6px" }}>
                  {(["Short Stay", "Long-Term Lease", "Purchase Inquiry"] as ReservationType[]).map(t => {
                    const on = type === t; const col = TYPE_C[t];
                    return (
                      <button key={t} type="button" onClick={() => setType(t)} style={{ flex: 1, padding: "9px 6px", border: `1px solid ${on ? col.color : C.border}`, borderRadius: "8px", background: on ? col.bg : "#fff", fontSize: "12px", fontWeight: on ? 700 : 400, color: on ? col.color : C.muted, cursor: "pointer", transition: "all 0.12s", textAlign: "center", fontFamily: FB }}>
                        {t}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: type === "Purchase Inquiry" ? "1fr" : "1fr 1fr", gap: "12px" }}>
                <div>
                  <label style={LBL}>{type === "Short Stay" ? "CHECK-IN DATE" : "START DATE"} *</label>
                  <input type="date" value={checkIn} onChange={e => setCheckIn(e.target.value)} required style={INP} onFocus={fo} onBlur={bl} />
                </div>
                {type !== "Purchase Inquiry" && (
                  <div>
                    <label style={LBL}>{type === "Short Stay" ? "CHECK-OUT DATE" : "END DATE"}</label>
                    <input type="date" value={checkOut} onChange={e => setCheckOut(e.target.value)} min={checkIn} style={INP} onFocus={fo} onBlur={bl} />
                  </div>
                )}
              </div>
              {nights > 0 && (
                <div style={{ padding: "10px 14px", background: "#F0FDF4", border: `1px solid ${C.gBdr}`, borderRadius: "8px", display: "flex", justifyContent: "space-between" }}>
                  <span style={{ fontSize: "13px", color: C.muted, fontFamily: FB }}>{nights} night{nights !== 1 ? "s" : ""}</span>
                  {type === "Short Stay" && <span style={{ fontSize: "13px", fontWeight: 700, color: C.green, fontFamily: FM }}>${(nightly * nights).toLocaleString()} est.</span>}
                </div>
              )}
              {type === "Purchase Inquiry" || type === "Long-Term Lease" ? (
                <div>
                  <label style={LBL}>INSTALLMENT TERM</label>
                  <div style={{ display: "flex", gap: "6px" }}>
                    {[12, 24, 36, 48, 60].map(t => (
                      <button key={t} type="button" onClick={() => setTerm(t)} style={{ flex: 1, padding: "8px 4px", border: `1px solid ${term === t ? C.green : C.border}`, borderRadius: "7px", background: term === t ? C.gBg : "#fff", fontSize: "12px", fontWeight: term === t ? 700 : 400, color: term === t ? C.green : C.muted, cursor: "pointer", fontFamily: FM, transition: "all 0.12s" }}>
                        {t}mo
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          )}

          {/* ── STEP 2: Payment Setup ── */}
          {!done && step === 2 && (
            <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
              <div>
                <label style={LBL}>DEPOSIT PERCENTAGE</label>
                <p style={{ fontSize: "12px", color: C.muted, marginBottom: "8px", fontFamily: FB }}>Select how much you will pay upfront as a reservation deposit.</p>
                <div style={{ display: "flex", gap: "6px" }}>
                  {[10, 15, 20, 25, 30].map(pct => (
                    <button key={pct} type="button" onClick={() => setDepositPct(pct)} style={{ flex: 1, padding: "12px 6px", border: `1px solid ${depositPct === pct ? C.green : C.border}`, borderRadius: "8px", background: depositPct === pct ? C.gBg : "#fff", cursor: "pointer", textAlign: "center", transition: "all 0.12s" }}>
                      <p style={{ fontSize: "16px", fontWeight: 800, color: depositPct === pct ? C.green : C.text, fontFamily: FH }}>{pct}%</p>
                      <p style={{ fontSize: "10px", color: C.muted, fontFamily: FM, marginTop: "2px" }}>${Math.round(unit.price * pct / 100 / 1000).toLocaleString()}K</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Payment breakdown preview */}
              <div style={{ padding: "14px 16px", background: "#F0FDF4", border: `1px solid ${C.gBdr}`, borderRadius: "10px" }}>
                <p style={{ fontSize: "11px", fontWeight: 700, color: C.green, letterSpacing: "0.05em", marginBottom: "10px", fontFamily: FB }}>PAYMENT BREAKDOWN</p>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {[
                    ["Unit Price", fmtPrice(unit.price), false],
                    [`Deposit (${depositPct}%)`, `$${depositAmt.toLocaleString()}`, false],
                    ["Balance", `$${balance.toLocaleString()}`, false],
                    [`Monthly (${term}mo)`, `$${monthly.toLocaleString()}/mo`, true],
                  ].map(([k, v, bold]) => (
                    <div key={k as string} style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ fontSize: "12px", color: C.muted, fontFamily: FB }}>{k as string}</span>
                      <span style={{ fontSize: bold ? "14px" : "13px", fontWeight: bold ? 800 : 600, color: bold ? C.green : C.text, fontFamily: FM }}>{v as string}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label style={LBL}>MODE OF PAYMENT</label>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
                  {["Wire Transfer", "Credit Card", "Crypto (USDC)", "Crypto (BTC)", "Bank Check", "Cash"].map(m => (
                    <button key={m} type="button" onClick={() => setPayMode(m)} style={{ padding: "11px 12px", border: `1px solid ${payMode === m ? C.green : C.border}`, borderRadius: "8px", background: payMode === m ? C.gBg : "#fff", fontSize: "13px", fontWeight: payMode === m ? 700 : 400, color: payMode === m ? C.green : C.text2, cursor: "pointer", textAlign: "left", fontFamily: FB, transition: "all 0.12s", display: "flex", alignItems: "center", gap: "6px" }}>
                      <span>{m === "Wire Transfer" ? "🏦" : m === "Credit Card" ? "💳" : m.startsWith("Crypto") ? "₿" : m === "Bank Check" ? "📄" : "💵"}</span>
                      <span>{m}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── STEP 3: Contact Info ── */}
          {!done && step === 3 && (
            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              <p style={{ fontSize: "13px", color: C.muted, fontFamily: FB, marginBottom: "4px" }}>Your profile information has been pre-filled. Please verify before continuing.</p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                <div>
                  <label style={LBL}>FULL NAME *</label>
                  <input value={cName} onChange={e => setCName(e.target.value)} required style={INP} onFocus={fo} onBlur={bl} />
                </div>
                <div>
                  <label style={LBL}>PHONE</label>
                  <input type="tel" value={cPhone} onChange={e => setCPhone(e.target.value)} placeholder="+1 (305) 555-0000" style={INP} onFocus={fo} onBlur={bl} />
                </div>
              </div>
              <div>
                <label style={LBL}>EMAIL ADDRESS *</label>
                <input type="email" value={cEmail} onChange={e => setCEmail(e.target.value)} required style={INP} onFocus={fo} onBlur={bl} />
              </div>
              <div>
                <label style={LBL}>ADDITIONAL NOTES</label>
                <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3} placeholder="Special requests or preferences…" style={{ ...INP, resize: "vertical" }} onFocus={fo} onBlur={bl} />
              </div>
            </div>
          )}

          {/* ── STEP 4: Confirm ── */}
          {!done && step === 4 && (
            <div>
              <p style={{ fontSize: "14px", color: C.text2, fontFamily: FB, marginBottom: "16px", lineHeight: 1.6 }}>
                Review your complete reservation details before submitting.
              </p>

              {/* Full receipt preview */}
              <div style={{ background: "#F8FAFC", border: `1px solid ${C.border}`, borderRadius: "12px", overflow: "hidden", marginBottom: "16px" }}>
                <div style={{ padding: "12px 16px", background: C.navy }}>
                  <p style={{ fontSize: "13px", fontWeight: 700, color: "#F1F5F9", fontFamily: FH }}>RESERVATION RECEIPT PREVIEW</p>
                </div>
                <div style={{ padding: "14px 16px", display: "flex", flexDirection: "column", gap: "0" }}>
                  {[
                    ["Unit", `${unit.id} · ${unit.type} · Floor ${unit.floor}`],
                    ["Unit Price", fmtPrice(unit.price)],
                    [null, null],
                    [`Reservation Deposit (${depositPct}%)`, `$${depositAmt.toLocaleString()}`],
                    ["Mode of Payment", payMode],
                    [null, null],
                    ["Balance Remaining", `$${balance.toLocaleString()}`],
                    ["Payment Term", `${term} months`],
                    ["Monthly Payment", `$${monthly.toLocaleString()}/mo`],
                    [null, null],
                    ["Client Name", cName],
                    ["Email", cEmail],
                    ["Type", type],
                    ...(checkIn ? [["Check-in", fmtDt(checkIn)]] : []),
                    [null, null],
                    ["TOTAL PROPERTY COST", fmtPrice(unit.price)],
                  ].map((row, i) => {
                    if (!row[0]) return <div key={i} style={{ borderTop: `1px dashed ${C.border}`, margin: "6px 0" }} />;
                    const [k, v] = row;
                    const isTotal = (k as string).startsWith("TOTAL");
                    return (
                      <div key={k as string} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0" }}>
                        <span style={{ fontSize: isTotal ? "13px" : "12px", fontWeight: isTotal ? 700 : 400, color: isTotal ? C.text : C.muted, fontFamily: FB }}>{k as string}</span>
                        <span style={{ fontSize: isTotal ? "15px" : "13px", fontWeight: isTotal ? 800 : 600, color: isTotal ? C.green : C.text, fontFamily: FM }}>{v as string}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer nav */}
        {!done && (
          <div style={{ padding: "16px 24px", borderTop: `1px solid ${C.border}`, display: "flex", gap: "10px", flexShrink: 0, background: C.card }}>
            {step > 1 && <button type="button" onClick={() => setStep(s => s - 1)} style={{ padding: "10px 20px", border: `1px solid ${C.border}`, borderRadius: "9px", background: "none", fontSize: "13px", color: C.muted, cursor: "pointer", fontFamily: FB }}>← Back</button>}
            {step < 4 ? (
              <button type="button" onClick={() => setStep(s => s + 1)} disabled={step === 1 && !checkIn && type !== "Purchase Inquiry"} style={{ flex: 1, padding: "11px", background: C.navy, border: "none", borderRadius: "9px", fontSize: "14px", fontWeight: 700, color: "#fff", cursor: "pointer", fontFamily: FH, transition: "background 0.15s" }}
                onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = "#1E293B")}
                onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = C.navy)}>
                Continue →
              </button>
            ) : (
              <button type="button" onClick={handleConfirm} disabled={loading || !cName || !cEmail} style={{ flex: 1, padding: "11px", background: C.green, border: "none", borderRadius: "9px", fontSize: "14px", fontWeight: 700, color: "#fff", cursor: loading ? "not-allowed" : "pointer", fontFamily: FH, opacity: loading ? 0.8 : 1 }}>
                {loading ? "Submitting…" : "Confirm Reservation →"}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ── MY RESERVATIONS ────────────────────────────────────────────────────────
function MyReservations({ onOpenUnit }: { onOpenUnit: (unit: Unit, mode: "reserve" | "buy") => void }) {
  const { reservations } = useReservations();
  const { units } = useBooking();
  const [filter, setFilter] = useState<"All" | "Pending" | "Confirmed" | "Cancelled" | "Completed">("All");

  const filtered = filter === "All" ? reservations : reservations.filter(r => r.status === filter);

  return (
    <div>
      {/* Filter tabs */}
      <div style={{ display: "flex", gap: "6px", marginBottom: "20px" }}>
        {(["All", "Pending", "Confirmed", "Cancelled", "Completed"] as const).map(s => {
          const on = filter === s;
          const m = s !== "All" ? STATUS_META[s] : null;
          const cnt = s === "All" ? reservations.length : reservations.filter(r => r.status === s).length;
          return (
            <button key={s} onClick={() => setFilter(s)} style={{ padding: "6px 14px", border: `1px solid ${on && m ? m.color : on ? C.navy : C.border}`, borderRadius: "100px", background: on && m ? m.bg : on ? "#F1F5F9" : "#fff", color: on && m ? m.color : on ? C.navy : C.muted, fontSize: "12px", fontWeight: on ? 700 : 400, cursor: "pointer", fontFamily: FB, transition: "all 0.12s" }}>
              {s} <span style={{ fontFamily: FM, fontSize: "10px" }}>({cnt})</span>
            </button>
          );
        })}
      </div>

      {filtered.length === 0 ? (
        <div style={{ padding: "64px", textAlign: "center", background: C.card, border: `1px solid ${C.border}`, borderRadius: "12px" }}>
          <p style={{ fontSize: "26px", marginBottom: "10px" }}>📋</p>
          <p style={{ fontSize: "16px", fontWeight: 700, color: C.text, fontFamily: FH }}>No reservations yet</p>
          <p style={{ fontSize: "13px", color: C.muted, marginTop: "4px", fontFamily: FB }}>Browse the catalog and make your first reservation.</p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
          {filtered.map(r => {
            const sm = STATUS_META[r.status];
            const tc = TYPE_C[r.type];
            const depositPct = Math.round((r.depositAmount / r.price) * 100);
            const balance = r.price - r.depositAmount;
            const monthly = Math.round(balance / 36);
            return (
              <div key={r.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: "14px", overflow: "hidden", boxShadow: "0 1px 3px rgba(15,23,42,0.04)" }}>
                {/* Top bar */}
                <div style={{ display: "flex", gap: "0", overflow: "hidden" }}>
                  <div style={{ width: "130px", flexShrink: 0, background: C.border }}>
                    <img src={`https://images.unsplash.com/${r.img}?w=260&h=200&fit=crop&auto=format`} alt={r.unitLabel} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  </div>
                  <div style={{ flex: 1, padding: "16px 18px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "8px" }}>
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: "7px", marginBottom: "4px" }}>
                          <p style={{ fontSize: "15px", fontWeight: 700, color: C.text, fontFamily: FH }}>{r.unitLabel}</p>
                          <Badge label={sm.label} color={sm.color} bg={sm.bg} />
                          <Badge label={r.type} color={tc?.color ?? C.green} bg={tc?.bg ?? C.gBg} />
                        </div>
                        <p style={{ fontSize: "12px", color: C.muted, fontFamily: FB }}>Floor {r.floor} · {fmtDt(r.checkIn)} · Agent: {r.agent}</p>
                      </div>
                      <div style={{ textAlign: "right", flexShrink: 0 }}>
                        <p style={{ fontSize: "11px", color: C.muted, fontFamily: FM }}>{r.id}</p>
                        <p style={{ fontSize: "11px", color: C.dim, fontFamily: FB }}>Filed {fmtDt(r.createdAt)}</p>
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: "0" }}>
                      {[["Unit Price", fmtPrice(r.price)], [`Deposit (${depositPct}%)`, `$${r.depositAmount.toLocaleString()}`], ["Balance", `$${balance.toLocaleString()}`], ["Monthly (36mo)", `$${monthly.toLocaleString()}/mo`]].map(([k, v], i, arr) => (
                        <div key={k} style={{ flex: 1, paddingRight: i < arr.length - 1 ? "12px" : 0, borderRight: i < arr.length - 1 ? `1px solid ${C.border}` : "none", marginRight: i < arr.length - 1 ? "12px" : 0 }}>
                          <p style={{ fontSize: "10px", fontWeight: 700, color: C.dim, letterSpacing: "0.04em", fontFamily: FB }}>{k}</p>
                          <p style={{ fontSize: "13px", fontWeight: 700, color: C.text, fontFamily: FM, marginTop: "2px" }}>{v}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Receipt accordion */}
                <ReceiptStrip r={r} />
              </div>
            );
          })}
        </div>
      )}

      {/* Quick reserve CTA */}
      {reservations.length > 0 && (
        <div style={{ marginTop: "20px", padding: "18px 20px", background: "#F0FDF4", border: `1px solid ${C.gBdr}`, borderRadius: "12px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <p style={{ fontSize: "14px", fontWeight: 700, color: C.text, fontFamily: FH, marginBottom: "3px" }}>Looking for more units?</p>
            <p style={{ fontSize: "12px", color: C.muted, fontFamily: FB }}>Browse all {units.filter(u => u.status === "Available").length} available units in the catalog.</p>
          </div>
        </div>
      )}
    </div>
  );
}

function ReceiptStrip({ r }: { r: Reservation }) {
  const [open, setOpen] = useState(false);
  const depositPct = Math.round((r.depositAmount / r.price) * 100);
  const balance = r.price - r.depositAmount;
  const monthly = Math.round(balance / 36);

  return (
    <>
      <button onClick={() => setOpen(v => !v)} style={{ width: "100%", padding: "10px 18px", background: "#F8FAFC", border: "none", borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer", transition: "background 0.12s" }}
        onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = "#F1F5F9")}
        onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = "#F8FAFC")}>
        <span style={{ fontSize: "12px", fontWeight: 600, color: C.text2, fontFamily: FH }}>View Payment Receipt</span>
        <span style={{ fontSize: "14px", color: C.muted, transform: open ? "rotate(180deg)" : "none", display: "inline-block", transition: "transform 0.2s" }}>⌄</span>
      </button>
      {open && (
        <div style={{ padding: "14px 18px", background: "#FAFBFC", borderTop: `1px solid ${C.border}` }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
            <div>
              <p style={{ fontSize: "10px", fontWeight: 700, color: C.muted, letterSpacing: "0.05em", marginBottom: "10px", fontFamily: FB }}>PAYMENT BREAKDOWN</p>
              {[["Unit Price", fmtPrice(r.price)], [`Deposit (${depositPct}%)`, `$${r.depositAmount.toLocaleString()}`], ["Balance Remaining", `$${balance.toLocaleString()}`], ["Monthly (36 months)", `$${monthly.toLocaleString()}/mo`], ["Payment Method", r.paymentMethod]].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", borderBottom: `1px solid ${C.border}`, padding: "5px 0" }}>
                  <span style={{ fontSize: "12px", color: C.muted, fontFamily: FB }}>{k}</span>
                  <span style={{ fontSize: "12px", fontWeight: 600, color: C.text, fontFamily: FM }}>{v}</span>
                </div>
              ))}
            </div>
            <div>
              <p style={{ fontSize: "10px", fontWeight: 700, color: C.muted, letterSpacing: "0.05em", marginBottom: "10px", fontFamily: FB }}>RESERVATION DETAILS</p>
              {[["Ref ID", r.id], ["Type", r.type], ["Check-in", fmtDt(r.checkIn)], ...(r.nights > 0 ? [["Duration", `${r.nights} nights`]] : []), ["Agent", r.agent], ["Filed", fmtDt(r.createdAt)]].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", borderBottom: `1px solid ${C.border}`, padding: "5px 0" }}>
                  <span style={{ fontSize: "12px", color: C.muted, fontFamily: FB }}>{k}</span>
                  <span style={{ fontSize: "12px", fontWeight: 600, color: C.text, fontFamily: k === "Ref ID" ? FM : FB }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ── MESSAGES ──────────────────────────────────────────────────────────────
function Messages({ user }: { user: ClientUser }) {
  const { threads, sendMessage, markRead } = useMessages();
  const [activeId, setActiveId] = useState<string | null>(threads[0]?.id ?? null);
  const [msg, setMsg] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const active = threads.find(t => t.id === activeId);

  useEffect(() => {
    if (activeId) { markRead(activeId); }
  }, [activeId, threads]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [active?.messages.length]);

  function send() {
    if (!msg.trim() || !activeId) return;
    sendMessage(activeId, msg.trim(), user.name);
    setMsg("");
  }

  if (threads.length === 0) {
    return (
      <div style={{ padding: "64px", textAlign: "center", background: C.card, border: `1px solid ${C.border}`, borderRadius: "12px" }}>
        <p style={{ fontSize: "26px", marginBottom: "10px" }}>💬</p>
        <p style={{ fontSize: "16px", fontWeight: 700, color: C.text, fontFamily: FH }}>No conversations yet</p>
        <p style={{ fontSize: "13px", color: C.muted, fontFamily: FB, marginTop: "4px" }}>Once you make a reservation, your assigned agent will reach out here.</p>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", background: C.card, border: `1px solid ${C.border}`, borderRadius: "14px", overflow: "hidden", height: "580px" }}>
      {/* Thread list */}
      <div style={{ width: "260px", flexShrink: 0, borderRight: `1px solid ${C.border}`, overflowY: "auto" }}>
        <div style={{ padding: "14px 16px", borderBottom: `1px solid ${C.border}` }}>
          <p style={{ fontSize: "14px", fontWeight: 700, color: C.text, fontFamily: FH }}>Conversations</p>
          <p style={{ fontSize: "11px", color: C.muted, fontFamily: FB, marginTop: "2px" }}>{threads.length} thread{threads.length !== 1 ? "s" : ""}</p>
        </div>
        {threads.map(t => {
          const unread = t.messages.filter(m => m.from === "agent" && !m.read).length;
          const last = t.messages[t.messages.length - 1];
          return (
            <button key={t.id} onClick={() => setActiveId(t.id)} style={{ width: "100%", padding: "13px 16px", background: activeId === t.id ? "#F0FDF4" : "transparent", border: "none", borderBottom: `1px solid ${C.border}`, borderLeft: `3px solid ${activeId === t.id ? C.green : "transparent"}`, textAlign: "left", cursor: "pointer", transition: "background 0.12s" }}
              onMouseEnter={e => { if (activeId !== t.id) (e.currentTarget as HTMLElement).style.background = "#F8FAFC"; }}
              onMouseLeave={e => { if (activeId !== t.id) (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "4px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "7px" }}>
                  <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: t.agentColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "10px", fontWeight: 700, color: "#fff", fontFamily: FH, flexShrink: 0 }}>{t.agentInitials}</div>
                  <p style={{ fontSize: "12px", fontWeight: 700, color: C.text, fontFamily: FH }}>{t.agentName}</p>
                </div>
                {unread > 0 && <span style={{ padding: "1px 6px", background: C.green, borderRadius: "100px", fontSize: "10px", fontWeight: 700, color: "#fff", fontFamily: FM }}>{unread}</span>}
              </div>
              <p style={{ fontSize: "11px", color: C.muted, fontFamily: FB, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.unitLabel}</p>
              {last && <p style={{ fontSize: "11px", color: C.dim, fontFamily: FB, marginTop: "2px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{last.text}</p>}
            </button>
          );
        })}
      </div>

      {/* Chat area */}
      {active ? (
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          {/* Chat header */}
          <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: "10px", flexShrink: 0 }}>
            <div style={{ width: "36px", height: "36px", borderRadius: "50%", background: active.agentColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "13px", fontWeight: 700, color: "#fff", fontFamily: FH, flexShrink: 0 }}>{active.agentInitials}</div>
            <div>
              <p style={{ fontSize: "14px", fontWeight: 700, color: C.text, fontFamily: FH }}>{active.agentName}</p>
              <p style={{ fontSize: "11px", color: C.muted, fontFamily: FB }}>{active.unitLabel}</p>
            </div>
          </div>

          {/* Messages */}
          <div style={{ flex: 1, overflowY: "auto", padding: "16px 18px", display: "flex", flexDirection: "column", gap: "12px", background: "#FAFBFC" }}>
            {active.messages.map(m => {
              const isMe = m.from === "client";
              return (
                <div key={m.id} style={{ display: "flex", justifyContent: isMe ? "flex-end" : "flex-start", gap: "8px", alignItems: "flex-end" }}>
                  {!isMe && <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: active.agentColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "10px", fontWeight: 700, color: "#fff", fontFamily: FH, flexShrink: 0, marginBottom: "2px" }}>{active.agentInitials}</div>}
                  <div style={{ maxWidth: "70%" }}>
                    <div style={{ padding: "10px 14px", borderRadius: isMe ? "14px 14px 2px 14px" : "14px 14px 14px 2px", background: isMe ? C.navy : "#fff", border: isMe ? "none" : `1px solid ${C.border}`, boxShadow: "0 1px 3px rgba(15,23,42,0.05)" }}>
                      <p style={{ fontSize: "13px", color: isMe ? "#F1F5F9" : C.text, fontFamily: FB, lineHeight: 1.5 }}>{m.text}</p>
                    </div>
                    <p style={{ fontSize: "10px", color: C.dim, fontFamily: FB, marginTop: "3px", textAlign: isMe ? "right" : "left" }}>{fmtTime(m.timestamp)}</p>
                  </div>
                </div>
              );
            })}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div style={{ padding: "12px 16px", borderTop: `1px solid ${C.border}`, display: "flex", gap: "8px", flexShrink: 0, background: C.card }}>
            <input value={msg} onChange={e => setMsg(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} placeholder={`Message ${active.agentName}…`}
              style={{ flex: 1, padding: "10px 14px", border: `1px solid ${C.border}`, borderRadius: "9px", background: "#F8FAFC", color: C.text, fontSize: "13px", outline: "none", fontFamily: FB }}
              onFocus={e => (e.target.style.borderColor = C.green)} onBlur={e => (e.target.style.borderColor = C.border)} />
            <button onClick={send} disabled={!msg.trim()} style={{ padding: "10px 18px", background: msg.trim() ? C.green : C.border, border: "none", borderRadius: "9px", fontSize: "13px", fontWeight: 700, color: "#fff", cursor: msg.trim() ? "pointer" : "not-allowed", fontFamily: FH, transition: "background 0.12s" }}>
              Send
            </button>
          </div>
        </div>
      ) : (
        <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <p style={{ color: C.muted, fontFamily: FB }}>Select a conversation</p>
        </div>
      )}
    </div>
  );
}

// ── ACCOUNT ────────────────────────────────────────────────────────────────
function Account({ user, onLogout }: { user: ClientUser; onLogout: () => void }) {
  const { reservations } = useReservations();
  const { updateProfile } = useClientAuth() as { updateProfile: (u: Partial<ClientUser>) => void; login: unknown; signup: unknown; logout: unknown; user: unknown };
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState({ name: user.name, email: user.email, phone: user.phone ?? "", nationality: user.nationality ?? "" });

  const INP: React.CSSProperties = { width: "100%", padding: "10px 12px", border: `1px solid ${C.border}`, borderRadius: "8px", background: editing ? "#fff" : "#F8FAFC", color: C.text, fontSize: "14px", outline: "none", fontFamily: FB, boxSizing: "border-box" };

  return (
    <div style={{ maxWidth: "720px" }}>
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: "14px", overflow: "hidden", boxShadow: "0 1px 4px rgba(15,23,42,0.05)" }}>
        {/* Profile header */}
        <div style={{ padding: "24px 28px", background: "linear-gradient(135deg, #0F172A 0%, #1E293B 100%)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
            <div style={{ width: "52px", height: "52px", borderRadius: "50%", background: C.green, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px", fontWeight: 800, color: "#fff", fontFamily: FH, flexShrink: 0 }}>
              {user.avatar}
            </div>
            <div>
              <p style={{ fontSize: "18px", fontWeight: 800, color: "#F1F5F9", fontFamily: FH }}>{user.name}</p>
              <p style={{ fontSize: "13px", color: "rgba(241,245,249,0.55)", fontFamily: FB }}>{user.email}</p>
            </div>
          </div>
          <div style={{ display: "flex", gap: "8px" }}>
            <button onClick={() => { if (editing) { updateProfile(draft); } setEditing(v => !v); }} style={{ padding: "8px 16px", border: `1px solid ${editing ? C.green : "rgba(255,255,255,0.15)"}`, borderRadius: "8px", background: editing ? C.gBg : "rgba(255,255,255,0.07)", fontSize: "12px", fontWeight: 600, color: editing ? C.green : "rgba(255,255,255,0.7)", cursor: "pointer", fontFamily: FH }}>
              {editing ? "Save Changes" : "Edit Profile"}
            </button>
            <button onClick={onLogout} style={{ padding: "8px 16px", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", background: "rgba(255,255,255,0.06)", fontSize: "12px", color: "rgba(255,255,255,0.5)", cursor: "pointer", fontFamily: FB }}>Sign Out</button>
          </div>
        </div>

        {/* Fields */}
        <div style={{ padding: "24px 28px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
          {[["FULL NAME", "name", "Jane Smith", "text"], ["EMAIL ADDRESS", "email", "jane@example.com", "email"], ["PHONE", "phone", "+1 (305) 555-0000", "tel"], ["NATIONALITY", "nationality", "United States", "text"]].map(([lbl, key, ph, type]) => (
            <div key={key}>
              <label style={{ display: "block", fontSize: "11px", fontWeight: 700, color: C.muted, letterSpacing: "0.05em", marginBottom: "5px", fontFamily: FB }}>{lbl}</label>
              <input type={type} value={(draft as Record<string, string>)[key] ?? ""} onChange={e => setDraft(d => ({ ...d, [key]: e.target.value }))}
                disabled={!editing} placeholder={ph} style={{ ...INP, cursor: editing ? "text" : "default" }}
                onFocus={e => editing && (e.target.style.borderColor = C.green)} onBlur={e => (e.target.style.borderColor = C.border)} />
            </div>
          ))}

          <div style={{ gridColumn: "1 / -1" }}>
            <label style={{ display: "block", fontSize: "11px", fontWeight: 700, color: C.muted, letterSpacing: "0.05em", marginBottom: "5px", fontFamily: FB }}>GOVERNMENT ID</label>
            <div style={{ padding: "14px 16px", border: `1px dashed ${user.idUploaded ? C.green : C.border}`, borderRadius: "8px", background: user.idUploaded ? "#F0FDF4" : "#F8FAFC", display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ fontSize: "20px" }}>{user.idUploaded ? "✅" : "📎"}</span>
              <p style={{ fontSize: "13px", color: user.idUploaded ? C.green : C.muted, fontFamily: FB }}>{user.idUploaded ? "Government ID on file — Verified" : "No ID uploaded yet. Contact your agent to complete verification."}</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", borderTop: `1px solid ${C.border}` }}>
          {[["Total Reservations", String(reservations.length)], ["Confirmed", String(reservations.filter(r => r.status === "Confirmed").length)], ["Total Deposits", `$${reservations.reduce((s, r) => s + r.depositAmount, 0).toLocaleString()}`]].map(([k, v], i, arr) => (
            <div key={k} style={{ padding: "18px 24px", borderRight: i < arr.length - 1 ? `1px solid ${C.border}` : "none", textAlign: "center" }}>
              <p style={{ fontSize: "24px", fontWeight: 800, color: C.text, fontFamily: FH }}>{v}</p>
              <p style={{ fontSize: "11px", color: C.muted, fontFamily: FB, marginTop: "3px" }}>{k}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// We need useClientAuth in Account
import { useClientAuth } from "../../contexts/ClientAuthContext";

// ── MAIN APP ───────────────────────────────────────────────────────────────
export default function ClientApp({ user, onLogout }: Props) {
  const [view, setView] = useState<ClientView>("catalog");
  const [modalUnit, setModalUnit] = useState<Unit | null>(null);
  const [modalMode, setModalMode] = useState<"reserve" | "buy">("reserve");
  const { reservations } = useReservations();
  const { unreadCount } = useMessages();

  function openUnit(unit: Unit, mode: "reserve" | "buy") { setModalUnit(unit); setModalMode(mode); }
  function closeModal() { setModalUnit(null); }
  function onReserveSuccess() { setModalUnit(null); setView("reservations"); }

  const NAV: Array<{ id: ClientView; label: string; badge?: number }> = [
    { id: "catalog",      label: "Catalog" },
    { id: "reservations", label: "My Reservations", badge: reservations.length },
    { id: "messages",     label: "Messages",        badge: unreadCount },
    { id: "account",      label: "My Account" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: C.bg, fontFamily: FB }}>
      {/* Header */}
      <header style={{ position: "sticky", top: 0, zIndex: 100, background: "rgba(255,255,255,0.97)", backdropFilter: "blur(12px)", borderBottom: `1px solid ${C.border}`, boxShadow: "0 1px 3px rgba(15,23,42,0.06)" }}>
        <div style={{ maxWidth: "1280px", margin: "0 auto", padding: "0 32px", height: "62px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          {/* Brand */}
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ width: "34px", height: "34px", borderRadius: "8px", background: C.navy, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <span style={{ color: "#fff", fontWeight: 800, fontSize: "15px", fontFamily: FH }}>J</span>
            </div>
            <div>
              <span style={{ fontSize: "16px", fontWeight: 800, color: C.text, fontFamily: FH, letterSpacing: "-0.01em" }}>JACEstates</span>
              <span style={{ fontSize: "12px", color: C.muted, marginLeft: "8px", fontFamily: FB }}>Meridian Residences</span>
            </div>
          </div>

          {/* Nav */}
          <nav style={{ display: "flex", gap: "2px" }}>
            {NAV.map(n => (
              <button key={n.id} onClick={() => setView(n.id)} style={{ position: "relative", padding: "7px 16px", border: "none", background: view === n.id ? C.gBg : "none", borderRadius: "8px", fontSize: "13px", fontWeight: view === n.id ? 700 : 500, color: view === n.id ? C.green : C.muted, cursor: "pointer", fontFamily: FH, transition: "all 0.12s" }}>
                {n.label}
                {(n.badge ?? 0) > 0 && <span style={{ position: "absolute", top: "4px", right: "6px", width: "16px", height: "16px", borderRadius: "50%", background: n.id === "messages" ? C.red : C.navy, color: "#fff", fontSize: "9px", fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: FM }}>{n.badge}</span>}
              </button>
            ))}
          </nav>

          {/* User */}
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "7px", padding: "5px 10px 5px 5px", background: "#F1F5F9", borderRadius: "100px", border: `1px solid ${C.border}` }}>
              <div style={{ width: "26px", height: "26px", borderRadius: "50%", background: C.green, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "9px", fontWeight: 800, color: "#fff", fontFamily: FH }}>
                {user.avatar}
              </div>
              <span style={{ fontSize: "12px", fontWeight: 600, color: C.text2, fontFamily: FB }}>{user.name.split(" ")[0]}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main style={{ maxWidth: "1280px", margin: "0 auto", padding: "32px" }}>
        {/* Page header */}
        <div style={{ marginBottom: "24px" }}>
          <h1 style={{ fontSize: "24px", fontWeight: 800, color: C.text, fontFamily: FH, letterSpacing: "-0.02em", marginBottom: "4px" }}>
            {view === "catalog" ? "Property Catalog" : view === "reservations" ? "My Reservations" : view === "messages" ? "Messages" : "My Account"}
          </h1>
          <p style={{ fontSize: "13px", color: C.muted, fontFamily: FB }}>
            {view === "catalog" && "Browse all available units at Meridian Residences."}
            {view === "reservations" && "Track your reservations, deposits, and payment schedules."}
            {view === "messages" && "Communicate directly with your assigned agent."}
            {view === "account" && "Manage your profile and account settings."}
          </p>
        </div>

        {view === "catalog"      && <Catalog onOpenUnit={openUnit} />}
        {view === "reservations" && <MyReservations onOpenUnit={openUnit} />}
        {view === "messages"     && <Messages user={user} />}
        {view === "account"      && <Account user={user} onLogout={onLogout} />}
      </main>

      {/* Reservation Modal */}
      {modalUnit && (
        <ReservationModal unit={modalUnit} defaultMode={modalMode} user={user} onClose={closeModal} onSuccess={onReserveSuccess} />
      )}
    </div>
  );
}
