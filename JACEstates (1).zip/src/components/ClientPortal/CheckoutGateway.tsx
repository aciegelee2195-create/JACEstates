import { useState } from "react";
import { useBooking } from "../../contexts/BookingContext";
import { fmtPrice, type Unit } from "../../data/buildingData";

interface Props {
  unit: Unit;
  mode: "hold" | "buy";
  onBack: () => void;
  onComplete: () => void;
}

const STEPS = ["Reservation", "Identity Verification", "Digital Lease"];

function StepIndicator({ step, total }: { step: number; total: number }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "0" }}>
      {STEPS.map((label, i) => {
        const done = i < step;
        const active = i === step;
        return (
          <div key={label} style={{ display: "flex", alignItems: "center", flex: i < total - 1 ? 1 : "none" }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "6px" }}>
              <div style={{
                width: "32px", height: "32px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
                background: done ? "#0D7A52" : active ? "var(--cp-gold)" : "var(--cp-bg)",
                border: `2px solid ${done ? "#0D7A52" : active ? "var(--cp-gold)" : "var(--cp-border)"}`,
                fontSize: "13px", fontWeight: 700, color: (done || active) ? "#fff" : "var(--cp-text-dim)",
                fontFamily: "Plus Jakarta Sans, sans-serif", transition: "all 0.3s",
              }}>
                {done ? "✓" : i + 1}
              </div>
              <span style={{ fontSize: "11px", fontWeight: active ? 700 : 500, color: active ? "var(--cp-text)" : done ? "#0D7A52" : "var(--cp-text-dim)", whiteSpace: "nowrap" }}>{label}</span>
            </div>
            {i < total - 1 && (
              <div style={{ flex: 1, height: "2px", background: done ? "#0D7A52" : "var(--cp-border)", margin: "0 8px", marginBottom: "20px", transition: "background 0.3s" }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

const depositPct = 0.10;

export default function CheckoutGateway({ unit, mode, onBack, onComplete }: Props) {
  const { placeHold, checkout } = useBooking();
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [complete, setComplete] = useState(false);

  // Step 1 fields
  const depositAmount = mode === "hold" ? 5_000 : Math.round(unit.price * depositPct);
  const [payMethod, setPayMethod] = useState<"card" | "wire" | "crypto">("card");
  const [cardNum, setCardNum] = useState("");
  const [cardName, setCardName] = useState("");
  const [cardExp, setCardExp] = useState("");
  const [cardCvv, setCardCvv] = useState("");

  // Step 2 fields
  const [fullName, setFullName] = useState("");
  const [dob, setDob] = useState("");
  const [nationality, setNationality] = useState("");
  const [idType, setIdType] = useState("passport");
  const [idNumber, setIdNumber] = useState("");

  // Step 3 fields
  const [signature, setSignature] = useState("");
  const [agreed, setAgreed] = useState(false);

  const inp: React.CSSProperties = {
    width: "100%", padding: "10px 12px", border: "1px solid var(--cp-border)", borderRadius: "8px",
    background: "var(--cp-card)", color: "var(--cp-text)", fontSize: "14px", outline: "none",
    fontFamily: "Inter, sans-serif", boxSizing: "border-box",
  };

  function nextStep() {
    if (step < 2) { setStep(s => s + 1); return; }
    // Final submit
    setLoading(true);
    setTimeout(() => {
      if (mode === "hold") placeHold(unit.id, { name: fullName || "Guest", email: "client@example.com" });
      else checkout(unit.id, { name: fullName || "Guest", email: "client@example.com" }, depositAmount);
      setComplete(true);
      setLoading(false);
    }, 1200);
  }

  const canNext = () => {
    if (step === 0) return payMethod === "wire" || payMethod === "crypto" || (cardNum.length >= 16 && cardName && cardExp && cardCvv);
    if (step === 1) return fullName && dob && idNumber;
    return signature.length >= 3 && agreed;
  };

  if (complete) {
    return (
      <div style={{ maxWidth: "560px", margin: "0 auto", padding: "60px 0", textAlign: "center" }}>
        <div style={{ width: "72px", height: "72px", borderRadius: "50%", background: "var(--cp-emerald-dim)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", fontSize: "32px" }}>🎉</div>
        <h2 style={{ fontSize: "30px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "8px" }}>
          {mode === "hold" ? "Hold Secured!" : "Reservation Confirmed!"}
        </h2>
        <p style={{ fontSize: "14px", color: "var(--cp-text-muted)", lineHeight: 1.6, marginBottom: "24px" }}>
          {mode === "hold"
            ? `Unit ${unit.id} is now on hold for 48 hours. Your agent will contact you within 2 hours to discuss next steps.`
            : `Unit ${unit.id} has been reserved in your name. Your deposit of ${fmtPrice(depositAmount)} is held in escrow. Welcome to Meridian Residences.`}
        </p>
        <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px", marginBottom: "24px", textAlign: "left" }}>
          <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "12px" }}>
            {mode === "hold" ? "HOLD CONFIRMATION" : "RESERVATION RECEIPT"}
          </p>
          {[
            ["Unit", `${unit.id} · ${unit.type} · Floor ${unit.floor}`],
            ["Status", mode === "hold" ? "Hold — 48 hours" : "Reserved"],
            [mode === "hold" ? "Hold Fee" : "Deposit Paid", fmtPrice(depositAmount)],
            ["Reference", `JCE-${Date.now().toString().slice(-6)}`],
          ].map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid var(--cp-border)" }}>
              <span style={{ fontSize: "12px", color: "var(--cp-text-dim)" }}>{k}</span>
              <span style={{ fontSize: "13px", fontWeight: 600, color: "var(--cp-text)" }}>{v}</span>
            </div>
          ))}
        </div>
        <p style={{ fontSize: "13px", color: "var(--cp-text-muted)", marginBottom: "20px" }}>Your assigned agent will contact you within 2 business hours. All documents will be emailed to you shortly.</p>
        <button onClick={onComplete} style={{ padding: "12px 32px", background: "var(--cp-gold)", border: "none", borderRadius: "8px", fontSize: "14px", fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
          ← Return to Listings
        </button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: "960px", margin: "0 auto" }}>
      <button onClick={onBack} style={{ display: "flex", alignItems: "center", gap: "6px", background: "none", border: "none", cursor: "pointer", fontSize: "13px", color: "var(--cp-text-muted)", marginBottom: "24px", padding: 0 }}>
        ← Back
      </button>

      <div style={{ marginBottom: "32px" }}>
        <h2 style={{ fontSize: "28px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "4px" }}>
          {mode === "hold" ? "Secure a 48-Hour Hold" : "Reserve Your Residence"}
        </h2>
        <p style={{ fontSize: "14px", color: "var(--cp-text-muted)" }}>Unit {unit.id} · {unit.type} · Floor {unit.floor} · {fmtPrice(unit.price)}</p>
      </div>

      {/* Step indicator */}
      <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "24px 28px", marginBottom: "24px" }}>
        <StepIndicator step={step} total={3} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: "24px" }}>
        {/* Step content */}
        <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "28px" }}>

          {/* ── Step 0: Reservation + Payment ── */}
          {step === 0 && (
            <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
              <h3 style={{ fontSize: "18px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)" }}>Reservation & Payment</h3>

              {/* Deposit breakdown */}
              <div style={{ padding: "16px", background: "var(--cp-bg)", borderRadius: "10px", border: "1px solid var(--cp-border)" }}>
                <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "12px" }}>PAYMENT SUMMARY</p>
                {mode === "buy" ? (
                  <>
                    {[["Unit Price", fmtPrice(unit.price)], ["Required Deposit (10%)", fmtPrice(depositAmount)], ["Balance Due at Closing", fmtPrice(unit.price - depositAmount)]].map(([k, v], i) => (
                      <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: i < 2 ? "1px solid var(--cp-border)" : "none" }}>
                        <span style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>{k}</span>
                        <span style={{ fontSize: "13px", fontWeight: i > 0 ? 700 : 400, color: i === 1 ? "var(--cp-gold)" : "var(--cp-text)" }}>{v}</span>
                      </div>
                    ))}
                  </>
                ) : (
                  <>
                    {[["48-Hour Hold Fee (Refundable)", "$5,000"], ["If Purchase Proceeds", "Applied to deposit"]].map(([k, v]) => (
                      <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid var(--cp-border)" }}>
                        <span style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>{k}</span>
                        <span style={{ fontSize: "13px", fontWeight: 700, color: "var(--cp-gold)" }}>{v}</span>
                      </div>
                    ))}
                  </>
                )}
              </div>

              {/* Payment method */}
              <div>
                <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "10px" }}>PAYMENT METHOD</p>
                <div style={{ display: "flex", gap: "8px", marginBottom: "16px" }}>
                  {(["card", "wire", "crypto"] as const).map(m => (
                    <button key={m} type="button" onClick={() => setPayMethod(m)} style={{
                      flex: 1, padding: "10px 8px", borderRadius: "8px", cursor: "pointer", textAlign: "center",
                      border: `1px solid ${payMethod === m ? "var(--cp-gold)" : "var(--cp-border)"}`,
                      background: payMethod === m ? "var(--cp-gold-dim)" : "var(--cp-bg)",
                      fontSize: "12px", fontWeight: 600, color: payMethod === m ? "var(--cp-gold)" : "var(--cp-text-muted)", transition: "all 0.15s",
                    }}>
                      {m === "card" ? "💳 Credit Card" : m === "wire" ? "🏦 Wire Transfer" : "₿ Crypto"}
                    </button>
                  ))}
                </div>

                {payMethod === "card" && (
                  <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                    <div>
                      <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>CARD NUMBER</label>
                      <input value={cardNum} onChange={e => setCardNum(e.target.value.replace(/\D/g, "").slice(0, 16))} placeholder="1234 5678 9012 3456" style={inp}
                        onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")} onBlur={e => (e.target.style.borderColor = "var(--cp-border)")} />
                    </div>
                    <div>
                      <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>CARDHOLDER NAME</label>
                      <input value={cardName} onChange={e => setCardName(e.target.value)} placeholder="Jane Smith" style={inp}
                        onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")} onBlur={e => (e.target.style.borderColor = "var(--cp-border)")} />
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                      <div>
                        <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>EXPIRY</label>
                        <input value={cardExp} onChange={e => setCardExp(e.target.value)} placeholder="MM / YY" style={inp}
                          onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")} onBlur={e => (e.target.style.borderColor = "var(--cp-border)")} />
                      </div>
                      <div>
                        <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>CVV</label>
                        <input value={cardCvv} onChange={e => setCardCvv(e.target.value.slice(0, 4))} placeholder="•••" type="password" style={inp}
                          onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")} onBlur={e => (e.target.style.borderColor = "var(--cp-border)")} />
                      </div>
                    </div>
                  </div>
                )}
                {payMethod === "wire" && (
                  <div style={{ padding: "14px", background: "var(--cp-bg)", borderRadius: "8px", border: "1px solid var(--cp-border)" }}>
                    <p style={{ fontSize: "13px", color: "var(--cp-text-2)", marginBottom: "8px" }}>Wire transfer instructions will be emailed once you proceed to the next step.</p>
                    <p style={{ fontSize: "12px", color: "var(--cp-text-muted)" }}>Processing time: 1–3 business days. Your hold will be confirmed once funds clear.</p>
                  </div>
                )}
                {payMethod === "crypto" && (
                  <div style={{ padding: "14px", background: "var(--cp-bg)", borderRadius: "8px", border: "1px solid var(--cp-border)" }}>
                    <p style={{ fontSize: "13px", color: "var(--cp-text-2)", marginBottom: "8px" }}>BTC, ETH, and USDC accepted. Wallet address and QR code will be provided after proceeding.</p>
                    <p style={{ fontSize: "12px", color: "var(--cp-text-muted)" }}>Rate locked at time of transaction. Confirmation required within 30 minutes.</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── Step 1: Identity Verification ── */}
          {step === 1 && (
            <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
              <div>
                <h3 style={{ fontSize: "18px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "4px" }}>Identity Verification</h3>
                <p style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>Required by regulatory compliance. Verification is processed within 24–48 hours.</p>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                <div>
                  <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>FULL LEGAL NAME *</label>
                  <input value={fullName} onChange={e => setFullName(e.target.value)} required placeholder="As shown on government ID" style={inp}
                    onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")} onBlur={e => (e.target.style.borderColor = "var(--cp-border)")} />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>DATE OF BIRTH *</label>
                  <input type="date" value={dob} onChange={e => setDob(e.target.value)} required style={inp}
                    onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")} onBlur={e => (e.target.style.borderColor = "var(--cp-border)")} />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                <div>
                  <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>NATIONALITY</label>
                  <input value={nationality} onChange={e => setNationality(e.target.value)} placeholder="United States" style={inp}
                    onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")} onBlur={e => (e.target.style.borderColor = "var(--cp-border)")} />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>ID TYPE *</label>
                  <select value={idType} onChange={e => setIdType(e.target.value)} style={{ ...inp }}>
                    <option value="passport">Passport</option>
                    <option value="drivers_license">Driver's License</option>
                    <option value="national_id">National ID</option>
                  </select>
                </div>
              </div>

              <div>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>ID NUMBER *</label>
                <input value={idNumber} onChange={e => setIdNumber(e.target.value)} required placeholder="Document number" style={inp}
                  onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")} onBlur={e => (e.target.style.borderColor = "var(--cp-border)")} />
              </div>

              <div>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>UPLOAD DOCUMENT</label>
                <div style={{ padding: "24px", border: "2px dashed var(--cp-border)", borderRadius: "8px", textAlign: "center", background: "var(--cp-bg)", cursor: "pointer", transition: "border-color 0.15s" }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = "var(--cp-gold)")}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = "var(--cp-border)")}
                >
                  <div style={{ fontSize: "24px", marginBottom: "8px" }}>📎</div>
                  <p style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>Drag & drop or <span style={{ color: "var(--cp-gold)", fontWeight: 600 }}>browse</span> to upload</p>
                  <p style={{ fontSize: "11px", color: "var(--cp-text-dim)", marginTop: "4px" }}>PDF, JPG, or PNG · Max 10MB</p>
                </div>
              </div>

              <div style={{ padding: "12px 14px", background: "rgba(13,122,82,0.06)", borderRadius: "8px", border: "1px solid rgba(13,122,82,0.2)", display: "flex", gap: "10px" }}>
                <span style={{ color: "#0D7A52", fontSize: "16px", flexShrink: 0 }}>🔒</span>
                <p style={{ fontSize: "12px", color: "var(--cp-text-muted)", lineHeight: 1.5 }}>Your documents are encrypted with 256-bit AES and processed in compliance with GDPR and local real estate regulations. They are never shared without your explicit consent.</p>
              </div>
            </div>
          )}

          {/* ── Step 2: Digital Lease ── */}
          {step === 2 && (
            <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
              <div>
                <h3 style={{ fontSize: "18px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "4px" }}>Digital Lease Agreement</h3>
                <p style={{ fontSize: "13px", color: "var(--cp-text-muted)" }}>Review and execute your reservation agreement.</p>
              </div>

              {/* Lease summary */}
              <div style={{ padding: "16px", background: "var(--cp-bg)", borderRadius: "10px", border: "1px solid var(--cp-border)", maxHeight: "220px", overflowY: "auto" }}>
                <p style={{ fontSize: "12px", fontWeight: 700, color: "var(--cp-text)", marginBottom: "10px" }}>MERIDIAN RESIDENCES — RESERVATION AGREEMENT SUMMARY</p>
                {[
                  ["Buyer / Tenant", fullName || "[Your Name]"],
                  ["Property", `Unit ${unit.id}, ${unit.type}, Floor ${unit.floor}`],
                  ["Development", "301 Meridian Tower, Harbor District, Miami FL 33131"],
                  ["Purchase Price", fmtPrice(unit.price)],
                  [mode === "hold" ? "Hold Fee" : "Deposit Amount", fmtPrice(depositAmount)],
                  ["Deposit Type", mode === "hold" ? "Refundable hold fee — 48 hours" : "10% initial deposit held in escrow"],
                  ["Governing Law", "State of Florida Real Estate Laws"],
                  ["Agreement Date", new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })],
                ].map(([k, v]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: "1px solid var(--cp-border)" }}>
                    <span style={{ fontSize: "11px", color: "var(--cp-text-dim)" }}>{k}</span>
                    <span style={{ fontSize: "12px", fontWeight: 600, color: "var(--cp-text)" }}>{v}</span>
                  </div>
                ))}
                <p style={{ fontSize: "11px", color: "var(--cp-text-muted)", marginTop: "12px", lineHeight: 1.6 }}>
                  This agreement constitutes a binding reservation of the above-described unit. The deposit amount shall be held in escrow by JACEstates Development Group, a licensed Florida real estate broker. Upon execution of the full purchase agreement, this deposit shall be applied toward the purchase price. The Buyer acknowledges having received and reviewed all relevant disclosure documents, including the condominium declaration, community rules, and financial statements...
                </p>
              </div>

              {/* Key terms */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
                {[
                  ["Cancellation Policy", mode === "hold" ? "Full refund within 48 hours" : "Deposit refundable within 7 days"],
                  ["Transfer", "Non-transferable without written consent"],
                  ["Completion", "Estimated Q3 2027"],
                  ["Jurisdiction", "Miami-Dade County, FL"],
                ].map(([k, v]) => (
                  <div key={k} style={{ padding: "10px", background: "var(--cp-bg)", borderRadius: "8px", border: "1px solid var(--cp-border)" }}>
                    <p style={{ fontSize: "10px", fontWeight: 700, color: "var(--cp-text-dim)", marginBottom: "3px" }}>{k.toUpperCase()}</p>
                    <p style={{ fontSize: "12px", color: "var(--cp-text-2)" }}>{v}</p>
                  </div>
                ))}
              </div>

              {/* Signature */}
              <div>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--cp-text-muted)", marginBottom: "5px" }}>YOUR DIGITAL SIGNATURE *</label>
                <input
                  value={signature}
                  onChange={e => setSignature(e.target.value)}
                  placeholder="Type your full legal name to sign"
                  style={{ ...inp, fontSize: "18px", fontFamily: "Instrument Serif, serif", fontStyle: "italic", borderBottom: `2px solid ${signature ? "var(--cp-gold)" : "var(--cp-border)"}`, borderRadius: "8px 8px 0 0", borderLeft: "1px solid var(--cp-border)", borderRight: "1px solid var(--cp-border)", borderTop: "1px solid var(--cp-border)" }}
                  onFocus={e => (e.target.style.borderBottomColor = "var(--cp-gold)")}
                  onBlur={e => (e.target.style.borderBottomColor = signature ? "var(--cp-gold)" : "var(--cp-border)")}
                />
                {signature && <p style={{ fontSize: "11px", color: "#0D7A52", marginTop: "4px" }}>✓ Signature captured: {new Date().toLocaleString()}</p>}
              </div>

              {/* Agree checkbox */}
              <label style={{ display: "flex", gap: "10px", cursor: "pointer", alignItems: "flex-start" }}>
                <input type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)} style={{ marginTop: "2px", width: "16px", height: "16px", cursor: "pointer", accentColor: "var(--cp-gold)", flexShrink: 0 }} />
                <span style={{ fontSize: "13px", color: "var(--cp-text-muted)", lineHeight: 1.5 }}>
                  I confirm that I have read, understood, and agree to the full terms of the Reservation Agreement, and I acknowledge that my digital signature above constitutes a legally binding electronic signature under ESIGN Act regulations.
                </span>
              </label>
            </div>
          )}

          {/* Navigation */}
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: "24px", paddingTop: "20px", borderTop: "1px solid var(--cp-border)" }}>
            {step > 0 ? (
              <button onClick={() => setStep(s => s - 1)} style={{ padding: "10px 20px", border: "1px solid var(--cp-border)", borderRadius: "8px", background: "none", fontSize: "13px", color: "var(--cp-text-2)", cursor: "pointer" }}>← Back</button>
            ) : (
              <button onClick={onBack} style={{ padding: "10px 20px", border: "1px solid var(--cp-border)", borderRadius: "8px", background: "none", fontSize: "13px", color: "var(--cp-text-2)", cursor: "pointer" }}>Cancel</button>
            )}
            <button
              onClick={nextStep}
              disabled={!canNext() || loading}
              style={{
                padding: "10px 28px", background: canNext() ? "var(--cp-gold)" : "var(--cp-border)", border: "none",
                borderRadius: "8px", fontSize: "14px", fontWeight: 700, color: canNext() ? "#fff" : "var(--cp-text-dim)",
                cursor: canNext() ? "pointer" : "not-allowed", fontFamily: "Plus Jakarta Sans, sans-serif", transition: "all 0.15s",
              }}
            >
              {loading ? "Processing…" : step < 2 ? "Continue →" : mode === "hold" ? "Secure Hold →" : "Execute Agreement →"}
            </button>
          </div>
        </div>

        {/* Summary sidebar */}
        <div style={{ position: "sticky", top: "88px" }}>
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", overflow: "hidden", boxShadow: "var(--cp-shadow-md)" }}>
            <div style={{ height: "130px", background: "#E8E4DC", overflow: "hidden" }}>
              <img src={`https://images.unsplash.com/${unit.img}?w=380&h=200&fit=crop&auto=format`} alt={unit.id} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            </div>
            <div style={{ padding: "18px" }}>
              <p style={{ fontSize: "10px", fontFamily: "JetBrains Mono, monospace", color: "var(--cp-text-dim)", marginBottom: "2px" }}>{unit.id}</p>
              <p style={{ fontSize: "17px", fontWeight: 400, fontFamily: "Instrument Serif, serif", color: "var(--cp-text)", marginBottom: "10px" }}>{unit.type} · Floor {unit.floor}</p>
              <div style={{ borderTop: "1px solid var(--cp-border)", paddingTop: "12px", display: "flex", flexDirection: "column", gap: "7px" }}>
                {[
                  ["Asking Price", fmtPrice(unit.price)],
                  mode === "hold" ? ["Hold Fee", "$5,000"] : ["Deposit (10%)", fmtPrice(depositAmount)],
                  ["Interior", `${unit.sqft.toLocaleString()} sqft`],
                  ["View", unit.view],
                ].map(([k, v]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ fontSize: "12px", color: "var(--cp-text-dim)" }}>{k}</span>
                    <span style={{ fontSize: "12px", fontWeight: 600, color: "var(--cp-text)", textAlign: "right", maxWidth: "140px" }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Security badges */}
          <div style={{ marginTop: "12px", padding: "14px", background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "10px" }}>
            <p style={{ fontSize: "10px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "10px" }}>SECURE CHECKOUT</p>
            {["🔒 256-bit SSL Encryption", "🏛️ Florida RE Compliant", "✅ ESIGN Act Verified", "🏦 Deposit held in escrow"].map(b => (
              <p key={b} style={{ fontSize: "12px", color: "var(--cp-text-muted)", marginBottom: "4px" }}>{b}</p>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
