import { useState } from "react";
import { useBooking } from "../../contexts/BookingContext";
import { getFloorLabel, fmtPrice, type Unit } from "../../data/buildingData";

type ActionMode = "tour" | "hold" | "buy";

interface Props { onAction: (unit: Unit, mode: ActionMode) => void; }

const ORIENTATIONS = ["All", "NE", "NW", "SE", "SW"];
const UNIT_TYPES = ["All", "Studio", "1BR", "2BR", "3BR", "Penthouse"];
const STATUS_OPTS = ["All", "Available", "Held", "Reserved", "Sold"];

const STATUS_META = {
  Available: { color: "#0D7A52", bg: "rgba(13,122,82,0.1)", label: "Available" },
  Held: { color: "#B45309", bg: "rgba(180,83,9,0.1)", label: "On Hold" },
  Reserved: { color: "#6D28D9", bg: "rgba(109,40,217,0.1)", label: "Reserved" },
  Sold: { color: "#64748B", bg: "rgba(100,116,139,0.1)", label: "Sold" },
};

function OrientationCompass({ dir }: { dir: string }) {
  const angles: Record<string, number> = { N: 0, NE: 45, E: 90, SE: 135, S: 180, SW: 225, W: 270, NW: 315 };
  const deg = angles[dir] ?? 0;
  return (
    <svg width="28" height="28" viewBox="0 0 28 28">
      <circle cx="14" cy="14" r="13" fill="var(--cp-bg)" stroke="var(--cp-border)" strokeWidth="1" />
      <g transform={`rotate(${deg} 14 14)`}>
        <polygon points="14,4 12,14 14,12 16,14" fill="var(--cp-gold)" />
        <polygon points="14,24 12,14 14,16 16,14" fill="var(--cp-text-dim)" />
      </g>
      <text x="14" y="16" textAnchor="middle" fontSize="7" fill="var(--cp-text-muted)" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="700">{dir}</text>
    </svg>
  );
}

export default function UnitSearch({ onAction }: Props) {
  const { units } = useBooking();
  const [typeFilter, setTypeFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [orientFilter, setOrientFilter] = useState("All");
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(15_000_000);
  const [minFloor, setMinFloor] = useState(2);
  const [maxFloor, setMaxFloor] = useState(24);
  const [query, setQuery] = useState("");

  const filtered = units.filter(u =>
    (typeFilter === "All" || u.type === typeFilter) &&
    (statusFilter === "All" || u.status === statusFilter) &&
    (orientFilter === "All" || u.orientation === orientFilter) &&
    u.price >= minPrice && u.price <= maxPrice &&
    u.floor >= minFloor && u.floor <= maxFloor &&
    (query === "" || u.id.toLowerCase().includes(query.toLowerCase()) || u.type.toLowerCase().includes(query.toLowerCase()) || u.view.toLowerCase().includes(query.toLowerCase()))
  );

  const fBtn = (active: boolean): React.CSSProperties => ({
    padding: "5px 12px", border: `1px solid ${active ? "var(--cp-gold)" : "var(--cp-border)"}`,
    borderRadius: "100px", background: active ? "var(--cp-gold-dim)" : "var(--cp-card)",
    color: active ? "var(--cp-gold)" : "var(--cp-text-muted)",
    fontSize: "12.5px", cursor: "pointer", fontWeight: active ? 600 : 400, transition: "all 0.15s",
  });

  return (
    <div style={{ display: "flex", gap: "24px" }}>
      {/* Filter sidebar */}
      <div style={{ width: "220px", flexShrink: 0 }}>
        <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px", position: "sticky", top: "88px" }}>
          <h3 style={{ fontSize: "13px", fontWeight: 700, color: "var(--cp-text)", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "16px", letterSpacing: "0.03em" }}>REFINE SEARCH</h3>

          {/* Search */}
          <div style={{ marginBottom: "18px" }}>
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Unit ID, type, view…"
              style={{ width: "100%", padding: "8px 10px", border: "1px solid var(--cp-border)", borderRadius: "8px", background: "var(--cp-bg)", color: "var(--cp-text)", fontSize: "13px", outline: "none", boxSizing: "border-box" }}
              onFocus={e => (e.target.style.borderColor = "var(--cp-gold)")}
              onBlur={e => (e.target.style.borderColor = "var(--cp-border)")}
            />
          </div>

          {[
            { label: "Unit Type", opts: UNIT_TYPES, val: typeFilter, set: setTypeFilter },
            { label: "Availability", opts: STATUS_OPTS, val: statusFilter, set: setStatusFilter },
            { label: "Orientation", opts: ORIENTATIONS, val: orientFilter, set: setOrientFilter },
          ].map(({ label, opts, val, set }) => (
            <div key={label} style={{ marginBottom: "18px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "8px" }}>{label.toUpperCase()}</p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "5px" }}>
                {opts.map(o => (
                  <button key={o} onClick={() => set(o)} style={fBtn(val === o)}>{o}</button>
                ))}
              </div>
            </div>
          ))}

          <div style={{ marginBottom: "18px" }}>
            <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "8px" }}>FLOOR RANGE</p>
            <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
              <input type="number" value={minFloor} onChange={e => setMinFloor(Number(e.target.value))} min={2} max={24} style={{ width: "56px", padding: "6px 8px", border: "1px solid var(--cp-border)", borderRadius: "6px", background: "var(--cp-bg)", color: "var(--cp-text)", fontSize: "13px", outline: "none" }} />
              <span style={{ color: "var(--cp-text-dim)" }}>–</span>
              <input type="number" value={maxFloor} onChange={e => setMaxFloor(Number(e.target.value))} min={2} max={24} style={{ width: "56px", padding: "6px 8px", border: "1px solid var(--cp-border)", borderRadius: "6px", background: "var(--cp-bg)", color: "var(--cp-text)", fontSize: "13px", outline: "none" }} />
            </div>
          </div>

          <div>
            <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "8px" }}>PRICE RANGE</p>
            <div style={{ display: "flex", gap: "8px", flexDirection: "column" }}>
              {[["Min", minPrice, setMinPrice], ["Max", maxPrice, setMaxPrice]].map(([label, val, set]) => (
                <select key={label as string} value={val as number} onChange={e => (set as Function)(Number(e.target.value))}
                  style={{ padding: "6px 8px", border: "1px solid var(--cp-border)", borderRadius: "6px", background: "var(--cp-bg)", color: "var(--cp-text)", fontSize: "12px", outline: "none" }}>
                  {[500_000, 1_000_000, 2_000_000, 3_000_000, 5_000_000, 8_000_000, 15_000_000].map(v => (
                    <option key={v} value={v}>{v >= 1_000_000 ? `$${v / 1_000_000}M` : `$${v / 1_000}K`}</option>
                  ))}
                </select>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div style={{ flex: 1 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
          <p style={{ fontSize: "14px", color: "var(--cp-text-muted)" }}>
            <strong style={{ color: "var(--cp-text)" }}>{filtered.length}</strong> units matching your criteria
          </p>
          <div style={{ display: "flex", gap: "8px" }}>
            {[["Available", units.filter(u => u.status === "Available").length, "#0D7A52"], ["Held", units.filter(u => u.status === "Held").length, "#B45309"], ["Sold", units.filter(u => u.status === "Sold").length, "#94A3B8"]].map(([l, v, c]) => (
              <span key={l as string} style={{ fontSize: "12px", padding: "3px 10px", borderRadius: "100px", background: `${c}12`, color: c as string, fontWeight: 600, border: `1px solid ${c}25` }}>{l}: {v as number}</span>
            ))}
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "16px" }}>
          {filtered.slice(0, 24).map(unit => {
            const meta = STATUS_META[unit.status];
            const isSold = unit.status === "Sold" || unit.status === "Reserved";
            return (
              <div key={unit.id} style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", overflow: "hidden", transition: "all 0.2s", boxShadow: "var(--cp-shadow)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = "var(--cp-shadow-md)"; (e.currentTarget as HTMLElement).style.borderColor = "var(--cp-border-strong)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "var(--cp-shadow)"; (e.currentTarget as HTMLElement).style.borderColor = "var(--cp-border)"; }}
              >
                {/* Image */}
                <div style={{ height: "160px", position: "relative", background: "#E8E4DC", overflow: "hidden" }}>
                  <img src={`https://images.unsplash.com/${unit.img}?w=500&h=280&fit=crop&auto=format`} alt={`Unit ${unit.id} interior`} style={{ width: "100%", height: "100%", objectFit: "cover", filter: isSold ? "grayscale(60%)" : "none" }} />
                  <div style={{ position: "absolute", top: "10px", left: "10px" }}>
                    <span style={{ padding: "3px 8px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, background: meta.bg, color: meta.color, backdropFilter: "blur(8px)", border: `1px solid ${meta.color}30` }}>{meta.label}</span>
                  </div>
                  <div style={{ position: "absolute", top: "10px", right: "10px" }}>
                    <span style={{ padding: "3px 8px", borderRadius: "5px", fontSize: "11px", background: "rgba(26,23,20,0.65)", color: "#FAF8F5", fontFamily: "JetBrains Mono, monospace" }}>{unit.id}</span>
                  </div>
                  <div style={{ position: "absolute", bottom: "10px", right: "10px" }}>
                    <OrientationCompass dir={unit.orientation} />
                  </div>
                </div>

                {/* Info */}
                <div style={{ padding: "16px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "6px" }}>
                    <div>
                      <div style={{ fontSize: "16px", fontWeight: 400, color: "var(--cp-text)", fontFamily: "Instrument Serif, serif" }}>{unit.type}</div>
                      <div style={{ fontSize: "12px", color: "var(--cp-text-muted)", marginTop: "2px" }}>Floor {unit.floor} · {getFloorLabel(unit.floor)}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: "16px", fontWeight: 700, color: isSold ? "var(--cp-text-dim)" : "var(--cp-text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{fmtPrice(unit.price)}</div>
                      <div style={{ fontSize: "11px", color: "var(--cp-text-dim)", marginTop: "1px" }}>${unit.monthlyRent.toLocaleString()}/mo</div>
                    </div>
                  </div>
                  <div style={{ fontSize: "12px", color: "var(--cp-text-muted)", marginBottom: "12px", lineHeight: 1.4 }}>{unit.view}</div>
                  <div style={{ display: "flex", gap: "6px", marginBottom: "14px", flexWrap: "wrap" }}>
                    <span style={{ padding: "2px 8px", borderRadius: "4px", background: "var(--cp-gold-dim)", color: "var(--cp-gold)", fontSize: "11px", fontWeight: 600 }}>{unit.sqft.toLocaleString()} sqft</span>
                    <span style={{ padding: "2px 8px", borderRadius: "4px", background: "var(--cp-bg)", color: "var(--cp-text-muted)", fontSize: "11px", border: "1px solid var(--cp-border)" }}>{unit.orientation} facing</span>
                  </div>

                  {/* CTAs */}
                  {unit.status === "Available" && (
                    <div style={{ display: "flex", gap: "8px" }}>
                      <button onClick={() => onAction(unit, "tour")} style={{ flex: 1, padding: "8px", border: "1px solid var(--cp-border-strong)", borderRadius: "8px", background: "none", fontSize: "12.5px", color: "var(--cp-text-2)", cursor: "pointer", fontWeight: 500 }}>Schedule Tour</button>
                      <button onClick={() => onAction(unit, "hold")} style={{ flex: 1, padding: "8px", border: "none", borderRadius: "8px", background: "var(--cp-gold)", fontSize: "12.5px", color: "#fff", cursor: "pointer", fontWeight: 600, fontFamily: "Plus Jakarta Sans, sans-serif" }}>Place 48hr Hold</button>
                    </div>
                  )}
                  {unit.status === "Held" && (
                    <div style={{ padding: "8px 12px", background: "var(--cp-amber-dim)", borderRadius: "8px", border: "1px solid rgba(180,83,9,0.2)", fontSize: "12px", color: "var(--cp-amber)" }}>
                      ⏱ On hold by {unit.holdClient} · {unit.holdExpiry}
                    </div>
                  )}
                  {isSold && (
                    <div style={{ padding: "8px 12px", background: "var(--cp-bg)", borderRadius: "8px", fontSize: "12px", color: "var(--cp-text-dim)", textAlign: "center" }}>
                      {unit.status === "Reserved" ? "Currently Reserved" : "Sold"}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        {filtered.length === 0 && (
          <div style={{ padding: "60px", textAlign: "center", color: "var(--cp-text-muted)" }}>
            <div style={{ fontSize: "32px", marginBottom: "12px" }}>🔍</div>
            <p style={{ fontSize: "15px", fontWeight: 600, color: "var(--cp-text)", fontFamily: "Instrument Serif, serif" }}>No units match your filters</p>
            <p style={{ fontSize: "13px", marginTop: "6px" }}>Try adjusting your search criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}
