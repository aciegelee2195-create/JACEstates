import { useState } from "react";
import { useBooking } from "../../contexts/BookingContext";
import { getFloorLabel, fmtPrice, type Unit } from "../../data/buildingData";

type ActionMode = "tour" | "hold" | "buy";
interface Props { onAction: (unit: Unit, mode: ActionMode) => void; }

const STATUS_COLOR = {
  Available: "#0D7A52",
  Held: "#B45309",
  Reserved: "#6D28D9",
  Sold: "#94A3B8",
};

const STATUS_LABEL = {
  Available: "Available",
  Held: "On Hold",
  Reserved: "Reserved",
  Sold: "Sold",
};

const ORIENT_ANGLES: Record<string, number> = { N: 0, NE: 45, E: 90, SE: 135, S: 180, SW: 225, W: 270, NW: 315 };

function MiniCompass({ dir, size = 44 }: { dir: string; size?: number }) {
  const deg = ORIENT_ANGLES[dir] ?? 0;
  const cx = size / 2, cy = size / 2, r = size / 2 - 2;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={cx} cy={cy} r={r} fill="var(--cp-bg)" stroke="var(--cp-border)" strokeWidth="1" />
      {/* Cardinal ticks */}
      {[0, 90, 180, 270].map(a => {
        const rad = (a - 90) * Math.PI / 180;
        const x1 = cx + (r - 4) * Math.cos(rad);
        const y1 = cy + (r - 4) * Math.sin(rad);
        const x2 = cx + r * Math.cos(rad);
        const y2 = cy + r * Math.sin(rad);
        return <line key={a} x1={x1} y1={y1} x2={x2} y2={y2} stroke="var(--cp-text-dim)" strokeWidth="1" />;
      })}
      {/* Needle */}
      <g transform={`rotate(${deg} ${cx} ${cy})`}>
        <polygon points={`${cx},${cy - r + 5} ${cx - 4},${cy + 2} ${cx},${cy - 2} ${cx + 4},${cy + 2}`} fill="var(--cp-gold)" />
        <polygon points={`${cx},${cy + r - 5} ${cx - 4},${cy - 2} ${cx},${cy + 2} ${cx + 4},${cy - 2}`} fill="var(--cp-text-dim)" />
      </g>
      <text x={cx} y={cy + r - 5} textAnchor="middle" fontSize="7" fill="var(--cp-gold)" fontWeight="700" fontFamily="Plus Jakarta Sans, sans-serif">{dir}</text>
    </svg>
  );
}

function FloorBar({ floor, units, selected, onSelect }: {
  floor: number;
  units: Unit[];
  selected: boolean;
  onSelect: () => void;
}) {
  const label = getFloorLabel(floor);
  const isPH = floor >= 23;
  const availCount = units.filter(u => u.status === "Available").length;

  return (
    <div
      onClick={onSelect}
      style={{
        display: "flex", alignItems: "center", gap: "8px",
        padding: "4px 10px", cursor: "pointer", borderRadius: "6px",
        background: selected ? "var(--cp-gold-dim)" : "transparent",
        border: `1px solid ${selected ? "var(--cp-gold)" : "transparent"}`,
        transition: "all 0.15s",
      }}
      onMouseEnter={e => { if (!selected) (e.currentTarget as HTMLElement).style.background = "var(--cp-bg)"; }}
      onMouseLeave={e => { if (!selected) (e.currentTarget as HTMLElement).style.background = "transparent"; }}
    >
      {/* Floor number */}
      <div style={{ width: "32px", textAlign: "right", flexShrink: 0 }}>
        <span style={{ fontSize: isPH ? "11px" : "10px", fontWeight: selected ? 700 : 500, color: selected ? "var(--cp-gold)" : "var(--cp-text-muted)", fontFamily: "JetBrains Mono, monospace" }}>
          {isPH ? `PH` : `${floor}`}
        </span>
      </div>

      {/* Unit status bars */}
      <div style={{ display: "flex", gap: "2px", flex: 1 }}>
        {units.map(unit => (
          <div key={unit.id} title={`${unit.id} · ${unit.type} · ${fmtPrice(unit.price)}`} style={{
            flex: 1, height: isPH ? "14px" : "10px", borderRadius: "2px",
            background: STATUS_COLOR[unit.status],
            opacity: unit.status === "Sold" ? 0.45 : 0.85,
            transition: "opacity 0.15s",
          }} />
        ))}
      </div>

      {/* Available count */}
      <div style={{ width: "20px", textAlign: "right", flexShrink: 0 }}>
        {availCount > 0 && (
          <span style={{ fontSize: "9px", fontWeight: 700, color: "#0D7A52", fontFamily: "JetBrains Mono, monospace" }}>{availCount}</span>
        )}
      </div>
    </div>
  );
}

function UnitCard({ unit, onAction }: { unit: Unit; onAction: (u: Unit, m: ActionMode) => void }) {
  const isAvail = unit.status === "Available";
  const sc = STATUS_COLOR[unit.status];

  return (
    <div style={{
      background: "var(--cp-card)", border: `1px solid ${isAvail ? "var(--cp-border)" : "var(--cp-border)"}`,
      borderRadius: "12px", overflow: "hidden", transition: "all 0.2s", boxShadow: "var(--cp-shadow)",
    }}
      onMouseEnter={e => { if (isAvail) { (e.currentTarget as HTMLElement).style.borderColor = "var(--cp-gold)"; (e.currentTarget as HTMLElement).style.boxShadow = "var(--cp-shadow-md)"; } }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "var(--cp-border)"; (e.currentTarget as HTMLElement).style.boxShadow = "var(--cp-shadow)"; }}
    >
      {/* Top status strip */}
      <div style={{ height: "4px", background: sc, opacity: unit.status === "Sold" ? 0.4 : 1 }} />

      <div style={{ padding: "16px" }}>
        {/* Header row */}
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "12px" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
              <span style={{ fontSize: "13px", fontFamily: "JetBrains Mono, monospace", color: "var(--cp-text-muted)", fontWeight: 600 }}>{unit.id}</span>
              <span style={{ padding: "2px 7px", borderRadius: "100px", fontSize: "10px", fontWeight: 700, background: `${sc}15`, color: sc, border: `1px solid ${sc}30` }}>{STATUS_LABEL[unit.status]}</span>
            </div>
            <div style={{ fontSize: "18px", fontWeight: 400, color: "var(--cp-text)", fontFamily: "Instrument Serif, serif" }}>{unit.type}</div>
          </div>
          <MiniCompass dir={unit.orientation} />
        </div>

        {/* Stats grid */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", marginBottom: "12px" }}>
          {[
            ["Price", fmtPrice(unit.price)],
            ["Monthly Rent", `$${unit.monthlyRent.toLocaleString()}`],
            ["Interior", `${unit.sqft.toLocaleString()} sqft`],
            ["Orientation", unit.orientation + " facing"],
          ].map(([l, v]) => (
            <div key={l} style={{ padding: "8px 10px", background: "var(--cp-bg)", borderRadius: "8px" }}>
              <div style={{ fontSize: "10px", color: "var(--cp-text-dim)", fontWeight: 600, letterSpacing: "0.05em", marginBottom: "2px" }}>{l.toUpperCase()}</div>
              <div style={{ fontSize: "13px", fontWeight: 600, color: "var(--cp-text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{v}</div>
            </div>
          ))}
        </div>

        {/* View */}
        <p style={{ fontSize: "12px", color: "var(--cp-text-muted)", marginBottom: "10px", lineHeight: 1.5 }}>📍 {unit.view}</p>

        {/* Features */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: "4px", marginBottom: "14px" }}>
          {unit.features.slice(0, 3).map(f => (
            <span key={f} style={{ padding: "2px 8px", borderRadius: "4px", fontSize: "11px", background: "var(--cp-bg)", color: "var(--cp-text-muted)", border: "1px solid var(--cp-border)" }}>✓ {f}</span>
          ))}
          {unit.features.length > 3 && (
            <span style={{ padding: "2px 8px", borderRadius: "4px", fontSize: "11px", color: "var(--cp-text-dim)" }}>+{unit.features.length - 3} more</span>
          )}
        </div>

        {/* CTAs */}
        {unit.status === "Available" && (
          <div style={{ display: "flex", gap: "8px" }}>
            <button onClick={() => onAction(unit, "tour")} style={{ flex: 1, padding: "9px", border: "1px solid var(--cp-border-strong)", borderRadius: "8px", background: "none", fontSize: "12.5px", color: "var(--cp-text-2)", cursor: "pointer", fontWeight: 500, transition: "all 0.15s" }}
              onMouseEnter={e => (e.currentTarget.style.background = "var(--cp-bg)")}
              onMouseLeave={e => (e.currentTarget.style.background = "none")}
            >Schedule Tour</button>
            <button onClick={() => onAction(unit, "hold")} style={{ flex: 1, padding: "9px", border: "none", borderRadius: "8px", background: "var(--cp-gold)", fontSize: "12.5px", color: "#fff", cursor: "pointer", fontWeight: 600, fontFamily: "Plus Jakarta Sans, sans-serif", transition: "background 0.15s" }}
              onMouseEnter={e => (e.currentTarget.style.background = "#A37222")}
              onMouseLeave={e => (e.currentTarget.style.background = "var(--cp-gold)")}
            >Place 48hr Hold</button>
          </div>
        )}
        {unit.status === "Held" && (
          <div style={{ padding: "9px 12px", background: "rgba(180,83,9,0.08)", borderRadius: "8px", border: "1px solid rgba(180,83,9,0.2)", textAlign: "center" }}>
            <p style={{ fontSize: "12px", color: "var(--cp-amber)", fontWeight: 600 }}>⏱ On hold — {unit.holdExpiry}</p>
          </div>
        )}
        {(unit.status === "Sold" || unit.status === "Reserved") && (
          <div style={{ padding: "9px 12px", background: "var(--cp-bg)", borderRadius: "8px", textAlign: "center" }}>
            <p style={{ fontSize: "12px", color: "var(--cp-text-dim)" }}>{unit.status === "Reserved" ? "This unit is reserved" : "This unit has been sold"}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function FloorStacking({ onAction }: Props) {
  const { units } = useBooking();
  const [selectedFloor, setSelectedFloor] = useState(14);
  const [hoveredUnit, setHoveredUnit] = useState<string | null>(null);

  const floors = Array.from({ length: 23 }, (_, i) => 24 - i); // 24 down to 2

  function getFloorUnits(floor: number) {
    return units.filter(u => u.floor === floor);
  }

  const floorUnits = getFloorUnits(selectedFloor);
  const label = getFloorLabel(selectedFloor);
  const isPH = selectedFloor >= 23;

  const totalAvail = units.filter(u => u.status === "Available").length;
  const totalHeld = units.filter(u => u.status === "Held").length;
  const totalSold = units.filter(u => u.status === "Sold").length;

  return (
    <div>
      {/* Title */}
      <div style={{ marginBottom: "24px" }}>
        <h2 style={{ fontSize: "26px", fontWeight: 400, color: "var(--cp-text)", fontFamily: "Instrument Serif, serif", letterSpacing: "-0.01em" }}>
          Interactive Floor Stacking
        </h2>
        <p style={{ fontSize: "14px", color: "var(--cp-text-muted)", marginTop: "4px" }}>
          Select a floor level to explore unit orientation, live availability, and pricing.
        </p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: "24px", alignItems: "start" }}>

        {/* ── Building Elevation ── */}
        <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "14px", overflow: "hidden", boxShadow: "var(--cp-shadow)", position: "sticky", top: "88px" }}>
          {/* Building header */}
          <div style={{ padding: "16px 16px 10px", borderBottom: "1px solid var(--cp-border)", background: "#1A1714" }}>
            <p style={{ fontSize: "11px", fontWeight: 700, color: "rgba(250,248,245,0.4)", letterSpacing: "0.08em", marginBottom: "4px" }}>MERIDIAN RESIDENCES</p>
            <p style={{ fontSize: "13px", color: "rgba(250,248,245,0.75)" }}>24 Floors · {totalAvail} Available</p>
            {/* Legend */}
            <div style={{ display: "flex", gap: "10px", marginTop: "10px", flexWrap: "wrap" }}>
              {Object.entries(STATUS_COLOR).map(([k, c]) => (
                <div key={k} style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <div style={{ width: "8px", height: "8px", borderRadius: "2px", background: c, opacity: k === "Sold" ? 0.45 : 1 }} />
                  <span style={{ fontSize: "10px", color: "rgba(250,248,245,0.5)" }}>{STATUS_LABEL[k as keyof typeof STATUS_LABEL]}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Floor list */}
          <div style={{ padding: "8px 6px", maxHeight: "520px", overflowY: "auto" }}>
            {/* Penthouse zone */}
            <div style={{ padding: "4px 10px 2px", marginBottom: "2px" }}>
              <span style={{ fontSize: "9px", fontWeight: 700, color: "var(--cp-gold)", letterSpacing: "0.08em" }}>PENTHOUSE</span>
            </div>
            {floors.filter(f => f >= 23).map(floor => (
              <FloorBar key={floor} floor={floor} units={getFloorUnits(floor)} selected={selectedFloor === floor} onSelect={() => setSelectedFloor(floor)} />
            ))}
            <div style={{ height: "1px", background: "var(--cp-border)", margin: "6px 10px" }} />

            <div style={{ padding: "4px 10px 2px" }}>
              <span style={{ fontSize: "9px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.08em" }}>SIGNATURE (17–22)</span>
            </div>
            {floors.filter(f => f >= 17 && f <= 22).map(floor => (
              <FloorBar key={floor} floor={floor} units={getFloorUnits(floor)} selected={selectedFloor === floor} onSelect={() => setSelectedFloor(floor)} />
            ))}
            <div style={{ height: "1px", background: "var(--cp-border)", margin: "6px 10px" }} />

            <div style={{ padding: "4px 10px 2px" }}>
              <span style={{ fontSize: "9px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.08em" }}>PREMIER (10–16)</span>
            </div>
            {floors.filter(f => f >= 10 && f <= 16).map(floor => (
              <FloorBar key={floor} floor={floor} units={getFloorUnits(floor)} selected={selectedFloor === floor} onSelect={() => setSelectedFloor(floor)} />
            ))}
            <div style={{ height: "1px", background: "var(--cp-border)", margin: "6px 10px" }} />

            <div style={{ padding: "4px 10px 2px" }}>
              <span style={{ fontSize: "9px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.08em" }}>HORIZON (2–9)</span>
            </div>
            {floors.filter(f => f >= 2 && f <= 9).map(floor => (
              <FloorBar key={floor} floor={floor} units={getFloorUnits(floor)} selected={selectedFloor === floor} onSelect={() => setSelectedFloor(floor)} />
            ))}

            {/* Ground */}
            <div style={{ margin: "8px 10px 0", padding: "6px 10px", background: "#1A1714", borderRadius: "4px" }}>
              <span style={{ fontSize: "10px", color: "rgba(250,248,245,0.35)", fontWeight: 600 }}>LOBBY · AMENITIES · PARKING</span>
            </div>
          </div>

          {/* Stats */}
          <div style={{ padding: "12px 16px", borderTop: "1px solid var(--cp-border)", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "6px" }}>
            {[["Avail.", totalAvail, "#0D7A52"], ["Held", totalHeld, "#B45309"], ["Sold", totalSold, "#94A3B8"]].map(([l, v, c]) => (
              <div key={l as string} style={{ textAlign: "center" }}>
                <div style={{ fontSize: "15px", fontWeight: 700, color: c as string, fontFamily: "JetBrains Mono, monospace" }}>{v as number}</div>
                <div style={{ fontSize: "9px", color: "var(--cp-text-dim)" }}>{l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Floor Detail Panel ── */}
        <div>
          {/* Floor header */}
          <div style={{ background: "var(--cp-card)", border: "1px solid var(--cp-border)", borderRadius: "12px", padding: "20px 24px", marginBottom: "16px", boxShadow: "var(--cp-shadow)" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "4px" }}>
                  <span style={{ fontSize: "13px", fontWeight: 700, color: isPH ? "var(--cp-gold)" : "var(--cp-text-muted)", fontFamily: "JetBrains Mono, monospace" }}>
                    {isPH ? "PH" : `FLOOR ${selectedFloor}`}
                  </span>
                  <span style={{ padding: "3px 10px", borderRadius: "100px", fontSize: "11px", fontWeight: 700, background: isPH ? "var(--cp-gold-dim)" : "var(--cp-bg)", color: isPH ? "var(--cp-gold)" : "var(--cp-text-dim)", border: `1px solid ${isPH ? "var(--cp-gold)30" : "var(--cp-border)"}` }}>{label}</span>
                </div>
                <h2 style={{ fontSize: "22px", fontWeight: 400, color: "var(--cp-text)", fontFamily: "Instrument Serif, serif" }}>
                  {floorUnits.length} {floorUnits.length === 1 ? "Residence" : "Residences"}
                  {floorUnits.filter(u => u.status === "Available").length > 0 && (
                    <span style={{ fontSize: "14px", color: "#0D7A52", marginLeft: "10px" }}>· {floorUnits.filter(u => u.status === "Available").length} available</span>
                  )}
                </h2>
              </div>
              <div style={{ display: "flex", gap: "8px" }}>
                <button
                  onClick={() => setSelectedFloor(f => Math.max(2, f - 1))}
                  disabled={selectedFloor <= 2}
                  style={{ width: "32px", height: "32px", borderRadius: "8px", border: "1px solid var(--cp-border)", background: "var(--cp-bg)", cursor: selectedFloor > 2 ? "pointer" : "not-allowed", opacity: selectedFloor <= 2 ? 0.4 : 1, fontSize: "14px", color: "var(--cp-text-muted)" }}
                >↓</button>
                <button
                  onClick={() => setSelectedFloor(f => Math.min(24, f + 1))}
                  disabled={selectedFloor >= 24}
                  style={{ width: "32px", height: "32px", borderRadius: "8px", border: "1px solid var(--cp-border)", background: "var(--cp-bg)", cursor: selectedFloor < 24 ? "pointer" : "not-allowed", opacity: selectedFloor >= 24 ? 0.4 : 1, fontSize: "14px", color: "var(--cp-text-muted)" }}
                >↑</button>
              </div>
            </div>

            {/* Floor orientation diagram */}
            <div style={{ display: "flex", gap: "8px", marginTop: "14px", overflow: "hidden" }}>
              <div style={{ flex: 1, padding: "12px 14px", background: "var(--cp-bg)", borderRadius: "8px", border: "1px solid var(--cp-border)" }}>
                <p style={{ fontSize: "10px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "8px" }}>FLOOR PLATE ORIENTATION</p>
                <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
                  {floorUnits.map(u => (
                    <div key={u.id} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
                      <div style={{ width: "6px", height: "6px", borderRadius: "2px", background: STATUS_COLOR[u.status], opacity: u.status === "Sold" ? 0.4 : 1 }} />
                      <MiniCompass dir={u.orientation} size={36} />
                      <span style={{ fontSize: "9px", color: "var(--cp-text-dim)", fontFamily: "JetBrains Mono, monospace" }}>{u.position}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div style={{ padding: "12px 14px", background: "var(--cp-bg)", borderRadius: "8px", border: "1px solid var(--cp-border)", minWidth: "160px" }}>
                <p style={{ fontSize: "10px", fontWeight: 700, color: "var(--cp-text-dim)", letterSpacing: "0.06em", marginBottom: "8px" }}>PRICE RANGE</p>
                <p style={{ fontSize: "16px", fontWeight: 700, color: "var(--cp-text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
                  {fmtPrice(Math.min(...floorUnits.map(u => u.price)))}
                </p>
                <p style={{ fontSize: "12px", color: "var(--cp-text-muted)" }}>to {fmtPrice(Math.max(...floorUnits.map(u => u.price)))}</p>
              </div>
            </div>
          </div>

          {/* Unit cards grid */}
          <div style={{ display: "grid", gridTemplateColumns: `repeat(${isPH ? 2 : floorUnits.length <= 2 ? 2 : 2}, 1fr)`, gap: "14px" }}>
            {floorUnits.map(unit => (
              <UnitCard key={unit.id} unit={unit} onAction={onAction} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
