import { useState } from "react";

const AGENTS = [
  { id: "AG-001", name: "Alexandra Chen", email: "a.chen@acme.jacestates.com", phone: "+1 (305) 881-4477", role: "Senior Sales Agent", region: "South Florida", sales: "$14.2M", deals: 12, rating: 4.9, status: "Active", joined: "Mar 2022", license: "FL-RE-00841", color: "#059669", img: "photo-1494790108377-be9c29b29330" },
  { id: "AG-002", name: "Marcus Torres", email: "m.torres@acme.jacestates.com", phone: "+1 (212) 774-3310", role: "Senior Sales Agent", region: "New York Metro", sales: "$11.8M", deals: 10, rating: 4.7, status: "Active", joined: "Jun 2021", license: "NY-RE-07731", color: "#2563EB", img: "photo-1500648767791-00dcc994a43e" },
  { id: "AG-003", name: "Priya Singh", email: "p.singh@acme.jacestates.com", phone: "+1 (512) 640-8821", role: "Sales Agent", region: "Texas", sales: "$9.4M", deals: 9, rating: 4.8, status: "Active", joined: "Jan 2023", license: "TX-RE-04412", color: "#D97706", img: "photo-1487412720507-e7ab37603c6f" },
  { id: "AG-004", name: "Derek Okafor", email: "d.okafor@acme.jacestates.com", phone: "+1 (214) 552-0091", role: "Commercial Agent", region: "Texas / Dallas", sales: "$7.6M", deals: 7, rating: 4.5, status: "Active", joined: "Sep 2022", license: "TX-RE-05512", color: "#DC2626", img: "photo-1507003211169-0a1dd7228f2d" },
  { id: "AG-005", name: "Lena Brauer", email: "l.brauer@acme.jacestates.com", phone: "+1 (303) 748-2293", role: "Sales Agent", region: "Mountain West", sales: "$5.9M", deals: 6, rating: 4.6, status: "Active", joined: "May 2023", license: "CO-RE-03322", color: "#0891B2", img: "photo-1544005313-94ddf0286df2" },
  { id: "AG-006", name: "James A. Carter", email: "j.carter@acme.jacestates.com", phone: "+1 (305) 900-0001", role: "CEO & Principal Broker", region: "All Regions", sales: "$7.1M", deals: 4, rating: 5.0, status: "Active", joined: "Jan 2018", license: "FL-BROKER-0001", color: "#7C3AED", img: "photo-1472099645785-5658abf4ff4e" },
  { id: "AG-007", name: "Sofia Mendez", email: "s.mendez@acme.jacestates.com", phone: "+1 (415) 332-9981", role: "Sales Agent", region: "California", sales: "$3.1M", deals: 3, rating: 4.3, status: "On Leave", joined: "Feb 2024", license: "CA-RE-09981", color: "#94A3B8", img: "photo-1489424731084-a5d8b219a5bb" },
];

export default function Agents() {
  const [selected, setSelected] = useState<typeof AGENTS[0] | null>(null);
  const [view, setView] = useState<"cards" | "table">("cards");

  return (
    <div style={{ padding: "24px", display: "flex", flexDirection: "column", gap: "16px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: "20px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", color: "var(--text)", letterSpacing: "-0.02em" }}>Team & Agents</h1>
          <p style={{ fontSize: "13px", color: "var(--text-muted)", marginTop: "2px" }}>ERP · Human Resources · {AGENTS.length} agents on roster</p>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          <div style={{ display: "flex", border: "1px solid var(--border)", borderRadius: "8px", overflow: "hidden" }}>
            {(["cards", "table"] as const).map(v => (
              <button key={v} onClick={() => setView(v)} style={{ padding: "7px 14px", background: view === v ? "var(--bg-subtle)" : "var(--bg-card)", border: "none", cursor: "pointer", fontSize: "12px", fontWeight: 600, color: view === v ? "var(--text)" : "var(--text-muted)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
                {v === "cards" ? "⊞ Cards" : "≡ Table"}
              </button>
            ))}
          </div>
          <button style={{ padding: "7px 14px", background: "#059669", border: "none", borderRadius: "8px", fontSize: "13px", fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>+ Add Agent</button>
        </div>
      </div>

      {/* KPI strip */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px" }}>
        {[
          { l: "Total Team Sales", v: "$59.1M", c: "#059669" },
          { l: "Avg. Deals / Agent", v: "7.3", c: "var(--text)" },
          { l: "Team Rating", v: "4.7 ★", c: "#D97706" },
          { l: "Active Agents", v: `${AGENTS.filter(a => a.status === "Active").length}/${AGENTS.length}`, c: "var(--text)" },
        ].map(s => (
          <div key={s.l} style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", padding: "14px 16px" }}>
            <div style={{ fontSize: "12px", color: "var(--text-muted)", marginBottom: "6px" }}>{s.l}</div>
            <div style={{ fontSize: "22px", fontWeight: 700, color: s.c, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{s.v}</div>
          </div>
        ))}
      </div>

      {view === "cards" ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "12px" }}>
          {AGENTS.map(a => (
            <div key={a.id} onClick={() => setSelected(a)} style={{
              background: "var(--bg-card)", border: `1px solid ${selected?.id === a.id ? a.color : "var(--border)"}`,
              borderRadius: "10px", padding: "18px", cursor: "pointer", transition: "all 0.15s",
            }}
              onMouseEnter={e => { if (selected?.id !== a.id) (e.currentTarget as HTMLElement).style.borderColor = `${a.color}60`; }}
              onMouseLeave={e => { if (selected?.id !== a.id) (e.currentTarget as HTMLElement).style.borderColor = "var(--border)"; }}
            >
              <div style={{ display: "flex", alignItems: "flex-start", gap: "12px", marginBottom: "14px" }}>
                <div style={{ width: "44px", height: "44px", borderRadius: "10px", overflow: "hidden", flexShrink: 0, background: "var(--bg-subtle)" }}>
                  <img src={`https://images.unsplash.com/${a.img}?w=80&h=80&fit=crop&auto=format`} alt={a.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div style={{ fontSize: "14px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{a.name}</div>
                    <span style={{ padding: "2px 8px", borderRadius: "100px", fontSize: "10px", fontWeight: 600, background: a.status === "Active" ? "rgba(5,150,105,0.1)" : "rgba(148,163,184,0.1)", color: a.status === "Active" ? "#059669" : "#94A3B8", flexShrink: 0, marginLeft: "8px" }}>{a.status}</span>
                  </div>
                  <div style={{ fontSize: "12px", color: "var(--text-muted)", marginTop: "2px" }}>{a.role}</div>
                  <div style={{ fontSize: "11px", color: "var(--text-dim)", marginTop: "1px" }}>{a.region}</div>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "8px", paddingTop: "12px", borderTop: "1px solid var(--border)" }}>
                {[["Sales YTD", a.sales, a.color], ["Deals", a.deals.toString(), "var(--text)"], ["Rating", `${a.rating}★`, "#D97706"]].map(([l, v, c]) => (
                  <div key={l as string} style={{ textAlign: "center" }}>
                    <div style={{ fontSize: "13px", fontWeight: 700, color: c as string, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{v}</div>
                    <div style={{ fontSize: "10px", color: "var(--text-dim)", marginTop: "2px" }}>{l}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ borderBottom: "1px solid var(--border)" }}>
                {["Agent", "Role", "Region", "Sales YTD", "Deals", "Rating", "Status", "License"].map(h => (
                  <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: "10px", fontWeight: 700, color: "var(--text-dim)", letterSpacing: "0.06em", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {AGENTS.map((a, i) => (
                <tr key={a.id} style={{ borderBottom: i < AGENTS.length - 1 ? "1px solid var(--border)" : "none", cursor: "pointer", transition: "background 0.12s" }}
                  onClick={() => setSelected(a)}
                  onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = "var(--bg-hover)")}
                  onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = "transparent")}
                >
                  <td style={{ padding: "11px 14px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                      <div style={{ width: "32px", height: "32px", borderRadius: "8px", overflow: "hidden", flexShrink: 0, background: "var(--bg-subtle)" }}>
                        <img src={`https://images.unsplash.com/${a.img}?w=50&h=50&fit=crop&auto=format`} alt={a.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                      </div>
                      <span style={{ fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{a.name}</span>
                    </div>
                  </td>
                  <td style={{ padding: "11px 14px", fontSize: "12.5px", color: "var(--text-2)" }}>{a.role}</td>
                  <td style={{ padding: "11px 14px", fontSize: "12.5px", color: "var(--text-muted)" }}>{a.region}</td>
                  <td style={{ padding: "11px 14px", fontSize: "13px", fontWeight: 700, color: "#059669", fontFamily: "JetBrains Mono, monospace" }}>{a.sales}</td>
                  <td style={{ padding: "11px 14px", fontSize: "12.5px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{a.deals}</td>
                  <td style={{ padding: "11px 14px", fontSize: "12.5px", color: "#D97706" }}>{"★".repeat(Math.round(a.rating))}</td>
                  <td style={{ padding: "11px 14px" }}>
                    <span style={{ padding: "2px 8px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, background: a.status === "Active" ? "rgba(5,150,105,0.1)" : "rgba(148,163,184,0.1)", color: a.status === "Active" ? "#059669" : "#94A3B8" }}>{a.status}</span>
                  </td>
                  <td style={{ padding: "11px 14px", fontSize: "11.5px", color: "var(--text-dim)", fontFamily: "JetBrains Mono, monospace" }}>{a.license}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Detail drawer */}
      {selected && (
        <>
          <div onClick={() => setSelected(null)} style={{ position: "fixed", inset: 0, zIndex: 90 }} />
          <div style={{ position: "fixed", inset: "0 0 0 auto", width: "360px", background: "var(--bg-card)", borderLeft: "1px solid var(--border)", zIndex: 91, display: "flex", flexDirection: "column", boxShadow: "var(--shadow-lg)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 20px", borderBottom: "1px solid var(--border)" }}>
              <span style={{ fontSize: "14px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>Agent Profile</span>
              <button onClick={() => setSelected(null)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-dim)", fontSize: "18px" }}>×</button>
            </div>
            <div style={{ flex: 1, overflowY: "auto", padding: "20px" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", marginBottom: "20px", textAlign: "center" }}>
                <div style={{ width: "72px", height: "72px", borderRadius: "16px", overflow: "hidden", border: `2px solid ${selected.color}40`, background: "var(--bg-subtle)" }}>
                  <img src={`https://images.unsplash.com/${selected.img}?w=120&h=120&fit=crop&auto=format`} alt={selected.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                </div>
                <div>
                  <div style={{ fontSize: "16px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{selected.name}</div>
                  <div style={{ fontSize: "13px", color: "var(--text-muted)", marginTop: "2px" }}>{selected.role}</div>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "8px", marginBottom: "18px" }}>
                {[["Sales", selected.sales, selected.color], ["Deals", selected.deals.toString(), "var(--text)"], ["Rating", selected.rating.toString(), "#D97706"]].map(([l, v, c]) => (
                  <div key={l as string} style={{ background: "var(--bg-subtle)", borderRadius: "8px", padding: "10px 8px", textAlign: "center" }}>
                    <div style={{ fontSize: "14px", fontWeight: 700, color: c as string, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{v}</div>
                    <div style={{ fontSize: "11px", color: "var(--text-dim)", marginTop: "2px" }}>{l}</div>
                  </div>
                ))}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "0" }}>
                {[
                  ["Agent ID", selected.id],
                  ["Email", selected.email],
                  ["Phone", selected.phone],
                  ["Region", selected.region],
                  ["License", selected.license],
                  ["Status", selected.status],
                  ["Joined", selected.joined],
                ].map(([k, v]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
                    <span style={{ fontSize: "12px", color: "var(--text-dim)" }}>{k}</span>
                    <span style={{ fontSize: "12.5px", fontWeight: 500, color: "var(--text)", fontFamily: k === "Agent ID" || k === "License" ? "JetBrains Mono, monospace" : "inherit" }}>{v}</span>
                  </div>
                ))}
              </div>
              <div style={{ display: "flex", gap: "8px", marginTop: "18px" }}>
                <button style={{ flex: 1, padding: "9px", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: "8px", fontSize: "13px", color: "var(--text-2)", cursor: "pointer", fontWeight: 500 }}>Message</button>
                <button style={{ flex: 1, padding: "9px", background: "#059669", border: "none", borderRadius: "8px", fontSize: "13px", color: "#fff", cursor: "pointer", fontWeight: 600, fontFamily: "Plus Jakarta Sans, sans-serif" }}>Edit Profile</button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
