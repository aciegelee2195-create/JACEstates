import { useState, useEffect, useRef } from "react";

const SEARCH_INDEX = [
  { type: "Property", id: "P-1001", label: "8 Harbor Point Terrace", sub: "Miami, FL · $4.25M · Occupied", icon: "🏢" },
  { type: "Property", id: "P-1002", label: "301 Meridian Tower", sub: "New York, NY · $28.5M · 44/48 units", icon: "🏢" },
  { type: "Property", id: "P-1003", label: "Westbrook Estate", sub: "Beverly Hills, CA · $7.10M · Vacant", icon: "🏢" },
  { type: "Property", id: "P-1004", label: "Parkside Office Complex", sub: "Dallas, TX · $11.4M · Fully Occupied", icon: "🏢" },
  { type: "Lead", id: "L-0841", label: "Sophia Reeves", sub: "Under Contract · $4.25M · Agent: A. Chen", icon: "👤" },
  { type: "Lead", id: "L-0839", label: "Harlan Frost LLC", sub: "Offer Submitted · $7.10M · Commercial", icon: "👤" },
  { type: "Lead", id: "L-0836", label: "Marcus Elliott Partners", sub: "Tour Scheduled · $11.4M · Commercial", icon: "👤" },
  { type: "Deal", id: "D-2847", label: "D-2847 — Harbor Point Terrace", sub: "Closing · $4.25M · Due Sep 18", icon: "🤝" },
  { type: "Deal", id: "D-2846", label: "D-2846 — Meridian Tower #42B", sub: "Due Diligence · $2.85M · Agent: M. Torres", icon: "🤝" },
  { type: "Invoice", id: "INV-0221", label: "Invoice #INV-0221 — HVAC Service", sub: "Parkside Office · $4,200 · Pending", icon: "📄" },
  { type: "Invoice", id: "INV-0218", label: "Invoice #INV-0218 — Commission Payout", sub: "A. Chen · $42,600 · Approved", icon: "📄" },
  { type: "Tenant", id: "TEN-101", label: "Marcus Elliott — Suite 200", sub: "Parkside Office Complex · Lease exp. Dec 2027", icon: "🔑" },
  { type: "Tenant", id: "TEN-102", label: "Robert & Lisa Kim — #42B", sub: "Meridian Tower · $9,200/mo · Current", icon: "🔑" },
];

const RECENT = SEARCH_INDEX.slice(0, 4);

const TYPE_COLOR: Record<string, string> = {
  Property: "#059669",
  Lead: "#7C3AED",
  Deal: "#2563EB",
  Invoice: "#D97706",
  Tenant: "#0891B2",
};

interface Props { onClose: () => void; }

export default function GlobalSearch({ onClose }: Props) {
  const [query, setQuery] = useState("");
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowDown") setActiveIdx(i => Math.min(i + 1, results.length - 1));
      if (e.key === "ArrowUp") setActiveIdx(i => Math.max(i - 1, 0));
    }
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  const results = query.length > 0
    ? SEARCH_INDEX.filter(item =>
        item.label.toLowerCase().includes(query.toLowerCase()) ||
        item.sub.toLowerCase().includes(query.toLowerCase()) ||
        item.id.toLowerCase().includes(query.toLowerCase())
      )
    : RECENT;

  const grouped: Record<string, typeof results> = {};
  results.forEach(r => { (grouped[r.type] = grouped[r.type] || []).push(r); });

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.7)", backdropFilter: "blur(4px)", zIndex: 200 }}
      />
      {/* Modal */}
      <div style={{
        position: "fixed", top: "18%", left: "50%", transform: "translateX(-50%)",
        width: "580px", maxWidth: "calc(100vw - 32px)",
        background: "var(--bg-card)", border: "1px solid var(--border)",
        borderRadius: "14px", boxShadow: "0 24px 64px rgba(0,0,0,0.3)", zIndex: 201, overflow: "hidden",
      }}>
        {/* Input row */}
        <div style={{ display: "flex", alignItems: "center", gap: "12px", padding: "14px 18px", borderBottom: "1px solid var(--border)" }}>
          <span style={{ fontSize: "16px", color: "var(--text-muted)", flexShrink: 0 }}>⌕</span>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => { setQuery(e.target.value); setActiveIdx(0); }}
            placeholder="Search properties, tenants, leads, invoices…"
            style={{ flex: 1, background: "none", border: "none", outline: "none", fontSize: "15px", color: "var(--text)", fontFamily: "Inter, sans-serif" }}
          />
          {query && (
            <button onClick={() => setQuery("")} style={{ background: "none", border: "none", cursor: "pointer", fontSize: "14px", color: "var(--text-dim)", padding: "2px 6px", borderRadius: "4px" }}>✕</button>
          )}
          <kbd style={{ background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: "5px", padding: "2px 7px", fontSize: "11px", color: "var(--text-dim)", flexShrink: 0, fontFamily: "JetBrains Mono, monospace" }}>ESC</kbd>
        </div>

        {/* Results */}
        <div style={{ maxHeight: "440px", overflowY: "auto" }}>
          {query.length === 0 && (
            <div style={{ padding: "10px 18px 6px", fontSize: "10px", fontWeight: 700, color: "var(--text-dim)", letterSpacing: "0.08em", fontFamily: "Plus Jakarta Sans, sans-serif" }}>RECENT</div>
          )}

          {Object.entries(grouped).map(([type, items]) => (
            <div key={type}>
              {query.length > 0 && (
                <div style={{ padding: "10px 18px 4px", fontSize: "10px", fontWeight: 700, color: TYPE_COLOR[type], letterSpacing: "0.08em", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
                  {type.toUpperCase()}S
                </div>
              )}
              {items.map((item, itemIdx) => {
                const flatIdx = results.indexOf(item);
                const isActive = flatIdx === activeIdx;
                return (
                  <div key={item.id}
                    style={{
                      display: "flex", alignItems: "center", gap: "12px", padding: "10px 18px",
                      background: isActive ? "var(--bg-subtle)" : "transparent",
                      cursor: "pointer", transition: "background 0.1s",
                      borderLeft: isActive ? `2px solid ${TYPE_COLOR[item.type]}` : "2px solid transparent",
                    }}
                    onMouseEnter={() => setActiveIdx(flatIdx)}
                    onClick={onClose}
                  >
                    <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: `${TYPE_COLOR[item.type]}15`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", flexShrink: 0 }}>{item.icon}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: "13.5px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {query ? highlightMatch(item.label, query) : item.label}
                      </div>
                      <div style={{ fontSize: "12px", color: "var(--text-muted)", marginTop: "1px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.sub}</div>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", flexShrink: 0 }}>
                      <span style={{ fontSize: "10px", padding: "2px 7px", borderRadius: "4px", background: `${TYPE_COLOR[item.type]}15`, color: TYPE_COLOR[item.type], fontWeight: 600, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{item.type}</span>
                      {isActive && <span style={{ fontSize: "11px", color: "var(--text-dim)" }}>↵</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}

          {results.length === 0 && query.length > 0 && (
            <div style={{ padding: "40px 18px", textAlign: "center" }}>
              <div style={{ fontSize: "28px", marginBottom: "8px" }}>🔍</div>
              <div style={{ fontSize: "14px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>No results for "{query}"</div>
              <div style={{ fontSize: "13px", color: "var(--text-muted)", marginTop: "4px" }}>Try searching by property name, client, deal ID, or invoice.</div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ display: "flex", gap: "16px", padding: "10px 18px", borderTop: "1px solid var(--border)", background: "var(--bg-subtle)" }}>
          {[["↑↓", "Navigate"], ["↵", "Open"], ["ESC", "Close"]].map(([key, label]) => (
            <div key={key} style={{ display: "flex", alignItems: "center", gap: "5px" }}>
              <kbd style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "4px", padding: "1px 6px", fontSize: "11px", color: "var(--text-muted)", fontFamily: "JetBrains Mono, monospace" }}>{key}</kbd>
              <span style={{ fontSize: "11px", color: "var(--text-dim)" }}>{label}</span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function highlightMatch(text: string, query: string) {
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <mark style={{ background: "rgba(5,150,105,0.2)", color: "#059669", borderRadius: "2px", padding: "0 1px" }}>
        {text.slice(idx, idx + query.length)}
      </mark>
      {text.slice(idx + query.length)}
    </>
  );
}
