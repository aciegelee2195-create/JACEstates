import { useState } from "react";

const DEALS = [
  { id: "D-2847", property: "8 Harbor Point Terrace", client: "Sophia Reeves", value: 4250000, stage: "Closing", agent: "A. Chen", agentColor: "#059669", opened: "Aug 14", expected: "Sep 18, 2026", probability: 92, type: "Sale" },
  { id: "D-2846", property: "301 Meridian Tower #42B", client: "Robert & Lisa Kim", value: 2850000, stage: "Due Diligence", agent: "M. Torres", agentColor: "#2563EB", opened: "Jul 30", expected: "Oct 5, 2026", probability: 74, type: "Sale" },
  { id: "D-2845", property: "Westbrook Estate", client: "Harlan Frost LLC", value: 7100000, stage: "Negotiation", agent: "J. Carter", agentColor: "#7C3AED", opened: "Aug 25", expected: "Nov 1, 2026", probability: 60, type: "Commercial" },
  { id: "D-2844", property: "12 Fairview Commons", client: "Dana Osei", value: 680000, stage: "Offer Accepted", agent: "P. Singh", agentColor: "#D97706", opened: "Aug 30", expected: "Sep 28, 2026", probability: 85, type: "Sale" },
  { id: "D-2843", property: "47 Crestwood Blvd", client: "Nguyen Family Trust", value: 1320000, stage: "Inspection", agent: "A. Chen", agentColor: "#059669", opened: "Aug 12", expected: "Sep 30, 2026", probability: 70, type: "Sale" },
  { id: "D-2842", property: "Parkside Office Complex", client: "Marcus Elliott", value: 11400000, stage: "Letter of Intent", agent: "J. Carter", agentColor: "#7C3AED", opened: "Jun 15", expected: "Dec 1, 2026", probability: 45, type: "Commercial" },
  { id: "D-2841", property: "Sunset Lofts Unit 3C", client: "Claire Vandenberg", value: 495000, stage: "Initial Review", agent: "L. Brauer", agentColor: "#0891B2", opened: "Sep 2", expected: "Oct 20, 2026", probability: 55, type: "Sale" },
];

const STAGE_META: Record<string, { color: string; bg: string }> = {
  "Initial Review": { color: "#64748B", bg: "rgba(100,116,139,0.1)" },
  "Letter of Intent": { color: "#7C3AED", bg: "rgba(124,58,237,0.1)" },
  "Offer Accepted": { color: "#2563EB", bg: "rgba(37,99,235,0.1)" },
  "Inspection": { color: "#D97706", bg: "rgba(217,119,6,0.1)" },
  "Due Diligence": { color: "#D97706", bg: "rgba(217,119,6,0.1)" },
  "Negotiation": { color: "#0891B2", bg: "rgba(8,145,178,0.1)" },
  "Closing": { color: "#059669", bg: "rgba(5,150,105,0.1)" },
  "Closed": { color: "#059669", bg: "rgba(5,150,105,0.1)" },
};

function fmt(n: number) {
  return n >= 1_000_000 ? `$${(n / 1_000_000).toFixed(2)}M` : `$${(n / 1_000).toFixed(0)}K`;
}

export default function Deals() {
  const [selected, setSelected] = useState<typeof DEALS[0] | null>(null);
  const totalWeighted = DEALS.reduce((s, d) => s + d.value * (d.probability / 100), 0);

  return (
    <div style={{ padding: "24px", display: "flex", flexDirection: "column", gap: "16px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: "20px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", color: "var(--text)", letterSpacing: "-0.02em" }}>Transactions</h1>
          <p style={{ fontSize: "13px", color: "var(--text-muted)", marginTop: "2px" }}>
            {DEALS.length} active deals · Weighted pipeline: <strong style={{ color: "var(--text)" }}>{fmt(totalWeighted)}</strong>
          </p>
        </div>
        <button style={{ padding: "7px 14px", background: "#059669", border: "none", borderRadius: "8px", fontSize: "13px", fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>+ New Deal</button>
      </div>

      {/* Stage summary */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px" }}>
        {[
          { l: "Total Pipeline", v: fmt(DEALS.reduce((s, d) => s + d.value, 0)), color: "var(--text)" },
          { l: "Weighted Value", v: fmt(totalWeighted), color: "#059669" },
          { l: "Near Closing", v: DEALS.filter(d => d.probability >= 80).length.toString(), color: "#059669" },
          { l: "Avg. Probability", v: `${Math.round(DEALS.reduce((s, d) => s + d.probability, 0) / DEALS.length)}%`, color: "#2563EB" },
        ].map(s => (
          <div key={s.l} style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", padding: "14px 16px" }}>
            <div style={{ fontSize: "12px", color: "var(--text-muted)", marginBottom: "6px" }}>{s.l}</div>
            <div style={{ fontSize: "22px", fontWeight: 700, color: s.color, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{s.v}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: "16px" }}>
        {/* Main table */}
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ borderBottom: "1px solid var(--border)" }}>
                {["Deal ID", "Property / Client", "Value", "Stage", "Prob.", "Agent", "Expected Close"].map(h => (
                  <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: "10px", fontWeight: 700, color: "var(--text-dim)", letterSpacing: "0.06em", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {DEALS.map((d, i) => {
                const meta = STAGE_META[d.stage];
                const isActive = selected?.id === d.id;
                return (
                  <tr key={d.id}
                    style={{ borderBottom: i < DEALS.length - 1 ? "1px solid var(--border)" : "none", cursor: "pointer", background: isActive ? "rgba(5,150,105,0.04)" : "transparent", transition: "background 0.12s" }}
                    onClick={() => setSelected(isActive ? null : d)}
                    onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)"; }}
                    onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = "transparent"; }}
                  >
                    <td style={{ padding: "11px 14px", fontSize: "12px", color: "var(--text-dim)", fontFamily: "JetBrains Mono, monospace" }}>{d.id}</td>
                    <td style={{ padding: "11px 14px" }}>
                      <div style={{ fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{d.property}</div>
                      <div style={{ fontSize: "12px", color: "var(--text-muted)", marginTop: "1px" }}>{d.client}</div>
                    </td>
                    <td style={{ padding: "11px 14px", fontSize: "13px", fontWeight: 700, color: "var(--text)", fontFamily: "JetBrains Mono, monospace" }}>{fmt(d.value)}</td>
                    <td style={{ padding: "11px 14px" }}>
                      <span style={{ padding: "3px 8px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, background: meta.bg, color: meta.color }}>{d.stage}</span>
                    </td>
                    <td style={{ padding: "11px 14px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "7px" }}>
                        <div style={{ width: "44px", height: "4px", background: "var(--bg-subtle)", borderRadius: "2px" }}>
                          <div style={{ height: "100%", width: `${d.probability}%`, background: d.probability >= 80 ? "#059669" : d.probability >= 60 ? "#D97706" : "#DC2626", borderRadius: "2px" }} />
                        </div>
                        <span style={{ fontSize: "12px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{d.probability}%</span>
                      </div>
                    </td>
                    <td style={{ padding: "11px 14px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                        <div style={{ width: "22px", height: "22px", borderRadius: "6px", background: d.agentColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "9px", fontWeight: 700, color: "#fff", fontFamily: "Plus Jakarta Sans, sans-serif", flexShrink: 0 }}>
                          {d.agent.split(" ").map(n => n[0]).join("")}
                        </div>
                        <span style={{ fontSize: "12px", color: "var(--text-2)" }}>{d.agent}</span>
                      </div>
                    </td>
                    <td style={{ padding: "11px 14px", fontSize: "12px", color: "var(--text-muted)" }}>{d.expected}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Side detail */}
        {selected ? (
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", padding: "20px", display: "flex", flexDirection: "column", gap: "14px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <h3 style={{ fontSize: "14px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>Deal Detail</h3>
              <button onClick={() => setSelected(null)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-dim)", fontSize: "16px" }}>×</button>
            </div>
            <div>
              <div style={{ fontSize: "15px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{selected.property}</div>
              <div style={{ fontSize: "13px", color: "var(--text-muted)", marginTop: "2px" }}>{selected.client}</div>
            </div>
            <div style={{ fontSize: "28px", fontWeight: 700, color: "#059669", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{fmt(selected.value)}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              {[
                ["Deal ID", selected.id],
                ["Type", selected.type],
                ["Stage", selected.stage],
                ["Probability", `${selected.probability}%`],
                ["Agent", selected.agent],
                ["Opened", selected.opened],
                ["Expected Close", selected.expected],
              ].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", paddingBottom: "8px", borderBottom: "1px solid var(--border)" }}>
                  <span style={{ fontSize: "12px", color: "var(--text-dim)" }}>{k}</span>
                  <span style={{ fontSize: "12.5px", fontWeight: 600, color: k === "Probability" ? "#059669" : "var(--text)", fontFamily: k === "Deal ID" ? "JetBrains Mono, monospace" : "inherit" }}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: "8px" }}>
              <button style={{ flex: 1, padding: "8px", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: "8px", fontSize: "12px", color: "var(--text-2)", cursor: "pointer", fontWeight: 500 }}>Update Stage</button>
              <button style={{ flex: 1, padding: "8px", background: "#059669", border: "none", borderRadius: "8px", fontSize: "12px", color: "#fff", cursor: "pointer", fontWeight: 600, fontFamily: "Plus Jakarta Sans, sans-serif" }}>View Full →</button>
            </div>
          </div>
        ) : (
          <div style={{ background: "var(--bg-card)", border: "1px dashed var(--border)", borderRadius: "10px", padding: "32px 20px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "8px", color: "var(--text-dim)" }}>
            <span style={{ fontSize: "24px" }}>🤝</span>
            <p style={{ fontSize: "13px", textAlign: "center" }}>Click a deal row to see full details here</p>
          </div>
        )}
      </div>
    </div>
  );
}
