import { useState } from "react";

interface LeaseDetail {
  unit: string;
  tenant: string;
  expires: string;
  rent: string;
  status: "Current" | "Expiring Soon" | "Expired";
}

interface MaintenanceTicket {
  id: string;
  issue: string;
  priority: "High" | "Medium" | "Low";
  status: "Open" | "In Progress" | "Resolved";
  raised: string;
}

interface Property {
  id: string;
  name: string;
  type: "Residential" | "Commercial" | "Industrial";
  location: string;
  units: number;
  occupied: number;
  monthlyYield: string;
  annualRevenue: string;
  status: "Fully Occupied" | "Partially Occupied" | "Vacant" | "Under Maintenance";
  manager: string;
  acquired: string;
  value: string;
  leases: LeaseDetail[];
  tickets: MaintenanceTicket[];
}

const PROPERTIES: Property[] = [
  {
    id: "P-1001", name: "8 Harbor Point Terrace", type: "Residential", location: "Miami, FL", units: 1, occupied: 1,
    monthlyYield: "$18,400", annualRevenue: "$220,800", status: "Fully Occupied", manager: "A. Chen", acquired: "Mar 2019", value: "$4.25M",
    leases: [{ unit: "Main Residence", tenant: "Sophia Reeves", expires: "Dec 31, 2026", rent: "$18,400/mo", status: "Current" }],
    tickets: [{ id: "T-441", issue: "Pool pump maintenance", priority: "Low", status: "Resolved", raised: "Aug 28" }],
  },
  {
    id: "P-1002", name: "301 Meridian Tower", type: "Residential", location: "New York, NY", units: 48, occupied: 44,
    monthlyYield: "$124,000", annualRevenue: "$1.49M", status: "Partially Occupied", manager: "M. Torres", acquired: "Jun 2021", value: "$28.5M",
    leases: [
      { unit: "#42B", tenant: "Robert & Lisa Kim", expires: "Mar 15, 2027", rent: "$9,200/mo", status: "Current" },
      { unit: "#14C", tenant: "Marcus Elliott", expires: "Oct 1, 2026", rent: "$7,800/mo", status: "Expiring Soon" },
      { unit: "#08A", tenant: "Vacant", expires: "—", rent: "—", status: "Expired" },
    ],
    tickets: [
      { id: "T-438", issue: "Elevator 2 inspection due", priority: "High", status: "Open", raised: "Sep 1" },
      { id: "T-435", issue: "Lobby lighting replacement", priority: "Medium", status: "In Progress", raised: "Aug 25" },
    ],
  },
  {
    id: "P-1003", name: "Westbrook Estate", type: "Commercial", location: "Beverly Hills, CA", units: 1, occupied: 0,
    monthlyYield: "—", annualRevenue: "—", status: "Vacant", manager: "J. Carter", acquired: "Jan 2023", value: "$7.10M",
    leases: [],
    tickets: [{ id: "T-440", issue: "Pre-sale inspection & staging", priority: "High", status: "In Progress", raised: "Sep 1" }],
  },
  {
    id: "P-1004", name: "Parkside Office Complex", type: "Commercial", location: "Dallas, TX", units: 22, occupied: 22,
    monthlyYield: "$87,000", annualRevenue: "$1.04M", status: "Fully Occupied", manager: "D. Okafor", acquired: "Feb 2020", value: "$11.4M",
    leases: [
      { unit: "Suite 100", tenant: "TechVentures Inc.", expires: "Jun 30, 2028", rent: "$14,200/mo", status: "Current" },
      { unit: "Suite 200–210", tenant: "Meridian Law Group", expires: "Dec 31, 2027", rent: "$28,400/mo", status: "Current" },
    ],
    tickets: [{ id: "T-432", issue: "HVAC quarterly service", priority: "Medium", status: "Resolved", raised: "Aug 15" }],
  },
  {
    id: "P-1005", name: "47 Crestwood Blvd", type: "Residential", location: "Seattle, WA", units: 1, occupied: 0,
    monthlyYield: "—", annualRevenue: "—", status: "Under Maintenance", manager: "A. Chen", acquired: "Aug 2022", value: "$1.32M",
    leases: [],
    tickets: [
      { id: "T-441", issue: "Roof replacement — storm damage", priority: "High", status: "In Progress", raised: "Aug 20" },
      { id: "T-439", issue: "Electrical panel upgrade", priority: "High", status: "Open", raised: "Sep 2" },
    ],
  },
  {
    id: "P-1006", name: "Sunset Lofts Block C", type: "Residential", location: "Denver, CO", units: 24, occupied: 21,
    monthlyYield: "$42,000", annualRevenue: "$504,000", status: "Partially Occupied", manager: "L. Brauer", acquired: "Sep 2022", value: "$9.8M",
    leases: [
      { unit: "Unit 3C", tenant: "Claire Vandenberg", expires: "Apr 30, 2027", rent: "$2,100/mo", status: "Current" },
      { unit: "Unit 1A, 2B, 4D", tenant: "Vacant", expires: "—", rent: "—", status: "Expired" },
    ],
    tickets: [{ id: "T-430", issue: "Parking lot reseal", priority: "Low", status: "Open", raised: "Aug 10" }],
  },
];

const STATUS_META: Record<string, { color: string; bg: string }> = {
  "Fully Occupied": { color: "#059669", bg: "rgba(5,150,105,0.1)" },
  "Partially Occupied": { color: "#2563EB", bg: "rgba(37,99,235,0.1)" },
  "Vacant": { color: "#D97706", bg: "rgba(217,119,6,0.1)" },
  "Under Maintenance": { color: "#DC2626", bg: "rgba(220,38,38,0.1)" },
};

const PRIORITY_COLOR = { High: "#DC2626", Medium: "#D97706", Low: "#059669" };
const TICKET_STATUS_COLOR = { "Open": "#DC2626", "In Progress": "#D97706", "Resolved": "#059669" };
const LEASE_STATUS_COLOR = { "Current": "#059669", "Expiring Soon": "#D97706", "Expired": "#DC2626" };

export default function Properties() {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [typeFilter, setTypeFilter] = useState<"All" | "Residential" | "Commercial" | "Industrial">("All");
  const [statusFilter, setStatusFilter] = useState("All");

  const filtered = PROPERTIES.filter(p =>
    (typeFilter === "All" || p.type === typeFilter) &&
    (statusFilter === "All" || p.status === statusFilter)
  );

  const toggleSelect = (id: string) => {
    setSelectedIds(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  const totalValue = PROPERTIES.reduce((s, p) => {
    const v = parseFloat(p.value.replace(/[$M]/g, "")) * (p.value.includes("M") ? 1 : 0.001);
    return s + v;
  }, 0);

  const fSA = (active: boolean): React.CSSProperties => ({
    padding: "6px 12px", border: "1px solid var(--border)", borderRadius: "8px",
    background: active ? "rgba(5,150,105,0.1)" : "var(--bg-card)",
    color: active ? "#059669" : "var(--text-2)", borderColor: active ? "rgba(5,150,105,0.3)" : "var(--border)",
    cursor: "pointer", fontSize: "12.5px", fontFamily: "Inter, sans-serif",
  });

  return (
    <div style={{ padding: "24px", display: "flex", flexDirection: "column", gap: "16px" }}>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: "20px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", color: "var(--text)", letterSpacing: "-0.02em" }}>ERP · Property Management</h1>
          <p style={{ fontSize: "13px", color: "var(--text-muted)", marginTop: "2px" }}>{filtered.length} properties · Total portfolio: <strong style={{ color: "var(--text)" }}>${totalValue.toFixed(1)}M</strong></p>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          <button style={{ padding: "7px 14px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", fontSize: "13px", color: "var(--text-2)", cursor: "pointer" }}>Import CSV</button>
          <button style={{ padding: "7px 14px", background: "#059669", border: "none", borderRadius: "8px", fontSize: "13px", fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>+ Add Property</button>
        </div>
      </div>

      {/* Summary cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px" }}>
        {[
          { l: "Total Properties", v: PROPERTIES.length.toString(), c: "#059669" },
          { l: "Fully Occupied", v: PROPERTIES.filter(p => p.status === "Fully Occupied").length.toString(), c: "#059669" },
          { l: "Vacant Units", v: PROPERTIES.reduce((s, p) => s + (p.units - p.occupied), 0).toString(), c: "#D97706" },
          { l: "Open Tickets", v: PROPERTIES.flatMap(p => p.tickets).filter(t => t.status !== "Resolved").length.toString(), c: "#DC2626" },
        ].map(s => (
          <div key={s.l} style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", padding: "14px 16px" }}>
            <div style={{ fontSize: "12px", color: "var(--text-muted)", marginBottom: "6px" }}>{s.l}</div>
            <div style={{ fontSize: "22px", fontWeight: 700, color: s.c, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{s.v}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
        {(["All", "Residential", "Commercial", "Industrial"] as const).map(t => (
          <button key={t} onClick={() => setTypeFilter(t)} style={fSA(typeFilter === t)}>{t}</button>
        ))}
        <div style={{ width: "1px", height: "20px", background: "var(--border)", alignSelf: "center" }} />
        {(["All", "Fully Occupied", "Partially Occupied", "Vacant", "Under Maintenance"]).map(s => (
          <button key={s} onClick={() => setStatusFilter(s)} style={fSA(statusFilter === s)}>{s === "All" ? "All Statuses" : s}</button>
        ))}
      </div>

      {/* Bulk action bar */}
      {selectedIds.size > 0 && (
        <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px 16px", background: "#0F172A", borderRadius: "8px" }}>
          <span style={{ fontSize: "13px", fontWeight: 600, color: "#fff", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{selectedIds.size} selected</span>
          <div style={{ flex: 1 }} />
          {["Export CSV", "Assign Manager", "Send Notice", "Generate Report"].map(a => (
            <button key={a} style={{ padding: "6px 12px", background: "#1E293B", border: "1px solid #334155", borderRadius: "6px", fontSize: "12px", color: "#CBD5E1", cursor: "pointer" }}>{a}</button>
          ))}
          <button onClick={() => setSelectedIds(new Set())} style={{ padding: "6px 12px", background: "none", border: "1px solid #334155", borderRadius: "6px", fontSize: "12px", color: "#64748B", cursor: "pointer" }}>✕ Clear</button>
        </div>
      )}

      {/* Main table */}
      <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden" }}>
        {/* Table header */}
        <div style={{ display: "grid", gridTemplateColumns: "36px 1fr 100px 80px 90px 100px 120px 110px 80px", gap: "0", borderBottom: "1px solid var(--border)", padding: "10px 0" }}>
          <div style={{ padding: "0 16px" }}>
            <input type="checkbox" style={{ cursor: "pointer" }}
              onChange={e => setSelectedIds(e.target.checked ? new Set(filtered.map(p => p.id)) : new Set())}
            />
          </div>
          {["Asset Name", "Type", "Units", "Occ. Rate", "Mo. Yield", "Annual Revenue", "Status", "Action"].map(h => (
            <div key={h} style={{ fontSize: "10px", fontWeight: 700, color: "var(--text-dim)", letterSpacing: "0.06em", fontFamily: "Plus Jakarta Sans, sans-serif", padding: "0 12px", alignSelf: "center" }}>{h.toUpperCase()}</div>
          ))}
        </div>

        {/* Rows */}
        {filtered.map((p, i) => {
          const isExpanded = expanded === p.id;
          const isSelected = selectedIds.has(p.id);
          const occPct = p.units > 0 ? Math.round((p.occupied / p.units) * 100) : 0;
          const meta = STATUS_META[p.status];

          return (
            <div key={p.id} style={{ borderBottom: i < filtered.length - 1 || isExpanded ? "1px solid var(--border)" : "none" }}>
              {/* Main row */}
              <div
                style={{ display: "grid", gridTemplateColumns: "36px 1fr 100px 80px 90px 100px 120px 110px 80px", cursor: "pointer", transition: "background 0.12s", background: isSelected ? "rgba(5,150,105,0.04)" : "transparent", padding: "4px 0" }}
                onMouseEnter={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)"; }}
                onMouseLeave={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = isSelected ? "rgba(5,150,105,0.04)" : "transparent"; }}
                onClick={() => setExpanded(isExpanded ? null : p.id)}
              >
                <div style={{ padding: "12px 16px" }} onClick={e => e.stopPropagation()}>
                  <input type="checkbox" checked={isSelected} onChange={() => toggleSelect(p.id)} style={{ cursor: "pointer" }} />
                </div>
                <div style={{ padding: "12px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <span style={{ fontSize: "14px", color: isExpanded ? "#059669" : "var(--text-dim)", transition: "transform 0.2s", display: "inline-block", transform: isExpanded ? "rotate(90deg)" : "none" }}>›</span>
                    <div>
                      <div style={{ fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{p.name}</div>
                      <div style={{ display: "flex", gap: "8px", marginTop: "2px" }}>
                        <span style={{ fontSize: "10px", color: "var(--text-dim)", fontFamily: "JetBrains Mono, monospace" }}>{p.id}</span>
                        <span style={{ fontSize: "11px", color: "var(--text-dim)" }}>{p.location}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div style={{ padding: "12px", alignSelf: "center" }}>
                  <span style={{ fontSize: "11px", padding: "2px 7px", borderRadius: "5px", background: "var(--bg-subtle)", color: "var(--text-muted)", fontWeight: 500 }}>{p.type}</span>
                </div>
                <div style={{ padding: "12px", alignSelf: "center", fontSize: "13px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{p.occupied}/{p.units}</div>
                <div style={{ padding: "12px", alignSelf: "center" }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                      <div style={{ width: "40px", height: "4px", background: "var(--bg-subtle)", borderRadius: "2px" }}>
                        <div style={{ height: "100%", width: `${occPct}%`, background: occPct >= 90 ? "#059669" : occPct >= 60 ? "#D97706" : "#DC2626", borderRadius: "2px" }} />
                      </div>
                      <span style={{ fontSize: "11px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{p.units > 0 ? `${occPct}%` : "—"}</span>
                    </div>
                  </div>
                </div>
                <div style={{ padding: "12px", alignSelf: "center", fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "JetBrains Mono, monospace" }}>{p.monthlyYield}</div>
                <div style={{ padding: "12px", alignSelf: "center", fontSize: "12.5px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{p.annualRevenue}</div>
                <div style={{ padding: "12px", alignSelf: "center" }}>
                  <span style={{ padding: "3px 8px", borderRadius: "100px", fontSize: "10px", fontWeight: 600, background: meta.bg, color: meta.color, fontFamily: "Plus Jakarta Sans, sans-serif", whiteSpace: "nowrap" }}>{p.status}</span>
                </div>
                <div style={{ padding: "12px", alignSelf: "center" }} onClick={e => e.stopPropagation()}>
                  <button style={{ padding: "4px 10px", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: "6px", fontSize: "12px", color: "var(--text-muted)", cursor: "pointer" }}>•••</button>
                </div>
              </div>

              {/* ── Expanded sub-panel ── */}
              {isExpanded && (
                <div style={{ background: "var(--bg-subtle)", borderTop: "1px solid var(--border)", padding: "20px 24px 20px 60px" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>

                    {/* Lease details */}
                    <div>
                      <h4 style={{ fontSize: "12px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", letterSpacing: "0.04em", marginBottom: "10px" }}>LEASE EXPIRY SCHEDULE</h4>
                      {p.leases.length === 0 ? (
                        <p style={{ fontSize: "12px", color: "var(--text-dim)" }}>No active leases.</p>
                      ) : (
                        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", overflow: "hidden" }}>
                          <table style={{ width: "100%", borderCollapse: "collapse" }}>
                            <thead>
                              <tr style={{ borderBottom: "1px solid var(--border)" }}>
                                {["Unit", "Tenant", "Expires", "Rent", "Status"].map(h => (
                                  <th key={h} style={{ padding: "8px 12px", textAlign: "left", fontSize: "10px", fontWeight: 700, color: "var(--text-dim)", letterSpacing: "0.05em" }}>{h}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {p.leases.map((l, li) => (
                                <tr key={li} style={{ borderBottom: li < p.leases.length - 1 ? "1px solid var(--border)" : "none" }}>
                                  <td style={{ padding: "8px 12px", fontSize: "12px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{l.unit}</td>
                                  <td style={{ padding: "8px 12px", fontSize: "12px", fontWeight: 600, color: "var(--text)" }}>{l.tenant}</td>
                                  <td style={{ padding: "8px 12px", fontSize: "12px", color: "var(--text-muted)" }}>{l.expires}</td>
                                  <td style={{ padding: "8px 12px", fontSize: "12px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{l.rent}</td>
                                  <td style={{ padding: "8px 12px" }}>
                                    <span style={{ padding: "2px 7px", borderRadius: "100px", fontSize: "10px", fontWeight: 600, background: `${LEASE_STATUS_COLOR[l.status]}15`, color: LEASE_STATUS_COLOR[l.status] }}>{l.status}</span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>

                    {/* Maintenance tickets */}
                    <div>
                      <h4 style={{ fontSize: "12px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", letterSpacing: "0.04em", marginBottom: "10px" }}>MAINTENANCE REQUESTS</h4>
                      {p.tickets.length === 0 ? (
                        <p style={{ fontSize: "12px", color: "var(--text-dim)" }}>No open tickets.</p>
                      ) : (
                        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", overflow: "hidden" }}>
                          {p.tickets.map((t, ti) => (
                            <div key={t.id} style={{ display: "flex", alignItems: "center", gap: "12px", padding: "10px 14px", borderBottom: ti < p.tickets.length - 1 ? "1px solid var(--border)" : "none" }}>
                              <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: PRIORITY_COLOR[t.priority], flexShrink: 0 }} />
                              <div style={{ flex: 1 }}>
                                <div style={{ fontSize: "12.5px", fontWeight: 500, color: "var(--text)" }}>{t.issue}</div>
                                <div style={{ fontSize: "11px", color: "var(--text-dim)", marginTop: "1px" }}>Raised {t.raised} · <span style={{ fontFamily: "JetBrains Mono, monospace" }}>{t.id}</span></div>
                              </div>
                              <span style={{ padding: "2px 7px", borderRadius: "100px", fontSize: "10px", fontWeight: 600, background: `${TICKET_STATUS_COLOR[t.status]}15`, color: TICKET_STATUS_COLOR[t.status] }}>{t.status}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      {/* Actions */}
                      <div style={{ display: "flex", gap: "8px", marginTop: "12px" }}>
                        <button style={{ padding: "6px 12px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "6px", fontSize: "12px", color: "var(--text-2)", cursor: "pointer" }}>View Contracts →</button>
                        <button style={{ padding: "6px 12px", background: "rgba(5,150,105,0.1)", border: "1px solid rgba(5,150,105,0.3)", borderRadius: "6px", fontSize: "12px", color: "#059669", cursor: "pointer", fontWeight: 500 }}>+ New Ticket</button>
                      </div>
                    </div>

                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
