import { useState } from "react";
import { useBooking } from "../../contexts/BookingContext";
import { fmtPrice } from "../../data/buildingData";
import type { UnitStatus } from "../../data/buildingData";

const STATUS_META: Record<UnitStatus, { label: string; color: string; bg: string }> = {
  Available: { label: "Available", color: "#059669", bg: "rgba(5,150,105,0.10)" },
  Held:      { label: "On Hold",   color: "#D97706", bg: "rgba(217,119,6,0.10)"  },
  Reserved:  { label: "Reserved",  color: "#7C3AED", bg: "rgba(124,58,237,0.10)" },
  Sold:      { label: "Sold",      color: "#64748B", bg: "rgba(100,116,139,0.10)" },
};

export default function ERPInventory() {
  const { units, deals } = useBooking();
  const [statusFilter, setStatusFilter] = useState<UnitStatus | "All">("All");
  const [search, setSearch] = useState("");

  const filtered = units.filter(u =>
    (statusFilter === "All" || u.status === statusFilter) &&
    (search === "" || u.id.toLowerCase().includes(search.toLowerCase()) || u.type.toLowerCase().includes(search.toLowerCase()))
  );

  const counts: Record<string, number> = {
    All: units.length,
    Available: units.filter(u => u.status === "Available").length,
    Held: units.filter(u => u.status === "Held").length,
    Reserved: units.filter(u => u.status === "Reserved").length,
    Sold: units.filter(u => u.status === "Sold").length,
  };

  const getDealClient = (unitId: string) => {
    const deal = deals.find(d => d.unitId === unitId);
    return deal?.clientName ?? null;
  };

  const th: React.CSSProperties = { padding: "10px 12px", textAlign: "left", fontSize: "11px", fontWeight: 700, color: "var(--text-muted)", letterSpacing: "0.05em", textTransform: "uppercase", borderBottom: "1px solid var(--border)", whiteSpace: "nowrap" };
  const td: React.CSSProperties = { padding: "10px 12px", fontSize: "13px", color: "var(--text)", borderBottom: "1px solid var(--border)", verticalAlign: "middle" };

  return (
    <div style={{ padding: "24px 28px" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "20px" }}>
        <div>
          <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "4px" }}>ERP Inventory</h2>
          <p style={{ fontSize: "13px", color: "var(--text-muted)" }}>Meridian Residences · {units.length} total units · Live sync</p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "6px", padding: "6px 12px", background: "rgba(5,150,105,0.08)", border: "1px solid rgba(5,150,105,0.2)", borderRadius: "100px" }}>
          <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#059669" }} />
          <span style={{ fontSize: "11px", fontWeight: 600, color: "#059669" }}>Synced</span>
        </div>
      </div>

      {/* Status filter tabs */}
      <div style={{ display: "flex", gap: "6px", marginBottom: "16px", flexWrap: "wrap" }}>
        {(["All", "Available", "Held", "Reserved", "Sold"] as const).map(s => (
          <button key={s} onClick={() => setStatusFilter(s)} style={{
            padding: "5px 13px", border: `1px solid ${statusFilter === s ? (s === "All" ? "#059669" : STATUS_META[s as UnitStatus]?.color ?? "#059669") : "var(--border)"}`,
            borderRadius: "100px", background: statusFilter === s ? (s === "All" ? "rgba(5,150,105,0.1)" : STATUS_META[s as UnitStatus]?.bg ?? "rgba(5,150,105,0.1)") : "var(--bg-card)",
            color: statusFilter === s ? (s === "All" ? "#059669" : STATUS_META[s as UnitStatus]?.color ?? "#059669") : "var(--text-muted)",
            fontSize: "12px", cursor: "pointer", fontWeight: statusFilter === s ? 700 : 400, transition: "all 0.15s",
          }}>
            {s} <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "10px" }}>({counts[s]})</span>
          </button>
        ))}
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search unit ID or type…"
          style={{ marginLeft: "auto", padding: "5px 12px", border: "1px solid var(--border)", borderRadius: "8px", background: "var(--bg-card)", color: "var(--text)", fontSize: "12px", outline: "none", width: "200px" }}
          onFocus={e => (e.target.style.borderColor = "#059669")}
          onBlur={e => (e.target.style.borderColor = "var(--border)")}
        />
      </div>

      {/* Table */}
      <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "var(--bg-subtle)" }}>
                <th style={th}>Unit ID</th>
                <th style={th}>Floor</th>
                <th style={th}>Type</th>
                <th style={th}>Sqft</th>
                <th style={th}>Price</th>
                <th style={th}>Orientation</th>
                <th style={th}>Status</th>
                <th style={th}>Client</th>
                <th style={th}>Hold Expiry</th>
                <th style={th}>Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(u => {
                const meta = STATUS_META[u.status];
                const client = u.holdClient ?? getDealClient(u.id);
                const locked = u.status === "Held" || u.status === "Reserved" || u.status === "Sold";
                return (
                  <tr key={u.id} style={{ transition: "background 0.1s" }}
                    onMouseEnter={e => (e.currentTarget.style.background = "var(--bg-subtle)")}
                    onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
                  >
                    <td style={td}>
                      <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                        {locked && <span title="Locked" style={{ fontSize: "12px" }}>🔒</span>}
                        <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "12px", color: "var(--text)" }}>{u.id}</span>
                      </div>
                    </td>
                    <td style={{ ...td, fontFamily: "JetBrains Mono, monospace" }}>{u.floor}</td>
                    <td style={td}>{u.type}</td>
                    <td style={{ ...td, fontFamily: "JetBrains Mono, monospace" }}>{u.sqft.toLocaleString()}</td>
                    <td style={{ ...td, fontFamily: "JetBrains Mono, monospace", fontWeight: 600 }}>{fmtPrice(u.price)}</td>
                    <td style={td}>
                      <span style={{ padding: "2px 7px", borderRadius: "4px", background: "var(--bg-subtle)", fontSize: "11px", fontFamily: "JetBrains Mono, monospace" }}>{u.orientation}</span>
                    </td>
                    <td style={td}>
                      <span style={{ padding: "3px 9px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, background: meta.bg, color: meta.color, border: `1px solid ${meta.color}30` }}>{meta.label}</span>
                    </td>
                    <td style={{ ...td, maxWidth: "140px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {client ? <span style={{ fontSize: "12px", color: "var(--text)" }}>{client}</span> : <span style={{ color: "var(--text-muted)", fontSize: "12px" }}>—</span>}
                    </td>
                    <td style={{ ...td, fontFamily: "JetBrains Mono, monospace", fontSize: "11px" }}>
                      {u.holdExpiry ?? <span style={{ color: "var(--text-muted)" }}>—</span>}
                    </td>
                    <td style={td}>
                      <button style={{ padding: "4px 10px", border: "1px solid var(--border)", borderRadius: "6px", background: "none", fontSize: "11px", color: "var(--text-muted)", cursor: "pointer" }}>
                        View
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div style={{ padding: "10px 16px", borderTop: "1px solid var(--border)", fontSize: "12px", color: "var(--text-muted)", display: "flex", justifyContent: "space-between" }}>
          <span>Showing {filtered.length} of {units.length} units</span>
          <span style={{ fontFamily: "JetBrains Mono, monospace" }}>
            Total inventory value: {fmtPrice(units.filter(u => u.status === "Available").reduce((s, u) => s + u.price, 0))} available
          </span>
        </div>
      </div>
    </div>
  );
}
