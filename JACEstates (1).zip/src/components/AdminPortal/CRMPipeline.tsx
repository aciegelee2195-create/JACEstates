import { useBooking, type Deal, type DealStage } from "../../contexts/BookingContext";

const STAGES: DealStage[] = ["New Inquiry", "Tour Scheduled", "Hold Placed", "Deposit Cleared", "Under Contract", "Closed"];

const STAGE_META: Record<DealStage, { color: string; bg: string; border: string }> = {
  "New Inquiry":     { color: "#64748B", bg: "rgba(100,116,139,0.08)", border: "rgba(100,116,139,0.18)" },
  "Tour Scheduled":  { color: "#0284C7", bg: "rgba(2,132,199,0.08)",   border: "rgba(2,132,199,0.18)"   },
  "Hold Placed":     { color: "#D97706", bg: "rgba(217,119,6,0.08)",   border: "rgba(217,119,6,0.18)"   },
  "Deposit Cleared": { color: "#7C3AED", bg: "rgba(124,58,237,0.08)",  border: "rgba(124,58,237,0.18)"  },
  "Under Contract":  { color: "#059669", bg: "rgba(5,150,105,0.08)",   border: "rgba(5,150,105,0.18)"   },
  "Closed":          { color: "#0D7A52", bg: "rgba(13,122,82,0.12)",   border: "rgba(13,122,82,0.25)"   },
};

function AgentAvatar({ name }: { name: string }) {
  const initials = name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase();
  const colors = ["#059669", "#0284C7", "#7C3AED", "#D97706", "#DB2777"];
  const color = colors[name.charCodeAt(0) % colors.length];
  return (
    <div style={{ width: "20px", height: "20px", borderRadius: "50%", background: color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "9px", fontWeight: 700, color: "#fff", flexShrink: 0, fontFamily: "Plus Jakarta Sans, sans-serif" }}>
      {initials}
    </div>
  );
}

function DealCard({ deal }: { deal: Deal }) {
  const meta = STAGE_META[deal.stage];
  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", padding: "12px", boxShadow: "0 1px 3px rgba(0,0,0,0.08)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "8px" }}>
        <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "10px", color: "var(--text-muted)", background: "var(--bg-subtle)", padding: "1px 6px", borderRadius: "4px" }}>
          {deal.id}
        </span>
        <span style={{ padding: "2px 7px", borderRadius: "100px", fontSize: "10px", fontWeight: 600, background: meta.bg, color: meta.color, border: `1px solid ${meta.border}`, whiteSpace: "nowrap" }}>
          {deal.stage}
        </span>
      </div>
      <p style={{ fontSize: "13px", fontWeight: 600, color: "var(--text)", marginBottom: "2px", lineHeight: 1.3 }}>{deal.clientName}</p>
      <p style={{ fontSize: "12px", color: "var(--text-muted)", marginBottom: "8px" }}>Unit {deal.unitId}</p>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: "13px", fontWeight: 700, color: "var(--text)", fontFamily: "JetBrains Mono, monospace" }}>
          ${(deal.value / 1000).toFixed(0)}K
        </span>
        <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          <AgentAvatar name={deal.agent} />
          <span style={{ fontSize: "10px", color: "var(--text-muted)" }}>{deal.agent.split(" ")[0]}</span>
        </div>
      </div>
      <p style={{ fontSize: "10px", color: "var(--text-muted)", marginTop: "6px", fontFamily: "JetBrains Mono, monospace" }}>
        {deal.createdAt}
      </p>
    </div>
  );
}

export default function CRMPipeline() {
  const { deals } = useBooking();

  const byStage = (stage: DealStage) => deals.filter(d => d.stage === stage);

  const totalValue = deals.reduce((s, d) => s + d.value, 0);


  return (
    <div style={{ padding: "24px 28px" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "24px" }}>
        <div>
          <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "4px" }}>CRM Pipeline</h2>
          <p style={{ fontSize: "13px", color: "var(--text-muted)" }}>{deals.length} active deals · Pipeline value ${(totalValue / 1_000_000).toFixed(2)}M</p>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          <div style={{ padding: "10px 14px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", textAlign: "center" }}>
            <p style={{ fontSize: "18px", fontWeight: 700, color: "#059669", fontFamily: "JetBrains Mono, monospace" }}>{deals.filter(d => d.stage === "Closed").length}</p>
            <p style={{ fontSize: "10px", color: "var(--text-muted)", marginTop: "2px" }}>Closed Won</p>
          </div>
          <div style={{ padding: "10px 14px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", textAlign: "center" }}>
            <p style={{ fontSize: "18px", fontWeight: 700, color: "#059669", fontFamily: "JetBrains Mono, monospace" }}>${(deals.filter(d => d.stage === "Closed").reduce((s, d) => s + d.value, 0) / 1000).toFixed(0)}K</p>
            <p style={{ fontSize: "10px", color: "var(--text-muted)", marginTop: "2px" }}>Closed Value</p>
          </div>
        </div>
      </div>

      {/* Kanban Board */}
      <div style={{ display: "grid", gridTemplateColumns: `repeat(${STAGES.length}, 240px)`, gap: "12px", overflowX: "auto", paddingBottom: "8px" }}>
        {STAGES.map(stage => {
          const cards = byStage(stage);
          const meta = STAGE_META[stage];
          return (
            <div key={stage}>
              <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "10px" }}>
                <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: meta.color, flexShrink: 0 }} />
                <span style={{ fontSize: "11px", fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em" }}>{stage}</span>
                <span style={{ marginLeft: "auto", fontSize: "11px", fontWeight: 700, color: meta.color, background: meta.bg, padding: "1px 7px", borderRadius: "100px", border: `1px solid ${meta.border}` }}>{cards.length}</span>
              </div>
              <div style={{ background: "var(--bg-subtle)", borderRadius: "10px", padding: "8px", minHeight: "120px", display: "flex", flexDirection: "column", gap: "8px", border: "1px solid var(--border)" }}>
                {cards.length === 0 ? (
                  <div style={{ padding: "20px 0", textAlign: "center", color: "var(--text-muted)", fontSize: "12px", opacity: 0.6 }}>No deals</div>
                ) : (
                  cards.map(d => <DealCard key={d.id} deal={d} />)
                )}
              </div>
              <p style={{ fontSize: "11px", color: "var(--text-muted)", marginTop: "6px", textAlign: "right", fontFamily: "JetBrains Mono, monospace" }}>
                ${(cards.reduce((s, d) => s + d.value, 0) / 1000).toFixed(0)}K
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
