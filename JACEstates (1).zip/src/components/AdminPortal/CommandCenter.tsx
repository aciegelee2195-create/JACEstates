import { useState } from "react";
import { useBooking } from "../../contexts/BookingContext";
import { useReservations } from "../../contexts/ReservationContext";
import CRMPipeline from "./CRMPipeline";
import ERPInventory from "./ERPInventory";
import FinancialLedger from "./FinancialLedger";
import ReservationsAdmin from "./ReservationsAdmin";

type AdminView = "overview" | "reservations" | "crm" | "inventory" | "ledger";

const FONT_HEAD = "Plus Jakarta Sans, sans-serif";
const FONT_BODY = "Inter, sans-serif";
const FONT_MONO = "JetBrains Mono, monospace";

interface AdminUser {
  name: string;
  role: string;
  email: string;
  roleKey: "super_admin" | "broker" | "property_manager" | "finance" | "client";
  initials: string;
  color: string;
}

interface Props {
  onSwitchPortal: () => void;
  onLogout?: () => void;
  adminUser?: AdminUser | null;
  user?: AdminUser | null;
  onLogin?: (user: AdminUser) => void;
}

const ADMIN_ACCOUNTS: Array<AdminUser & { password: string }> = [
  { name: "Super Admin",      role: "Super Administrator", email: "super@jacestates.com",   roleKey: "super_admin",       initials: "SA", color: "#7C3AED", password: "admin123" },
  { name: "Alexandra Chen",   role: "Senior Broker",       email: "a.chen@jacestates.com",  roleKey: "broker",            initials: "AC", color: "#059669", password: "broker123" },
  { name: "Marcus Torres",    role: "Property Manager",    email: "m.torres@jacestates.com",roleKey: "property_manager",  initials: "MT", color: "#0284C7", password: "pm123" },
  { name: "Priya Singh",      role: "Finance Manager",     email: "p.singh@jacestates.com", roleKey: "finance",           initials: "PS", color: "#D97706", password: "finance123" },
];

function AdminLoginScreen({ onLogin, onBack }: { onLogin: (u: AdminUser) => void; onBack: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const border = "#E2E8F0";
  const green = "#059669";
  const navy = "#0F172A";
  const muted = "#64748B";
  const text = "#0F172A";
  const red = "#DC2626";

  const inp: React.CSSProperties = {
    width: "100%", padding: "11px 14px", border: `1px solid ${border}`, borderRadius: "9px",
    background: "#fff", color: text, fontSize: "14px", outline: "none",
    fontFamily: FONT_BODY, boxSizing: "border-box", transition: "border-color 0.15s",
  };
  const focus = (e: React.FocusEvent<HTMLInputElement>) => (e.target.style.borderColor = green);
  const blur  = (e: React.FocusEvent<HTMLInputElement>) => (e.target.style.borderColor = border);
  const lbl: React.CSSProperties = { display: "block", fontSize: "11px", fontWeight: 700, color: muted, letterSpacing: "0.05em", marginBottom: "5px", fontFamily: FONT_BODY };

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    setTimeout(() => {
      const found = ADMIN_ACCOUNTS.find(a => a.email.toLowerCase() === email.toLowerCase() && a.password === password);
      if (!found) { setError("Invalid credentials. Check your email and password."); setLoading(false); return; }
      const { password: _, ...u } = found;
      onLogin(u);
      setLoading(false);
    }, 500);
  }

  return (
    <div style={{ minHeight: "100vh", background: "#0F172A", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: FONT_BODY, padding: "24px", position: "relative", overflow: "hidden" }}>
      {/* Subtle background texture */}
      <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(circle at 20% 50%, rgba(5,150,105,0.08) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(124,58,237,0.06) 0%, transparent 50%)" }} />

      <div style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: "420px" }}>
        {/* Brand */}
        <div style={{ textAlign: "center", marginBottom: "36px" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
            <div style={{ width: "40px", height: "40px", borderRadius: "10px", background: green, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#fff", fontWeight: 800, fontSize: "17px", fontFamily: FONT_HEAD }}>J</span>
            </div>
            <span style={{ fontSize: "22px", fontWeight: 800, color: "#F1F5F9", fontFamily: FONT_HEAD, letterSpacing: "-0.02em" }}>JACEstates</span>
          </div>
          <p style={{ fontSize: "13px", color: "rgba(241,245,249,0.5)", fontFamily: FONT_BODY }}>Management Command Center</p>
        </div>

        {/* Card */}
        <div style={{ background: "#1E293B", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "16px", padding: "32px", boxShadow: "0 24px 64px rgba(0,0,0,0.4)" }}>
          <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#F1F5F9", fontFamily: FONT_HEAD, marginBottom: "6px" }}>Admin Sign In</h2>
          <p style={{ fontSize: "13px", color: "rgba(241,245,249,0.5)", fontFamily: FONT_BODY, marginBottom: "24px", lineHeight: 1.5 }}>
            Access restricted to authorized staff only.
          </p>

          {/* Demo hint */}
          <div style={{ padding: "10px 14px", background: "rgba(5,150,105,0.1)", border: "1px solid rgba(5,150,105,0.2)", borderRadius: "8px", marginBottom: "20px" }}>
            <p style={{ fontSize: "12px", fontWeight: 600, color: "#34D399", marginBottom: "4px", fontFamily: FONT_HEAD }}>Demo credentials</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "4px" }}>
              {[["Super Admin", "super@jacestates.com", "admin123"], ["Broker", "a.chen@jacestates.com", "broker123"]].map(([role, em, pw]) => (
                <button key={role} type="button" onClick={() => { setEmail(em); setPassword(pw); }} style={{ padding: "6px 8px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "6px", cursor: "pointer", textAlign: "left" }}>
                  <p style={{ fontSize: "10px", fontWeight: 700, color: "#34D399", fontFamily: FONT_HEAD }}>{role}</p>
                  <p style={{ fontSize: "9px", color: "rgba(255,255,255,0.4)", fontFamily: FONT_MONO }}>{em}</p>
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
            <div>
              <label style={{ ...lbl, color: "rgba(241,245,249,0.5)" }}>EMAIL ADDRESS</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="admin@jacestates.com"
                style={{ ...inp, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#F1F5F9" }}
                onFocus={e => (e.target.style.borderColor = green)} onBlur={blur} />
            </div>
            <div>
              <label style={{ ...lbl, color: "rgba(241,245,249,0.5)" }}>PASSWORD</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} required placeholder="Enter your password"
                style={{ ...inp, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#F1F5F9" }}
                onFocus={e => (e.target.style.borderColor = green)} onBlur={blur} />
            </div>

            {error && (
              <div style={{ padding: "10px 14px", background: "rgba(220,38,38,0.1)", border: "1px solid rgba(220,38,38,0.2)", borderRadius: "8px", fontSize: "13px", color: red }}>
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} style={{ padding: "12px", background: green, border: "none", borderRadius: "9px", fontSize: "14px", fontWeight: 700, color: "#fff", cursor: loading ? "not-allowed" : "pointer", fontFamily: FONT_HEAD, opacity: loading ? 0.8 : 1, transition: "all 0.15s", marginTop: "4px" }}
              onMouseEnter={e => { if (!loading) (e.currentTarget.style.background = "#047857"); }}
              onMouseLeave={e => { if (!loading) (e.currentTarget.style.background = green); }}>
              {loading ? "Signing in…" : "Sign In to Command Center →"}
            </button>
          </form>
        </div>

        <div style={{ textAlign: "center", marginTop: "20px" }}>
          <button onClick={onBack} style={{ background: "none", border: "none", fontSize: "13px", color: "rgba(241,245,249,0.35)", cursor: "pointer", fontFamily: FONT_BODY }}>
            ← Back to portal selection
          </button>
        </div>
      </div>
    </div>
  );
}

// Light-mode hardcoded tokens for admin
const A = {
  bg:     "#F8FAFC",
  card:   "#FFFFFF",
  border: "#E2E8F0",
  text:   "#0F172A",
  text2:  "#334155",
  muted:  "#64748B",
  dim:    "#94A3B8",
  sub:    "#F1F5F9",
};

const NAV_GROUPS = [
  {
    label: "MAIN",
    items: [
      { id: "overview" as AdminView,     label: "Overview",          icon: "▤" },
      { id: "reservations" as AdminView, label: "Reservations",      icon: "📋" },
    ],
  },
  {
    label: "TOOLS",
    items: [
      { id: "crm" as AdminView,          label: "CRM Pipeline",      icon: "◆" },
      { id: "inventory" as AdminView,    label: "ERP Inventory",     icon: "▣" },
      { id: "ledger" as AdminView,       label: "Financial Ledger",  icon: "◈" },
    ],
  },
];

function KPI({ label, value, sub, accent }: { label: string; value: string; sub?: string; accent?: string }) {
  return (
    <div style={{ background: A.card, border: `1px solid ${A.border}`, borderRadius: "10px", padding: "18px 20px", flex: 1, boxShadow: "0 1px 3px rgba(15,23,42,0.04)" }}>
      <p style={{ fontSize: "11px", fontWeight: 700, color: A.muted, letterSpacing: "0.06em", marginBottom: "8px" }}>{label}</p>
      <p style={{ fontSize: "26px", fontWeight: 800, color: accent ?? A.text, fontFamily: FONT_MONO, letterSpacing: "-0.02em" }}>{value}</p>
      {sub && <p style={{ fontSize: "11px", color: A.muted, marginTop: "4px" }}>{sub}</p>}
    </div>
  );
}

function Overview() {
  const { units, deals, deposits } = useBooking();
  const { reservations } = useReservations();
  const available = units.filter(u => u.status === "Available").length;
  const held = units.filter(u => u.status === "Held").length;
  const reserved = units.filter(u => u.status === "Reserved").length;
  const sold = units.filter(u => u.status === "Sold").length;
  const pipelineValue = deals.reduce((s, d) => s + d.value, 0);
  const depositValue = deposits.filter(d => d.status !== "Pending").reduce((s, d) => s + d.amount, 0);
  const pendingRes = reservations.filter(r => r.status === "Pending").length;

  return (
    <div style={{ padding: "24px 28px", display: "flex", flexDirection: "column", gap: "20px" }}>
      <div>
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: A.text, fontFamily: FONT_HEAD, marginBottom: "3px" }}>Command Overview</h2>
        <p style={{ fontSize: "13px", color: A.muted }}>Meridian Residences · {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}</p>
      </div>

      {/* KPI ribbon */}
      <div style={{ display: "flex", gap: "12px" }}>
        <KPI label="PIPELINE DEALS" value={String(deals.length)} sub={`${deals.filter(d => d.stage === "Under Contract").length} under contract`} accent="#059669" />
        <KPI label="PIPELINE VALUE" value={`$${(pipelineValue / 1_000_000).toFixed(1)}M`} sub="Total deal value" accent="#7C3AED" />
        <KPI label="DEPOSITS IN" value={`$${(depositValue / 1000).toFixed(0)}K`} sub="Cleared & escrowed" accent="#0284C7" />
        <KPI label="PENDING REVIEWS" value={String(pendingRes)} sub={`${reservations.length} total reservations`} accent="#D97706" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
        {/* Unit status */}
        <div style={{ background: A.card, border: `1px solid ${A.border}`, borderRadius: "10px", overflow: "hidden" }}>
          <div style={{ padding: "14px 20px", borderBottom: `1px solid ${A.border}` }}>
            <p style={{ fontSize: "13px", fontWeight: 700, color: A.text, fontFamily: FONT_HEAD }}>Unit Status</p>
          </div>
          <div style={{ padding: "16px 20px", display: "flex", flexDirection: "column", gap: "12px" }}>
            {[
              { label: "Available", count: available, color: "#059669" },
              { label: "On Hold",   count: held,      color: "#D97706" },
              { label: "Reserved",  count: reserved,  color: "#7C3AED" },
              { label: "Sold",      count: sold,       color: "#64748B" },
            ].map(({ label, count, color }) => (
              <div key={label}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                  <span style={{ fontSize: "12px", color: A.text2 }}>{label}</span>
                  <span style={{ fontSize: "12px", fontWeight: 700, color, fontFamily: FONT_MONO }}>{count} <span style={{ fontWeight: 400, color: A.dim }}>/ {units.length}</span></span>
                </div>
                <div style={{ height: "5px", background: A.sub, borderRadius: "100px", overflow: "hidden" }}>
                  <div style={{ height: "100%", width: `${(count / units.length) * 100}%`, background: color, borderRadius: "100px", transition: "width 0.6s" }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent CRM */}
        <div style={{ background: A.card, border: `1px solid ${A.border}`, borderRadius: "10px", overflow: "hidden" }}>
          <div style={{ padding: "14px 20px", borderBottom: `1px solid ${A.border}` }}>
            <p style={{ fontSize: "13px", fontWeight: 700, color: A.text, fontFamily: FONT_HEAD }}>Recent CRM Activity</p>
          </div>
          <div style={{ padding: "0 20px" }}>
            {deals.slice(0, 5).map((d, i) => (
              <div key={d.id} style={{ padding: "11px 0", borderBottom: i < 4 ? `1px solid ${A.border}` : "none", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <p style={{ fontSize: "13px", fontWeight: 600, color: A.text }}>{d.clientName}</p>
                  <p style={{ fontSize: "11px", color: A.muted, fontFamily: FONT_MONO }}>{d.id} · Unit {d.unitId}</p>
                </div>
                <div style={{ textAlign: "right" }}>
                  <p style={{ fontSize: "12px", fontWeight: 700, color: A.text, fontFamily: FONT_MONO }}>${(d.value / 1_000_000).toFixed(2)}M</p>
                  <p style={{ fontSize: "10px", color: A.muted }}>{d.stage}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Agent performance */}
      <div style={{ background: A.card, border: `1px solid ${A.border}`, borderRadius: "10px", overflow: "hidden" }}>
        <div style={{ padding: "14px 20px", borderBottom: `1px solid ${A.border}` }}>
          <p style={{ fontSize: "13px", fontWeight: 700, color: A.text, fontFamily: FONT_HEAD }}>Agent Performance</p>
        </div>
        <div style={{ padding: "0 20px" }}>
          {Object.entries(deals.reduce((acc, d) => { acc[d.agent] = (acc[d.agent] ?? 0) + d.value; return acc; }, {} as Record<string, number>))
            .sort((a, b) => b[1] - a[1]).map(([agent, value], i, arr) => (
              <div key={agent} style={{ padding: "11px 0", borderBottom: i < arr.length - 1 ? `1px solid ${A.border}` : "none", display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ width: "30px", height: "30px", borderRadius: "50%", background: "#0F172A", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "10px", fontWeight: 700, color: "#fff", fontFamily: FONT_HEAD, flexShrink: 0 }}>
                  {agent.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                    <span style={{ fontSize: "13px", fontWeight: 600, color: A.text }}>{agent}</span>
                    <span style={{ fontSize: "12px", fontWeight: 700, color: "#059669", fontFamily: FONT_MONO }}>${(value / 1_000_000).toFixed(2)}M</span>
                  </div>
                  <div style={{ height: "4px", background: A.sub, borderRadius: "100px", overflow: "hidden" }}>
                    <div style={{ height: "100%", width: `${(value / (arr[0][1] || 1)) * 100}%`, background: "#059669", borderRadius: "100px" }} />
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

export default function CommandCenter({ onSwitchPortal, onLogout, adminUser: propAdminUser }: Props) {
  const [localAdminUser, setLocalAdminUser] = useState<AdminUser | null>(null);
  const adminUser = propAdminUser ?? localAdminUser;
  const [view, setView] = useState<AdminView>("overview");
  const { reservations } = useReservations();
  const pendingRes = reservations.filter(r => r.status === "Pending").length;

  if (!adminUser) {
    return <AdminLoginScreen onLogin={setLocalAdminUser} onBack={onSwitchPortal} />;
  }
  function handleLogout() { if (onLogout) onLogout(); else setLocalAdminUser(null); }

  const allNav = NAV_GROUPS.flatMap(g => g.items);

  return (
    // Force light theme — no dark mode in admin
    <div data-theme="light" style={{ display: "flex", minHeight: "100vh", background: A.bg, color: A.text, fontFamily: FONT_BODY }}>
      {/* Sidebar */}
      <aside style={{ width: "224px", flexShrink: 0, background: "#0F172A", display: "flex", flexDirection: "column", position: "fixed", top: 0, left: 0, height: "100vh", zIndex: 50, borderRight: "1px solid rgba(255,255,255,0.06)" }}>
        {/* Brand */}
        <div style={{ padding: "20px 18px 16px", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
          <button onClick={onSwitchPortal} style={{ display: "flex", alignItems: "center", gap: "8px", background: "none", border: "none", cursor: "pointer", padding: 0, marginBottom: "10px" }}>
            <div style={{ width: "30px", height: "30px", borderRadius: "7px", background: "#059669", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#fff", fontWeight: 800, fontSize: "13px", fontFamily: FONT_HEAD }}>J</span>
            </div>
            <span style={{ fontSize: "15px", fontWeight: 800, color: "#F8FAFC", fontFamily: FONT_HEAD, letterSpacing: "-0.01em" }}>JACEstates</span>
          </button>
          <span style={{ display: "inline-flex", padding: "2px 8px", background: "rgba(5,150,105,0.15)", borderRadius: "100px", fontSize: "10px", fontWeight: 700, color: "#34D399", letterSpacing: "0.06em" }}>ADMIN PORTAL</span>
        </div>

        {/* Nav groups */}
        <nav style={{ flex: 1, padding: "10px 8px", display: "flex", flexDirection: "column", gap: "4px", overflowY: "auto" }}>
          {NAV_GROUPS.map(group => (
            <div key={group.label} style={{ marginBottom: "6px" }}>
              <p style={{ fontSize: "9px", fontWeight: 700, color: "rgba(255,255,255,0.28)", letterSpacing: "0.1em", padding: "4px 10px 6px", textTransform: "uppercase" }}>{group.label}</p>
              {group.items.map(n => {
                const on = view === n.id;
                const badge = n.id === "reservations" && pendingRes > 0 ? pendingRes : null;
                return (
                  <button key={n.id} onClick={() => setView(n.id)} style={{ display: "flex", alignItems: "center", gap: "9px", padding: "9px 10px", borderRadius: "8px", width: "100%", textAlign: "left", cursor: "pointer", transition: "all 0.15s", border: `1px solid ${on ? "rgba(5,150,105,0.25)" : "transparent"}`, background: on ? "rgba(5,150,105,0.15)" : "transparent", color: on ? "#34D399" : "rgba(248,250,252,0.55)", fontSize: "13px", fontWeight: on ? 600 : 400 }}>
                    <span style={{ fontSize: "13px", opacity: on ? 1 : 0.6 }}>{n.icon}</span>
                    <span style={{ flex: 1 }}>{n.label}</span>
                    {badge && <span style={{ padding: "1px 6px", borderRadius: "100px", background: "#D97706", color: "#fff", fontSize: "10px", fontWeight: 700 }}>{badge}</span>}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* User card */}
        <div style={{ padding: "14px 16px", borderTop: "1px solid rgba(255,255,255,0.07)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "9px", marginBottom: "10px" }}>
            <div style={{ width: "30px", height: "30px", borderRadius: "50%", background: adminUser.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "11px", fontWeight: 700, color: "#fff", flexShrink: 0, fontFamily: FONT_HEAD }}>
              {adminUser.initials}
            </div>
            <div>
              <p style={{ fontSize: "12px", fontWeight: 700, color: "#F8FAFC", fontFamily: FONT_HEAD }}>{adminUser.name}</p>
              <p style={{ fontSize: "10px", color: "rgba(248,250,252,0.4)", fontFamily: FONT_BODY }}>{adminUser.role}</p>
            </div>
          </div>
          <div style={{ display: "flex", gap: "5px" }}>
            <button onClick={handleLogout} style={{ flex: 1, padding: "6px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "6px", color: "rgba(248,250,252,0.5)", fontSize: "10px", cursor: "pointer", fontFamily: FONT_BODY }}
              onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = "rgba(220,38,38,0.12)")}
              onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.05)")}>
              Sign Out
            </button>
            <button onClick={onSwitchPortal} style={{ flex: 1, padding: "6px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "6px", color: "rgba(248,250,252,0.5)", fontSize: "10px", cursor: "pointer", fontFamily: FONT_BODY }}
              onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)")}
              onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.05)")}>
              ← Portals
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ marginLeft: "224px", flex: 1, background: A.bg, minHeight: "100vh", overflow: "auto" }}>
        {/* Top bar */}
        <header style={{ height: "56px", background: A.card, borderBottom: `1px solid ${A.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 28px", position: "sticky", top: 0, zIndex: 40, boxShadow: "0 1px 3px rgba(15,23,42,0.04)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <span style={{ fontSize: "15px", fontWeight: 700, color: A.text, fontFamily: FONT_HEAD }}>
              {allNav.find(n => n.id === view)?.label}
            </span>
            <span style={{ fontSize: "12px", color: A.muted }}>· Meridian Residences</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "5px", padding: "4px 10px", background: "rgba(5,150,105,0.08)", border: "1px solid rgba(5,150,105,0.18)", borderRadius: "100px" }}>
              <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#059669" }} />
              <span style={{ fontSize: "11px", fontWeight: 600, color: "#059669" }}>Live</span>
            </div>
            <span style={{ fontSize: "12px", color: A.muted }}>{new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
          </div>
        </header>

        {view === "overview"     && <Overview />}
        {view === "reservations" && <ReservationsAdmin />}
        {view === "crm"          && <CRMPipeline />}
        {view === "inventory"    && <ERPInventory />}
        {view === "ledger"       && <FinancialLedger />}
      </main>
    </div>
  );
}
