import { useState } from "react";
import { useReservations, type ReservationStatus, type Reservation } from "../../contexts/ReservationContext";
import { fmtPrice } from "../../data/buildingData";

const STATUSES: ReservationStatus[] = ["Pending", "Confirmed", "Cancelled", "Completed"];
const AGENTS = ["Alexandra Chen", "Marcus Torres", "Jordan Carter", "Priya Singh", "Lena Brauer"];

const STATUS_META: Record<ReservationStatus, { color: string; bg: string; border: string }> = {
  Pending:   { color: "#D97706", bg: "rgba(217,119,6,0.08)",   border: "rgba(217,119,6,0.2)"   },
  Confirmed: { color: "#059669", bg: "rgba(5,150,105,0.08)",   border: "rgba(5,150,105,0.2)"   },
  Cancelled: { color: "#DC2626", bg: "rgba(220,38,38,0.07)",   border: "rgba(220,38,38,0.18)"  },
  Completed: { color: "#64748B", bg: "rgba(100,116,139,0.08)", border: "rgba(100,116,139,0.18)" },
};

const TYPE_META: Record<string, { color: string; bg: string }> = {
  "Short Stay":       { color: "#059669", bg: "rgba(5,150,105,0.08)"  },
  "Long-Term Lease":  { color: "#0284C7", bg: "rgba(2,132,199,0.08)"  },
  "Purchase Inquiry": { color: "#7C3AED", bg: "rgba(124,58,237,0.08)" },
};

function fmtDt(s: string) {
  return new Date(s + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function ReservationRow({ res, onUpdate }: { res: Reservation; onUpdate: (id: string, status: ReservationStatus, agent: string) => void }) {
  const [expanded, setExpanded] = useState(false);
  const [status, setStatus] = useState<ReservationStatus>(res.status);
  const [agent, setAgent] = useState(res.agent);
  const sm = STATUS_META[status];
  const tm = TYPE_META[res.type] ?? TYPE_META["Short Stay"];

  const th: React.CSSProperties = { padding: "0", fontSize: "10px", fontWeight: 700, color: "#94A3B8", letterSpacing: "0.05em" };
  const td: React.CSSProperties = { fontSize: "12px", color: "#334155" };
  const inp: React.CSSProperties = { padding: "6px 8px", border: "1px solid #E2E8F0", borderRadius: "6px", background: "#fff", color: "#0F172A", fontSize: "12px", outline: "none", fontFamily: "Inter, sans-serif", cursor: "pointer" };

  return (
    <>
      <tr style={{ borderBottom: `1px solid #E2E8F0`, transition: "background 0.1s", cursor: "pointer" }}
        onClick={() => setExpanded(v => !v)}
        onMouseEnter={e => (e.currentTarget.style.background = "#F8FAFC")}
        onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
      >
        <td style={{ padding: "12px 14px" }}>
          <p style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "11px", color: "#64748B" }}>{res.id}</p>
        </td>
        <td style={{ padding: "12px 8px" }}>
          <p style={{ fontSize: "13px", fontWeight: 600, color: "#0F172A" }}>{res.clientName}</p>
          <p style={{ fontSize: "11px", color: "#94A3B8" }}>{res.clientEmail}</p>
        </td>
        <td style={{ padding: "12px 8px" }}>
          <p style={{ fontSize: "12px", fontWeight: 600, color: "#0F172A", fontFamily: "JetBrains Mono, monospace" }}>{res.unitId}</p>
          <p style={{ fontSize: "11px", color: "#94A3B8" }}>{res.unitType} · Floor {res.floor}</p>
        </td>
        <td style={{ padding: "12px 8px" }}>
          <span style={{ padding: "2px 8px", borderRadius: "100px", fontSize: "10px", fontWeight: 600, background: tm.bg, color: tm.color }}>{res.type}</span>
        </td>
        <td style={{ padding: "12px 8px" }}>
          <p style={{ fontSize: "12px", color: "#334155" }}>{fmtDt(res.checkIn)}</p>
          {res.nights > 0 && <p style={{ fontSize: "11px", color: "#94A3B8" }}>{res.nights} nights</p>}
        </td>
        <td style={{ padding: "12px 8px" }}>
          <p style={{ fontSize: "13px", fontWeight: 700, color: "#0F172A", fontFamily: "JetBrains Mono, monospace" }}>${res.depositAmount.toLocaleString()}</p>
          <p style={{ fontSize: "11px", color: "#94A3B8" }}>{res.paymentMethod}</p>
        </td>
        <td style={{ padding: "12px 8px" }}>
          <span style={{ padding: "3px 8px", borderRadius: "100px", fontSize: "11px", fontWeight: 700, background: sm.bg, color: sm.color, border: `1px solid ${sm.border}` }}>{status}</span>
        </td>
        <td style={{ padding: "12px 8px" }}>
          <p style={{ fontSize: "12px", color: "#334155" }}>{res.agent}</p>
        </td>
        <td style={{ padding: "12px 8px 12px 14px" }}>
          <span style={{ fontSize: "16px", color: "#94A3B8", display: "block", transition: "transform 0.2s", transform: expanded ? "rotate(180deg)" : "none", textAlign: "center" }}>⌄</span>
        </td>
      </tr>

      {/* Expanded detail row */}
      {expanded && (
        <tr>
          <td colSpan={9} style={{ padding: 0, background: "#F8FAFC", borderBottom: "1px solid #E2E8F0" }}>
            <div style={{ padding: "18px 20px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "20px" }}>
              {/* Contact + Property */}
              <div>
                <p style={{ ...th, marginBottom: "10px" }}>CLIENT & PROPERTY</p>
                <div style={{ display: "flex", gap: "10px", marginBottom: "10px" }}>
                  <img src={`https://images.unsplash.com/${res.img}?w=80&h=64&fit=crop&auto=format`} alt={res.unitId}
                    style={{ width: "64px", height: "52px", objectFit: "cover", borderRadius: "6px", flexShrink: 0 }} />
                  <div>
                    <p style={{ ...td, fontWeight: 700, color: "#0F172A" }}>{res.unitLabel}</p>
                    <p style={{ ...td }}>{res.unitType} · Floor {res.floor}</p>
                    <p style={{ ...td, color: "#059669", fontWeight: 600 }}>{fmtPrice(res.price)}</p>
                  </div>
                </div>
                <p style={{ ...td, marginBottom: "2px" }}><strong>Phone:</strong> {res.clientPhone || "—"}</p>
                {res.notes && <p style={{ fontSize: "12px", color: "#64748B", fontStyle: "italic", marginTop: "4px", lineHeight: 1.4 }}>"{res.notes}"</p>}
              </div>

              {/* Update status */}
              <div>
                <p style={{ ...th, marginBottom: "10px" }}>UPDATE STATUS</p>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  {STATUSES.map(s => {
                    const m = STATUS_META[s];
                    const on = status === s;
                    return (
                      <button key={s} type="button" onClick={e => { e.stopPropagation(); setStatus(s); }}
                        style={{ padding: "7px 12px", border: `1px solid ${on ? m.color : "#E2E8F0"}`, borderRadius: "7px", background: on ? m.bg : "#fff", fontSize: "12px", fontWeight: on ? 700 : 500, color: on ? m.color : "#64748B", cursor: "pointer", textAlign: "left", transition: "all 0.15s" }}>
                        {on ? "✓ " : ""}{s}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Assign agent + save */}
              <div>
                <p style={{ ...th, marginBottom: "10px" }}>ASSIGN AGENT</p>
                <select value={agent} onChange={e => { e.stopPropagation(); setAgent(e.target.value); }} onClick={e => e.stopPropagation()}
                  style={{ ...inp, width: "100%", marginBottom: "12px" }}>
                  {AGENTS.map(a => <option key={a}>{a}</option>)}
                </select>
                <button onClick={e => { e.stopPropagation(); onUpdate(res.id, status, agent); setExpanded(false); }}
                  style={{ width: "100%", padding: "9px", background: "#059669", border: "none", borderRadius: "8px", fontSize: "13px", fontWeight: 700, color: "#fff", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
                  Save Changes
                </button>
                <p style={{ fontSize: "11px", color: "#94A3B8", marginTop: "6px", textAlign: "center" }}>Filed {fmtDt(res.createdAt)}</p>
              </div>
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

export default function ReservationsAdmin() {
  const { reservations, updateStatus, assignAgent } = useReservations();
  const [statusFilter, setStatusFilter] = useState<ReservationStatus | "All">("All");
  const [typeFilter, setTypeFilter] = useState("All");
  const [search, setSearch] = useState("");

  const filtered = reservations.filter(r =>
    (statusFilter === "All" || r.status === statusFilter) &&
    (typeFilter === "All" || r.type === typeFilter) &&
    (search === "" || r.clientName.toLowerCase().includes(search.toLowerCase()) || r.unitId.toLowerCase().includes(search.toLowerCase()) || r.id.toLowerCase().includes(search.toLowerCase()))
  );

  const counts = {
    All: reservations.length,
    Pending: reservations.filter(r => r.status === "Pending").length,
    Confirmed: reservations.filter(r => r.status === "Confirmed").length,
    Cancelled: reservations.filter(r => r.status === "Cancelled").length,
    Completed: reservations.filter(r => r.status === "Completed").length,
  };

  const totalDeposits = reservations.filter(r => r.status !== "Cancelled").reduce((s, r) => s + r.depositAmount, 0);

  function handleUpdate(id: string, status: ReservationStatus, agent: string) {
    updateStatus(id, status);
    assignAgent(id, agent);
  }

  const th: React.CSSProperties = { padding: "10px 8px 10px 8px", textAlign: "left", fontSize: "10px", fontWeight: 700, color: "#94A3B8", letterSpacing: "0.06em", textTransform: "uppercase", borderBottom: "1px solid #E2E8F0", whiteSpace: "nowrap" };

  return (
    <div style={{ padding: "24px 28px" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "20px" }}>
        <div>
          <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#0F172A", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "3px" }}>Reservations</h2>
          <p style={{ fontSize: "13px", color: "#64748B" }}>{reservations.length} total · ${(totalDeposits / 1000).toFixed(0)}K deposits collected</p>
        </div>
        <div style={{ display: "flex", gap: "6px" }}>
          {(["All", "Pending", "Confirmed", "Cancelled", "Completed"] as const).map(s => {
            const on = statusFilter === s;
            const m = s !== "All" ? STATUS_META[s as ReservationStatus] : null;
            return (
              <button key={s} onClick={() => setStatusFilter(s)} style={{ padding: "5px 12px", border: `1px solid ${on && m ? m.color : on ? "#059669" : "#E2E8F0"}`, borderRadius: "100px", background: on && m ? m.bg : on ? "rgba(5,150,105,0.08)" : "#fff", color: on && m ? m.color : on ? "#059669" : "#64748B", fontSize: "12px", fontWeight: on ? 700 : 400, cursor: "pointer", transition: "all 0.15s" }}>
                {s} <span style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "10px" }}>({counts[s]})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Search + type filter */}
      <div style={{ display: "flex", gap: "8px", marginBottom: "16px" }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by client, unit ID, or reservation…"
          style={{ flex: 1, padding: "8px 12px", border: "1px solid #E2E8F0", borderRadius: "8px", background: "#fff", color: "#0F172A", fontSize: "13px", outline: "none", fontFamily: "Inter, sans-serif" }}
          onFocus={e => (e.target.style.borderColor = "#059669")} onBlur={e => (e.target.style.borderColor = "#E2E8F0")} />
        <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} style={{ padding: "8px 12px", border: "1px solid #E2E8F0", borderRadius: "8px", background: "#fff", color: "#334155", fontSize: "13px", outline: "none", cursor: "pointer" }}>
          {["All", "Short Stay", "Long-Term Lease", "Purchase Inquiry"].map(t => <option key={t}>{t}</option>)}
        </select>
      </div>

      {/* KPI strip */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px", marginBottom: "20px" }}>
        {[
          ["PENDING REVIEW", counts.Pending, STATUS_META.Pending.color],
          ["CONFIRMED", counts.Confirmed, STATUS_META.Confirmed.color],
          ["TOTAL DEPOSITS", `$${(totalDeposits / 1000).toFixed(0)}K`, "#059669"],
          ["TOTAL RESERVATIONS", counts.All, "#0F172A"],
        ].map(([label, value, color]) => (
          <div key={label as string} style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: "8px", padding: "12px 14px" }}>
            <p style={{ fontSize: "10px", fontWeight: 700, color: "#94A3B8", letterSpacing: "0.06em", marginBottom: "4px" }}>{label as string}</p>
            <p style={{ fontSize: "22px", fontWeight: 800, color: color as string, fontFamily: "JetBrains Mono, monospace" }}>{value as string | number}</p>
          </div>
        ))}
      </div>

      {/* Table */}
      <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: "10px", overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#F8FAFC" }}>
              <th style={{ ...th, paddingLeft: "14px" }}>Ref ID</th>
              <th style={th}>Client</th>
              <th style={th}>Unit</th>
              <th style={th}>Type</th>
              <th style={th}>Check-in</th>
              <th style={th}>Deposit</th>
              <th style={th}>Status</th>
              <th style={th}>Agent</th>
              <th style={{ ...th, paddingRight: "14px", width: "32px" }}></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(r => <ReservationRow key={r.id} res={r} onUpdate={handleUpdate} />)}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div style={{ padding: "40px", textAlign: "center" }}>
            <p style={{ fontSize: "24px", marginBottom: "8px" }}>📋</p>
            <p style={{ fontSize: "14px", fontWeight: 600, color: "#0F172A", fontFamily: "Plus Jakarta Sans, sans-serif" }}>No reservations found</p>
            <p style={{ fontSize: "12px", color: "#64748B", marginTop: "4px" }}>Adjust your search or filters.</p>
          </div>
        )}
        <div style={{ padding: "10px 14px", borderTop: "1px solid #E2E8F0", fontSize: "12px", color: "#94A3B8", display: "flex", justifyContent: "space-between" }}>
          <span>Showing {filtered.length} of {reservations.length} reservations</span>
          <span style={{ fontFamily: "JetBrains Mono, monospace" }}>Total pipeline: {fmtPrice(reservations.filter(r => r.status !== "Cancelled").reduce((s, r) => s + r.price, 0))}</span>
        </div>
      </div>
    </div>
  );
}
