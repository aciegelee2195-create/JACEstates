import { useBooking, type Deposit } from "../../contexts/BookingContext";
import { fmtPrice } from "../../data/buildingData";

const TYPE_META: Record<string, { color: string; bg: string }> = {
  "Hold Fee":        { color: "#D97706", bg: "rgba(217,119,6,0.10)"   },
  "Initial Deposit": { color: "#7C3AED", bg: "rgba(124,58,237,0.10)"  },
  "Escrow":          { color: "#059669", bg: "rgba(5,150,105,0.10)"   },
  "Monthly Rent":    { color: "#0284C7", bg: "rgba(2,132,199,0.10)"   },
};

const STATUS_META: Record<string, { label: string; color: string; bg: string }> = {
  "Pending":         { label: "Pending",          color: "#D97706", bg: "rgba(217,119,6,0.08)"    },
  "Cleared":         { label: "Cleared",           color: "#059669", bg: "rgba(5,150,105,0.08)"   },
  "Held in Escrow":  { label: "Held in Escrow",    color: "#0284C7", bg: "rgba(2,132,199,0.08)"   },
};

function KPICard({ label, value, sub, color }: { label: string; value: string; sub: string; color: string }) {
  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", padding: "18px 20px" }}>
      <p style={{ fontSize: "11px", fontWeight: 700, color: "var(--text-muted)", letterSpacing: "0.06em", marginBottom: "8px" }}>{label}</p>
      <p style={{ fontSize: "24px", fontWeight: 800, color, fontFamily: "JetBrains Mono, monospace", letterSpacing: "-0.02em", marginBottom: "4px" }}>{value}</p>
      <p style={{ fontSize: "11px", color: "var(--text-muted)" }}>{sub}</p>
    </div>
  );
}

export default function FinancialLedger() {
  const { deposits, units, deals } = useBooking();

  const totalCleared = deposits.filter(d => d.status === "Cleared").reduce((s, d) => s + d.amount, 0);
  const pendingEscrow = deposits.filter(d => d.status === "Held in Escrow").reduce((s, d) => s + d.amount, 0);
  const monthlyYield = units.filter(u => u.status === "Sold" || u.status === "Reserved").reduce((s, u) => s + u.monthlyRent, 0);
  const holdFees = deposits.filter(d => d.type === "Hold Fee").reduce((s, d) => s + d.amount, 0);

  const th: React.CSSProperties = { padding: "10px 14px", textAlign: "left", fontSize: "11px", fontWeight: 700, color: "var(--text-muted)", letterSpacing: "0.05em", textTransform: "uppercase", borderBottom: "1px solid var(--border)", whiteSpace: "nowrap" };
  const td: React.CSSProperties = { padding: "11px 14px", fontSize: "13px", color: "var(--text)", borderBottom: "1px solid var(--border)", verticalAlign: "middle" };

  return (
    <div style={{ padding: "24px 28px" }}>
      <div style={{ marginBottom: "24px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "4px" }}>Financial Ledger</h2>
        <p style={{ fontSize: "13px", color: "var(--text-muted)" }}>Real-time deposit tracking, escrow balances, and revenue summary</p>
      </div>

      {/* KPI Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", marginBottom: "28px" }}>
        <KPICard label="DEPOSITS CLEARED" value={`$${(totalCleared / 1000).toFixed(0)}K`} sub={`${deposits.filter(d => d.status === "Cleared").length} transactions`} color="#059669" />
        <KPICard label="HELD IN ESCROW" value={`$${(pendingEscrow / 1000).toFixed(0)}K`} sub={`${deposits.filter(d => d.status === "Held in Escrow").length} held`} color="#0284C7" />
        <KPICard label="MONTHLY RENTAL YIELD" value={`$${(monthlyYield / 1000).toFixed(1)}K`} sub={`${units.filter(u => u.status === "Sold" || u.status === "Reserved").length} units`} color="#7C3AED" />
        <KPICard label="HOLD FEES COLLECTED" value={`$${(holdFees / 1000).toFixed(0)}K`} sub={`${deposits.filter(d => d.type === "Hold Fee").length} hold deposits`} color="#D97706" />
      </div>

      {/* Pipeline snapshot */}
      <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", padding: "18px 20px", marginBottom: "20px" }}>
        <p style={{ fontSize: "12px", fontWeight: 700, color: "var(--text-muted)", letterSpacing: "0.05em", marginBottom: "14px" }}>PIPELINE FINANCIAL SNAPSHOT</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "10px" }}>
          {([
            ["New Inquiry", "#64748B"],
            ["Tour Scheduled", "#0284C7"],
            ["Hold Placed", "#D97706"],
            ["Deposit Cleared", "#7C3AED"],
            ["Under Contract", "#059669"],
            ["Closed", "#0D7A52"],
          ] as const).map(([stage, color]) => (
            <div key={stage} style={{ textAlign: "center", padding: "10px", background: "var(--bg-subtle)", borderRadius: "8px" }}>
              <p style={{ fontSize: "18px", fontWeight: 800, color, fontFamily: "JetBrains Mono, monospace" }}>
                {deals.filter(d => d.stage === stage).length}
              </p>
              <p style={{ fontSize: "10px", color: "var(--text-muted)", marginTop: "3px", lineHeight: 1.2 }}>{stage}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Transaction table */}
      <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden" }}>
        <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <p style={{ fontSize: "13px", fontWeight: 700, color: "var(--text)" }}>Transaction History</p>
          <span style={{ fontSize: "11px", color: "var(--text-muted)", fontFamily: "JetBrains Mono, monospace" }}>{deposits.length} records</span>
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "var(--bg-subtle)" }}>
              <th style={th}>ID</th>
              <th style={th}>Date</th>
              <th style={th}>Unit</th>
              <th style={th}>Client</th>
              <th style={th}>Type</th>
              <th style={th}>Amount</th>
              <th style={th}>Status</th>
            </tr>
          </thead>
          <tbody>
            {deposits.map((dep: Deposit) => {
              const typeMeta = TYPE_META[dep.type] ?? { color: "#64748B", bg: "rgba(100,116,139,0.1)" };
              const statusMeta = STATUS_META[dep.status] ?? { label: dep.status, color: "#64748B", bg: "rgba(100,116,139,0.08)" };
              return (
                <tr key={dep.id}
                  onMouseEnter={e => (e.currentTarget.style.background = "var(--bg-subtle)")}
                  onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
                  style={{ transition: "background 0.1s" }}
                >
                  <td style={{ ...td, fontFamily: "JetBrains Mono, monospace", fontSize: "11px" }}>{dep.id}</td>
                  <td style={{ ...td, fontSize: "12px", color: "var(--text-muted)" }}>{dep.date}</td>
                  <td style={{ ...td, fontFamily: "JetBrains Mono, monospace", fontSize: "12px" }}>{dep.unitId}</td>
                  <td style={{ ...td, fontSize: "12px" }}>{dep.clientName}</td>
                  <td style={td}>
                    <span style={{ padding: "2px 8px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, background: typeMeta.bg, color: typeMeta.color }}>{dep.type}</span>
                  </td>
                  <td style={{ ...td, fontFamily: "JetBrains Mono, monospace", fontWeight: 700, color: "#059669" }}>
                    {fmtPrice(dep.amount)}
                  </td>
                  <td style={td}>
                    <span style={{ padding: "2px 8px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, background: statusMeta.bg, color: statusMeta.color }}>
                      {statusMeta.label}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <div style={{ padding: "12px 20px", borderTop: "1px solid var(--border)", display: "flex", justifyContent: "flex-end", gap: "24px" }}>
          <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
            <span style={{ fontSize: "12px", color: "var(--text-muted)" }}>Total inflow:</span>
            <span style={{ fontSize: "13px", fontWeight: 700, color: "#059669", fontFamily: "JetBrains Mono, monospace" }}>
              {fmtPrice(deposits.filter(d => d.status !== "Pending").reduce((s, d) => s + d.amount, 0))}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
