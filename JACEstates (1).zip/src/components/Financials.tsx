import { useState } from "react";

const MONTHLY = [
  { m: "Jan", rev: 2.8, exp: 1.4, net: 1.4 },
  { m: "Feb", rev: 3.1, exp: 1.5, net: 1.6 },
  { m: "Mar", rev: 3.4, exp: 1.6, net: 1.8 },
  { m: "Apr", rev: 3.4, exp: 1.7, net: 1.7 },
  { m: "May", rev: 3.9, exp: 1.8, net: 2.1 },
  { m: "Jun", rev: 4.1, exp: 1.9, net: 2.2 },
  { m: "Jul", rev: 3.7, exp: 1.8, net: 1.9 },
  { m: "Aug", rev: 4.6, exp: 2.0, net: 2.6 },
  { m: "Sep", rev: 4.82, exp: 2.1, net: 2.72 },
];

const COMMISSIONS = [
  { agent: "Alexandra Chen", sales: "$14.2M", commission: "$426K", deals: 12, paid: true },
  { agent: "Marcus Torres", sales: "$11.8M", commission: "$354K", deals: 10, paid: true },
  { agent: "Priya Singh", sales: "$9.4M", commission: "$282K", deals: 9, paid: false },
  { agent: "Derek Okafor", sales: "$7.6M", commission: "$228K", deals: 7, paid: false },
  { agent: "Lena Brauer", sales: "$5.9M", commission: "$177K", deals: 6, paid: true },
];

const EXPENSES = [
  { cat: "Staff & Commissions", amt: "$1,467K", pct: 70, color: "#059669" },
  { cat: "Marketing", amt: "$252K", pct: 12, color: "#2563EB" },
  { cat: "Office & Ops", amt: "$168K", pct: 8, color: "#7C3AED" },
  { cat: "Technology", amt: "$105K", pct: 5, color: "#D97706" },
  { cat: "Legal", amt: "$84K", pct: 4, color: "#DC2626" },
  { cat: "Misc", amt: "$21K", pct: 1, color: "#94A3B8" },
];

export default function Financials() {
  const [tab, setTab] = useState<"overview" | "commissions" | "expenses">("overview");
  const ytdRev = MONTHLY.reduce((s, m) => s + m.rev, 0);
  const ytdNet = MONTHLY.reduce((s, m) => s + m.net, 0);
  const margin = ((ytdNet / ytdRev) * 100).toFixed(1);
  const maxRev = Math.max(...MONTHLY.map(m => m.rev));

  return (
    <div style={{ padding: "24px", display: "flex", flexDirection: "column", gap: "16px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: "20px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", color: "var(--text)", letterSpacing: "-0.02em" }}>Financials</h1>
          <p style={{ fontSize: "13px", color: "var(--text-muted)", marginTop: "2px" }}>ERP · Fiscal Year 2026 · Q1–Q3</p>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          <button style={{ padding: "7px 14px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", fontSize: "13px", color: "var(--text-2)", cursor: "pointer" }}>Export PDF</button>
          <button style={{ padding: "7px 14px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", fontSize: "13px", color: "var(--text-2)", cursor: "pointer" }}>Export CSV</button>
        </div>
      </div>

      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px" }}>
        {[
          { l: "YTD Revenue", v: `$${ytdRev.toFixed(2)}M`, delta: "+18.4% YoY", up: true },
          { l: "YTD Net Income", v: `$${ytdNet.toFixed(2)}M`, delta: "+21.2% YoY", up: true },
          { l: "Net Margin", v: `${margin}%`, delta: "+1.8pp YoY", up: true },
          { l: "Total Commissions", v: "$1.47M", delta: "5 agents", up: true },
        ].map(k => (
          <div key={k.l} style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", padding: "14px 16px" }}>
            <div style={{ fontSize: "12px", color: "var(--text-muted)", marginBottom: "6px" }}>{k.l}</div>
            <div style={{ fontSize: "22px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{k.v}</div>
            <div style={{ fontSize: "12px", color: "#059669", marginTop: "4px", fontWeight: 500 }}>▲ {k.delta}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid var(--border)", gap: "0" }}>
        {(["overview", "commissions", "expenses"] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            padding: "10px 18px", background: "none", border: "none", cursor: "pointer",
            fontSize: "13px", fontWeight: 600, textTransform: "capitalize",
            color: tab === t ? "#059669" : "var(--text-muted)",
            borderBottom: tab === t ? "2px solid #059669" : "2px solid transparent",
            marginBottom: "-1px", fontFamily: "Plus Jakarta Sans, sans-serif",
          }}>{t}</button>
        ))}
      </div>

      {tab === "overview" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
          {/* Chart */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", padding: "20px" }}>
            <h3 style={{ fontSize: "14px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "4px" }}>Revenue vs. Net Income</h3>
            <p style={{ fontSize: "12px", color: "var(--text-muted)", marginBottom: "16px" }}>Jan–Sep 2026 · in $M</p>
            <div style={{ display: "flex", gap: "16px", marginBottom: "8px", fontSize: "12px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "5px" }}><div style={{ width: "10px", height: "10px", borderRadius: "2px", background: "#059669" }} /><span style={{ color: "var(--text-muted)" }}>Revenue</span></div>
              <div style={{ display: "flex", alignItems: "center", gap: "5px" }}><div style={{ width: "10px", height: "10px", borderRadius: "2px", background: "#2563EB" }} /><span style={{ color: "var(--text-muted)" }}>Net Income</span></div>
            </div>
            <div style={{ display: "flex", alignItems: "flex-end", gap: "12px", height: "120px" }}>
              {MONTHLY.map(m => (
                <div key={m.m} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
                  <div style={{ display: "flex", gap: "2px", alignItems: "flex-end", height: "100px" }}>
                    <div style={{ width: "12px", borderRadius: "3px 3px 0 0", background: "#059669", height: `${(m.rev / maxRev) * 100}%`, minHeight: "2px", transition: "height 0.4s" }} />
                    <div style={{ width: "12px", borderRadius: "3px 3px 0 0", background: "#2563EB", height: `${(m.net / maxRev) * 100}%`, minHeight: "2px", transition: "height 0.4s" }} />
                  </div>
                  <span style={{ fontSize: "10px", color: "var(--text-dim)" }}>{m.m}</span>
                </div>
              ))}
            </div>
          </div>
          {/* Table */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--border)" }}>
                  {["Month", "Revenue", "Expenses", "Net Income", "Margin"].map(h => (
                    <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: "10px", fontWeight: 700, color: "var(--text-dim)", letterSpacing: "0.06em" }}>{h.toUpperCase()}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {MONTHLY.map((m, i) => (
                  <tr key={m.m} style={{ borderBottom: i < MONTHLY.length - 1 ? "1px solid var(--border)" : "none" }}>
                    <td style={{ padding: "10px 14px", fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{m.m} 2026</td>
                    <td style={{ padding: "10px 14px", fontSize: "12.5px", fontWeight: 600, color: "#059669", fontFamily: "JetBrains Mono, monospace" }}>${m.rev.toFixed(2)}M</td>
                    <td style={{ padding: "10px 14px", fontSize: "12.5px", color: "#DC2626", fontFamily: "JetBrains Mono, monospace" }}>${m.exp.toFixed(2)}M</td>
                    <td style={{ padding: "10px 14px", fontSize: "12.5px", fontWeight: 600, color: "#2563EB", fontFamily: "JetBrains Mono, monospace" }}>${m.net.toFixed(2)}M</td>
                    <td style={{ padding: "10px 14px", fontSize: "12.5px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{((m.net / m.rev) * 100).toFixed(1)}%</td>
                  </tr>
                ))}
                <tr style={{ borderTop: "2px solid var(--border-strong)", background: "var(--bg-subtle)" }}>
                  <td style={{ padding: "10px 14px", fontSize: "13px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>YTD Total</td>
                  <td style={{ padding: "10px 14px", fontSize: "12.5px", fontWeight: 700, color: "#059669", fontFamily: "JetBrains Mono, monospace" }}>${ytdRev.toFixed(2)}M</td>
                  <td style={{ padding: "10px 14px", fontSize: "12.5px", fontWeight: 700, color: "#DC2626", fontFamily: "JetBrains Mono, monospace" }}>${(ytdRev - ytdNet).toFixed(2)}M</td>
                  <td style={{ padding: "10px 14px", fontSize: "12.5px", fontWeight: 700, color: "#2563EB", fontFamily: "JetBrains Mono, monospace" }}>${ytdNet.toFixed(2)}M</td>
                  <td style={{ padding: "10px 14px", fontSize: "12.5px", fontWeight: 700, color: "var(--text)", fontFamily: "JetBrains Mono, monospace" }}>{margin}%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "commissions" && (
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ borderBottom: "1px solid var(--border)" }}>
                {["Agent", "Total Sales", "Commission", "Deals", "Status"].map(h => (
                  <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontSize: "10px", fontWeight: 700, color: "var(--text-dim)", letterSpacing: "0.06em" }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {COMMISSIONS.map((c, i) => (
                <tr key={c.agent} style={{ borderBottom: i < COMMISSIONS.length - 1 ? "1px solid var(--border)" : "none" }}>
                  <td style={{ padding: "12px 16px", fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{c.agent}</td>
                  <td style={{ padding: "12px 16px", fontSize: "12.5px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{c.sales}</td>
                  <td style={{ padding: "12px 16px", fontSize: "13px", fontWeight: 700, color: "#059669", fontFamily: "JetBrains Mono, monospace" }}>{c.commission}</td>
                  <td style={{ padding: "12px 16px", fontSize: "12.5px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{c.deals}</td>
                  <td style={{ padding: "12px 16px" }}>
                    <span style={{ padding: "3px 8px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, background: c.paid ? "rgba(5,150,105,0.1)" : "rgba(217,119,6,0.1)", color: c.paid ? "#059669" : "#D97706" }}>{c.paid ? "Paid" : "Pending"}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "expenses" && (
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", padding: "20px" }}>
          <h3 style={{ fontSize: "14px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "16px" }}>Expense Breakdown · Sep 2026 · Total $2.10M</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
            {EXPENSES.map(e => (
              <div key={e.cat}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "5px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <div style={{ width: "8px", height: "8px", borderRadius: "2px", background: e.color }} />
                    <span style={{ fontSize: "13px", color: "var(--text-2)" }}>{e.cat}</span>
                  </div>
                  <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
                    <span style={{ fontSize: "12px", color: "var(--text-muted)" }}>{e.pct}%</span>
                    <span style={{ fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "JetBrains Mono, monospace", minWidth: "64px", textAlign: "right" }}>{e.amt}</span>
                  </div>
                </div>
                <div style={{ height: "5px", background: "var(--bg-subtle)", borderRadius: "3px" }}>
                  <div style={{ height: "100%", width: `${e.pct}%`, background: e.color, borderRadius: "3px", transition: "width 0.5s" }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
