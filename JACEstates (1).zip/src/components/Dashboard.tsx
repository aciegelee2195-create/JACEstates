import { useState } from "react";

/* ── KPI data ── */
const KPI = [
  {
    label: "Total Portfolio Value",
    value: "$248.5M",
    delta: "+12.4%",
    deltaDir: "up",
    sub: "vs $220.9M prior year",
    color: "#059669",
    dimColor: "rgba(5,150,105,0.1)",
    icon: "🏢",
  },
  {
    label: "Occupancy Rate",
    value: "94.2%",
    delta: "+1.8pp",
    deltaDir: "up",
    sub: "847 / 899 units occupied",
    color: "#2563EB",
    dimColor: "rgba(37,99,235,0.1)",
    icon: "📊",
    progress: 94.2,
  },
  {
    label: "Active CRM Pipeline",
    value: "$14.2M",
    delta: "38 deals",
    deltaDir: "neutral",
    sub: "Across all sales stages",
    color: "#7C3AED",
    dimColor: "rgba(124,58,237,0.1)",
    icon: "🤝",
  },
  {
    label: "Monthly NOI",
    value: "$1.85M",
    delta: "+6.3%",
    deltaDir: "up",
    sub: "Net Operating Income",
    color: "#D97706",
    dimColor: "rgba(217,119,6,0.1)",
    icon: "💰",
  },
];

/* ── 12-month chart data ── */
const CHART_DATA = [
  { m: "Oct", rev: 3.2, maint: 0.48 },
  { m: "Nov", rev: 3.5, maint: 0.52 },
  { m: "Dec", rev: 3.8, maint: 0.62 },
  { m: "Jan", rev: 2.9, maint: 0.44 },
  { m: "Feb", rev: 3.1, maint: 0.46 },
  { m: "Mar", rev: 3.4, maint: 0.55 },
  { m: "Apr", rev: 3.6, maint: 0.50 },
  { m: "May", rev: 3.9, maint: 0.58 },
  { m: "Jun", rev: 4.1, maint: 0.61 },
  { m: "Jul", rev: 3.7, maint: 0.49 },
  { m: "Aug", rev: 4.6, maint: 0.70 },
  { m: "Sep", rev: 4.82, maint: 0.65 },
];

/* ── Properties at a glance ── */
const PROPS_TABLE = [
  { id: "P-1001", name: "8 Harbor Point Terrace", location: "Miami, FL", units: 1, occupied: 1, yield: "$18.4K/mo", status: "Occupied" },
  { id: "P-1002", name: "301 Meridian Tower", location: "New York, NY", units: 48, occupied: 44, yield: "$124K/mo", status: "Occupied" },
  { id: "P-1003", name: "Westbrook Estate", location: "Beverly Hills, CA", units: 1, occupied: 0, yield: "—", status: "Vacant" },
  { id: "P-1004", name: "Parkside Office Complex", location: "Dallas, TX", units: 22, occupied: 22, yield: "$87K/mo", status: "Occupied" },
  { id: "P-1005", name: "47 Crestwood Blvd", location: "Seattle, WA", units: 1, occupied: 0, yield: "—", status: "Under Maintenance" },
  { id: "P-1006", name: "Sunset Lofts Block C", location: "Denver, CO", units: 24, occupied: 21, yield: "$42K/mo", status: "Occupied" },
];

/* ── CRM Activity Feed ── */
const ACTIVITY = [
  { type: "TOUR", label: "Site Visit Scheduled", detail: "Sophia Reeves · 8 Harbor Point Terrace", time: "Today 2:30 PM", color: "#059669" },
  { type: "LEASE", label: "Lease Signed", detail: "Marcus Elliott · Meridian Tower Unit 14C", time: "Today 11:04 AM", color: "#2563EB" },
  { type: "TICKET", label: "Maintenance Ticket", detail: "#441 — HVAC failure · 47 Crestwood Blvd", time: "Yesterday 4:20 PM", color: "#D97706" },
  { type: "OFFER", label: "Offer Submitted", detail: "Nguyen Trust · Westbrook Estate · $6.8M", time: "Yesterday 1:15 PM", color: "#7C3AED" },
  { type: "TOUR", label: "Site Visit Completed", detail: "Robert & Lisa Kim · Meridian Tower #42B", time: "Sep 2, 3:00 PM", color: "#059669" },
];

/* ── Financial Action Items ── */
const ACTIONS = [
  { label: "Q3 Rent Roll Review", due: "Due Sep 8", priority: "high" },
  { label: "Renew Lease: Unit 7B — Sunset Lofts", due: "Expires Oct 1", priority: "high" },
  { label: "Approve maintenance invoice #2281", due: "$4,200 pending", priority: "medium" },
  { label: "Commission payout — A. Chen & M. Torres", due: "Sep 15", priority: "medium" },
];

const STATUS_PILL: Record<string, { bg: string; color: string }> = {
  "Occupied": { bg: "rgba(5,150,105,0.1)", color: "#059669" },
  "Vacant": { bg: "rgba(217,119,6,0.1)", color: "#D97706" },
  "Under Maintenance": { bg: "rgba(220,38,38,0.1)", color: "#DC2626" },
};

export default function Dashboard() {
  const [hoveredBar, setHoveredBar] = useState<number | null>(null);

  const maxRev = Math.max(...CHART_DATA.map(d => d.rev));
  const chartH = 120;

  /* SVG multi-axis chart */
  const barW = 18;
  const gap = 16;
  const chartW = CHART_DATA.length * (barW + gap) - gap;

  return (
    <div style={{ padding: "24px", display: "flex", flexDirection: "column", gap: "20px" }}>

      {/* Page header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: "20px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", color: "var(--text)", letterSpacing: "-0.02em" }}>Executive Overview</h1>
          <p style={{ fontSize: "13px", color: "var(--text-muted)", marginTop: "2px" }}>September 2026 · Q3 · All Properties</p>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          <button style={{ padding: "7px 14px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", fontSize: "13px", color: "var(--text-2)", cursor: "pointer", fontWeight: 500 }}>Export PDF</button>
          <button style={{ padding: "7px 14px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px", fontSize: "13px", color: "var(--text-2)", cursor: "pointer", fontWeight: 500 }}>Share Report</button>
        </div>
      </div>

      {/* ── KPI Ribbon ── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px" }}>
        {KPI.map(k => (
          <div key={k.label} style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", padding: "16px 18px", boxShadow: "var(--shadow)" }}>
            <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "10px" }}>
              <span style={{ fontSize: "12px", color: "var(--text-muted)", fontWeight: 500, lineHeight: 1.4, maxWidth: "120px" }}>{k.label}</span>
              <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: k.dimColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", flexShrink: 0 }}>{k.icon}</div>
            </div>
            <div style={{ fontSize: "24px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", color: "var(--text)", letterSpacing: "-0.02em", marginBottom: "6px" }}>{k.value}</div>
            {k.progress != null && (
              <div style={{ height: "3px", background: "var(--bg-subtle)", borderRadius: "2px", margin: "8px 0" }}>
                <div style={{ height: "100%", width: `${k.progress}%`, background: k.color, borderRadius: "2px" }} />
              </div>
            )}
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <span style={{ fontSize: "12px", fontWeight: 600, color: k.deltaDir === "up" ? "#059669" : k.deltaDir === "down" ? "#DC2626" : "var(--text-muted)", background: k.deltaDir === "up" ? "rgba(5,150,105,0.08)" : k.deltaDir === "down" ? "rgba(220,38,38,0.08)" : "var(--bg-subtle)", padding: "2px 6px", borderRadius: "4px" }}>
                {k.deltaDir === "up" ? "▲ " : k.deltaDir === "down" ? "▼ " : ""}{k.delta}
              </span>
              <span style={{ fontSize: "11px", color: "var(--text-dim)" }}>{k.sub}</span>
            </div>
          </div>
        ))}
      </div>

      {/* ── Main 2-column layout ── */}
      <div style={{ display: "grid", gridTemplateColumns: "65% 35%", gap: "16px", alignItems: "start" }}>

        {/* Left column */}
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>

          {/* Multi-axis SVG chart */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", padding: "20px", boxShadow: "var(--shadow)" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "18px" }}>
              <div>
                <h3 style={{ fontSize: "14px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>Revenue vs. Maintenance Overhead</h3>
                <p style={{ fontSize: "12px", color: "var(--text-muted)", marginTop: "2px" }}>12-month trend · Oct 2025 – Sep 2026</p>
              </div>
              <div style={{ display: "flex", gap: "16px", fontSize: "12px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "5px" }}><div style={{ width: "10px", height: "10px", borderRadius: "2px", background: "#059669" }} /><span style={{ color: "var(--text-muted)" }}>Revenue ($M)</span></div>
                <div style={{ display: "flex", alignItems: "center", gap: "5px" }}><div style={{ width: "10px", height: "2px", background: "#D97706" }} /><span style={{ color: "var(--text-muted)" }}>Maintenance ($M)</span></div>
              </div>
            </div>
            {/* SVG Chart */}
            <div style={{ overflowX: "auto" }}>
              <svg width={Math.max(chartW + 40, 580)} height={chartH + 36} style={{ display: "block" }}>
                {/* Y-axis grid lines */}
                {[0, 25, 50, 75, 100].map(pct => (
                  <line key={pct} x1="0" y1={chartH - (pct / 100) * chartH} x2={chartW + 20} y2={chartH - (pct / 100) * chartH}
                    stroke="var(--border)" strokeWidth="1" strokeDasharray="3,3" />
                ))}
                {/* Bars + line dots */}
                {CHART_DATA.map((d, i) => {
                  const x = i * (barW + gap);
                  const barH = (d.rev / maxRev) * chartH;
                  const lineY = chartH - (d.maint / (maxRev * 0.2)) * chartH * 0.3;
                  const isHover = hoveredBar === i;
                  return (
                    <g key={d.m}
                      onMouseEnter={() => setHoveredBar(i)}
                      onMouseLeave={() => setHoveredBar(null)}
                      style={{ cursor: "pointer" }}
                    >
                      {/* Bar */}
                      <rect x={x} y={chartH - barH} width={barW} height={barH}
                        fill={isHover ? "#047857" : "#059669"} rx="3" opacity={isHover ? 1 : 0.85}
                        style={{ transition: "all 0.15s" }}
                      />
                      {/* Hover tooltip */}
                      {isHover && (
                        <>
                          <rect x={x - 10} y={chartH - barH - 30} width="56" height="22" fill="var(--bg-card)" rx="4" style={{ filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.15))" }} />
                          <text x={x + barW / 2} y={chartH - barH - 15} textAnchor="middle" fontSize="10" fill="var(--text)" fontFamily="JetBrains Mono, monospace" fontWeight="600">${d.rev}M</text>
                        </>
                      )}
                      {/* Month label */}
                      <text x={x + barW / 2} y={chartH + 16} textAnchor="middle" fontSize="10" fill="var(--text-dim)" fontFamily="Inter, sans-serif">{d.m}</text>
                    </g>
                  );
                })}
                {/* Maintenance line */}
                <polyline
                  points={CHART_DATA.map((d, i) => {
                    const x = i * (barW + gap) + barW / 2;
                    const y = chartH - (d.maint / (maxRev * 0.2)) * chartH * 0.3;
                    return `${x},${y}`;
                  }).join(" ")}
                  fill="none" stroke="#D97706" strokeWidth="2" strokeLinejoin="round"
                />
                {CHART_DATA.map((d, i) => (
                  <circle key={`dot-${i}`} cx={i * (barW + gap) + barW / 2} cy={chartH - (d.maint / (maxRev * 0.2)) * chartH * 0.3}
                    r="3" fill="#D97706" stroke="var(--bg-card)" strokeWidth="1.5" />
                ))}
              </svg>
            </div>
          </div>

          {/* Properties at a glance */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden", boxShadow: "var(--shadow)" }}>
            <div style={{ padding: "16px 20px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid var(--border)" }}>
              <h3 style={{ fontSize: "14px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>Properties at a Glance</h3>
              <button style={{ fontSize: "12px", color: "#059669", background: "none", border: "none", cursor: "pointer", fontWeight: 500 }}>View all →</button>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--border)" }}>
                  {["Property", "Location", "Units", "Occ. Rate", "Monthly Yield", "Status"].map(h => (
                    <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontSize: "10px", fontWeight: 700, color: "var(--text-dim)", letterSpacing: "0.06em", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{h.toUpperCase()}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {PROPS_TABLE.map((p, i) => {
                  const occPct = p.units > 0 ? Math.round((p.occupied / p.units) * 100) : 0;
                  return (
                    <tr key={p.id} style={{ borderBottom: i < PROPS_TABLE.length - 1 ? "1px solid var(--border)" : "none", transition: "background 0.12s", cursor: "pointer" }}
                      onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = "var(--bg-hover)")}
                      onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = "transparent")}
                    >
                      <td style={{ padding: "11px 16px" }}>
                        <div style={{ fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{p.name}</div>
                        <div style={{ fontSize: "11px", color: "var(--text-dim)", marginTop: "1px", fontFamily: "JetBrains Mono, monospace" }}>{p.id}</div>
                      </td>
                      <td style={{ padding: "11px 16px", fontSize: "12.5px", color: "var(--text-muted)" }}>{p.location}</td>
                      <td style={{ padding: "11px 16px", fontSize: "12.5px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{p.occupied}/{p.units}</td>
                      <td style={{ padding: "11px 16px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          <div style={{ width: "48px", height: "4px", background: "var(--bg-subtle)", borderRadius: "2px" }}>
                            <div style={{ height: "100%", width: `${occPct}%`, background: occPct >= 90 ? "#059669" : occPct >= 70 ? "#D97706" : "#DC2626", borderRadius: "2px" }} />
                          </div>
                          <span style={{ fontSize: "12px", color: "var(--text-2)", fontFamily: "JetBrains Mono, monospace" }}>{p.units > 0 ? `${occPct}%` : "—"}</span>
                        </div>
                      </td>
                      <td style={{ padding: "11px 16px", fontSize: "12.5px", fontWeight: 600, color: "var(--text)", fontFamily: "JetBrains Mono, monospace" }}>{p.yield}</td>
                      <td style={{ padding: "11px 16px" }}>
                        <span style={{ ...STATUS_PILL[p.status], padding: "3px 8px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{p.status}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right column */}
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>

          {/* CRM Activity Feed */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden", boxShadow: "var(--shadow)" }}>
            <div style={{ padding: "16px 20px 12px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3 style={{ fontSize: "14px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>Recent CRM Activity</h3>
              <span style={{ fontSize: "10px", fontWeight: 600, padding: "3px 7px", background: "rgba(37,99,235,0.1)", color: "#2563EB", borderRadius: "100px" }}>LIVE</span>
            </div>
            <div style={{ padding: "4px 0" }}>
              {ACTIVITY.map((a, i) => (
                <div key={i} style={{ display: "flex", gap: "12px", padding: "12px 20px", borderBottom: i < ACTIVITY.length - 1 ? "1px solid var(--border)" : "none", cursor: "pointer", transition: "background 0.12s" }}
                  onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = "var(--bg-hover)")}
                  onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = "transparent")}
                >
                  <div style={{ width: "28px", height: "28px", borderRadius: "7px", background: `${a.color}15`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <span style={{ fontSize: "10px", fontWeight: 700, color: a.color, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{a.type}</span>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: "12.5px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{a.label}</div>
                    <div style={{ fontSize: "12px", color: "var(--text-muted)", marginTop: "2px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{a.detail}</div>
                    <div style={{ fontSize: "11px", color: "var(--text-dim)", marginTop: "3px" }}>{a.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Financial Action Items */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden", boxShadow: "var(--shadow)" }}>
            <div style={{ padding: "16px 20px 12px", borderBottom: "1px solid var(--border)" }}>
              <h3 style={{ fontSize: "14px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>Financial Action Items</h3>
            </div>
            <div style={{ padding: "8px 0" }}>
              {ACTIONS.map((a, i) => (
                <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: "12px", padding: "11px 20px", borderBottom: i < ACTIONS.length - 1 ? "1px solid var(--border)" : "none" }}>
                  <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: a.priority === "high" ? "#DC2626" : "#D97706", marginTop: "5px", flexShrink: 0 }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "13px", color: "var(--text-2)", fontWeight: 500 }}>{a.label}</div>
                    <div style={{ fontSize: "11px", color: a.priority === "high" ? "#DC2626" : "#D97706", marginTop: "2px", fontWeight: 600 }}>{a.due}</div>
                  </div>
                  <button style={{ padding: "4px 10px", background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: "6px", fontSize: "11px", color: "var(--text-muted)", cursor: "pointer", flexShrink: 0 }}>Resolve</button>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
