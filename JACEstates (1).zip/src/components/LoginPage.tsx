import { useState } from "react";
import type { AppUser } from "../App";

const ROLES: { key: AppUser["roleKey"]; label: string; badge: string; color: string; email: string; password: string; name: string }[] = [
  { key: "super_admin", label: "Super Admin", badge: "SA", color: "#7C3AED", email: "admin@acme.jacestates.com", password: "admin123", name: "James A. Carter" },
  { key: "broker", label: "Sales Broker", badge: "BR", color: "#059669", email: "broker@acme.jacestates.com", password: "broker123", name: "Alexandra Chen" },
  { key: "property_manager", label: "Property Manager", badge: "PM", color: "#2563EB", email: "pm@acme.jacestates.com", password: "pm1234", name: "Marcus Williams" },
  { key: "finance", label: "Finance Analyst", badge: "FA", color: "#D97706", email: "finance@acme.jacestates.com", password: "fin123", name: "Priya Singh" },
];

interface Props { onLogin: (user: AppUser) => void; }

export default function LoginPage({ onLogin }: Props) {
  const [workspace, setWorkspace] = useState("acme");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeRole, setActiveRole] = useState<AppUser["roleKey"] | null>(null);

  function fillRole(r: typeof ROLES[0]) {
    setActiveRole(r.key);
    setEmail(r.email);
    setPassword(r.password);
    setError("");
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    setTimeout(() => {
      const match = ROLES.find(r => r.email === email && r.password === password);
      if (match) {
        onLogin({ name: match.name, role: match.label, email: match.email, roleKey: match.key });
      } else {
        setError("Invalid credentials. Check your email and password.");
        setLoading(false);
      }
    }, 700);
  }

  const inp: React.CSSProperties = {
    width: "100%", padding: "9px 12px", border: "1px solid #E2E8F0", borderRadius: "8px",
    background: "#fff", color: "#0F172A", fontSize: "14px", outline: "none",
    fontFamily: "Inter, sans-serif", transition: "border-color 0.15s",
  };

  return (
    <div style={{ display: "flex", height: "100vh", background: "#0F172A" }}>
      {/* ── Left hero panel ── */}
      <div style={{ flex: 1, position: "relative", overflow: "hidden", display: "none" }} className="login-hero">
        <img
          src="https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1200&h=1400&fit=crop&auto=format"
          alt="Modern architectural building facade"
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.35 }}
        />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(160deg, rgba(15,23,42,0.6) 0%, rgba(15,23,42,0.92) 100%)" }} />
        <div style={{ position: "relative", zIndex: 1, height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "40px 48px" }}>
          {/* Logo */}
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: "#059669", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#fff", fontWeight: 800, fontSize: "16px", fontFamily: "Plus Jakarta Sans, sans-serif" }}>J</span>
            </div>
            <span style={{ color: "#F1F5F9", fontSize: "18px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", letterSpacing: "-0.02em" }}>
              JACEstates
            </span>
          </div>
          {/* Value prop */}
          <div>
            <div style={{ display: "inline-flex", alignItems: "center", gap: "6px", background: "rgba(5,150,105,0.15)", border: "1px solid rgba(5,150,105,0.3)", borderRadius: "100px", padding: "4px 12px", marginBottom: "20px" }}>
              <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#059669", display: "block" }} />
              <span style={{ color: "#34D399", fontSize: "12px", fontWeight: 600, fontFamily: "Plus Jakarta Sans, sans-serif" }}>Enterprise Real Estate Platform</span>
            </div>
            <h1 style={{ color: "#F1F5F9", fontSize: "36px", fontWeight: 800, fontFamily: "Plus Jakarta Sans, sans-serif", lineHeight: 1.15, letterSpacing: "-0.03em", marginBottom: "16px" }}>
              Unify your property<br />portfolio in one<br /><span style={{ color: "#34D399" }}>intelligent platform</span>
            </h1>
            <p style={{ color: "#94A3B8", fontSize: "15px", lineHeight: 1.6, maxWidth: "380px" }}>
              ERP + CRM designed for brokers, property managers, and finance teams — from portfolio tracking to closing deals.
            </p>
            {/* Stats row */}
            <div style={{ display: "flex", gap: "32px", marginTop: "36px" }}>
              {[{ v: "$248.5M", l: "Portfolio Value" }, { v: "94.2%", l: "Occupancy Rate" }, { v: "38 Deals", l: "Active Pipeline" }].map(s => (
                <div key={s.l}>
                  <div style={{ color: "#F1F5F9", fontSize: "22px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{s.v}</div>
                  <div style={{ color: "#475569", fontSize: "12px", marginTop: "2px" }}>{s.l}</div>
                </div>
              ))}
            </div>
          </div>
          <p style={{ color: "#334155", fontSize: "12px" }}>© 2026 JACEstates Inc. All rights reserved.</p>
        </div>
      </div>

      {/* ── Right sign-in panel ── */}
      <div style={{ width: "100%", maxWidth: "520px", background: "#fff", display: "flex", flexDirection: "column", justifyContent: "center", padding: "48px 56px", overflowY: "auto" }}>
        {/* Mobile logo */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "36px" }}>
          <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#059669", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ color: "#fff", fontWeight: 800, fontSize: "14px", fontFamily: "Plus Jakarta Sans, sans-serif" }}>J</span>
          </div>
          <span style={{ color: "#0F172A", fontSize: "17px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", letterSpacing: "-0.02em" }}>JACEstates</span>
        </div>

        <h2 style={{ color: "#0F172A", fontSize: "24px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", letterSpacing: "-0.02em", marginBottom: "4px" }}>
          Sign in to your workspace
        </h2>
        <p style={{ color: "#64748B", fontSize: "14px", marginBottom: "28px" }}>
          Enter your credentials or select a demo role below.
        </p>

        {/* Workspace selector */}
        <div style={{ marginBottom: "20px" }}>
          <label style={{ display: "block", fontSize: "12px", fontWeight: 600, color: "#374151", marginBottom: "6px", fontFamily: "Plus Jakarta Sans, sans-serif", letterSpacing: "0.01em" }}>WORKSPACE</label>
          <div style={{ display: "flex", alignItems: "center", border: "1px solid #E2E8F0", borderRadius: "8px", overflow: "hidden", background: "#F8FAFC" }}>
            <div style={{ padding: "9px 12px", background: "#F1F5F9", borderRight: "1px solid #E2E8F0", fontSize: "13px", color: "#64748B", whiteSpace: "nowrap" }}>
              🏢
            </div>
            <input
              value={workspace}
              onChange={e => setWorkspace(e.target.value)}
              style={{ flex: 1, padding: "9px 10px", border: "none", background: "transparent", fontSize: "14px", color: "#0F172A", outline: "none" }}
              placeholder="workspace-name"
            />
            <div style={{ padding: "9px 12px", borderLeft: "1px solid #E2E8F0", fontSize: "13px", color: "#94A3B8", whiteSpace: "nowrap" }}>
              .jacestates.com
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
          <div>
            <label style={{ display: "block", fontSize: "12px", fontWeight: 600, color: "#374151", marginBottom: "6px", fontFamily: "Plus Jakarta Sans, sans-serif" }}>EMAIL ADDRESS</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="you@company.com" style={inp}
              onFocus={e => (e.target.style.borderColor = "#059669")}
              onBlur={e => (e.target.style.borderColor = "#E2E8F0")}
            />
          </div>
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
              <label style={{ fontSize: "12px", fontWeight: 600, color: "#374151", fontFamily: "Plus Jakarta Sans, sans-serif" }}>PASSWORD</label>
              <button type="button" style={{ fontSize: "12px", color: "#059669", background: "none", border: "none", cursor: "pointer", fontWeight: 500 }}>Forgot password?</button>
            </div>
            <div style={{ position: "relative" }}>
              <input type={showPass ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)} required placeholder="••••••••" style={{ ...inp, paddingRight: "44px" }}
                onFocus={e => (e.target.style.borderColor = "#059669")}
                onBlur={e => (e.target.style.borderColor = "#E2E8F0")}
              />
              <button type="button" onClick={() => setShowPass(!showPass)} style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", fontSize: "12px", color: "#94A3B8", fontWeight: 500 }}>
                {showPass ? "Hide" : "Show"}
              </button>
            </div>
          </div>

          {error && (
            <div style={{ padding: "10px 12px", background: "#FEF2F2", border: "1px solid #FECACA", borderRadius: "8px", fontSize: "13px", color: "#DC2626" }}>
              {error}
            </div>
          )}

          <button type="submit" disabled={loading} style={{
            padding: "10px 16px", background: loading ? "#D1FAE5" : "#059669", color: loading ? "#059669" : "#fff",
            border: "none", borderRadius: "8px", fontSize: "14px", fontWeight: 600, cursor: loading ? "not-allowed" : "pointer",
            fontFamily: "Plus Jakarta Sans, sans-serif", transition: "background 0.15s, transform 0.1s",
          }}
            onMouseEnter={e => { if (!loading) (e.currentTarget as HTMLElement).style.background = "#047857"; }}
            onMouseLeave={e => { if (!loading) (e.currentTarget as HTMLElement).style.background = "#059669"; }}
          >
            {loading ? "Signing in…" : "Sign in →"}
          </button>
        </form>

        {/* SSO divider */}
        <div style={{ display: "flex", alignItems: "center", gap: "12px", margin: "20px 0" }}>
          <div style={{ flex: 1, height: "1px", background: "#E2E8F0" }} />
          <span style={{ fontSize: "12px", color: "#94A3B8", fontWeight: 500 }}>Or continue with SSO</span>
          <div style={{ flex: 1, height: "1px", background: "#E2E8F0" }} />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "24px" }}>
          {[
            { label: "Google Workspace", icon: "G" },
            { label: "Microsoft Entra", icon: "M" },
          ].map(sso => (
            <button key={sso.label} type="button" style={{
              display: "flex", alignItems: "center", justifyContent: "center", gap: "8px",
              padding: "9px 12px", border: "1px solid #E2E8F0", borderRadius: "8px",
              background: "#fff", fontSize: "13px", color: "#374151", cursor: "pointer",
              fontWeight: 500, transition: "border-color 0.15s, background 0.15s",
            }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#F8FAFC"; (e.currentTarget as HTMLElement).style.borderColor = "#CBD5E1"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#fff"; (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; }}
            >
              <span style={{ width: "18px", height: "18px", borderRadius: "4px", background: "#0F172A", color: "#fff", fontSize: "10px", fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{sso.icon}</span>
              {sso.label}
            </button>
          ))}
        </div>

        {/* Role switcher */}
        <div style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", borderRadius: "10px", padding: "16px" }}>
          <p style={{ fontSize: "11px", fontWeight: 700, color: "#94A3B8", letterSpacing: "0.08em", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "12px" }}>DEMO ROLE SELECTOR</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
            {ROLES.map(r => (
              <button key={r.key} type="button" onClick={() => fillRole(r)} style={{
                display: "flex", alignItems: "center", gap: "8px", padding: "8px 10px",
                border: `1px solid ${activeRole === r.key ? r.color : "#E2E8F0"}`,
                borderRadius: "8px", background: activeRole === r.key ? `${r.color}0D` : "#fff",
                cursor: "pointer", textAlign: "left", transition: "all 0.15s",
              }}>
                <span style={{
                  width: "28px", height: "28px", borderRadius: "6px", background: `${r.color}18`,
                  color: r.color, fontSize: "10px", fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center",
                  fontFamily: "Plus Jakarta Sans, sans-serif", flexShrink: 0,
                }}>{r.badge}</span>
                <div>
                  <div style={{ fontSize: "12px", fontWeight: 600, color: "#0F172A", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{r.label}</div>
                  <div style={{ fontSize: "11px", color: "#94A3B8", marginTop: "1px" }}>Click to fill</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @media (min-width: 900px) {
          .login-hero { display: flex !important; }
        }
      `}</style>
    </div>
  );
}
