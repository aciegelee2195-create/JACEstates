import type { Portal } from "../App";

interface Props { onSelect: (p: Portal) => void; }

export default function PortalSelector({ onSelect }: Props) {
  const card: React.CSSProperties = {
    flex: 1, position: "relative", overflow: "hidden", cursor: "pointer",
    display: "flex", flexDirection: "column", justifyContent: "flex-end",
    minHeight: "100vh", transition: "flex 0.5s cubic-bezier(0.4,0,0.2,1)",
  };

  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "Inter, sans-serif" }}>

      {/* ── Client Experience Panel ── */}
      <div style={card} onClick={() => onSelect("client")}
        onMouseEnter={e => (e.currentTarget.style.flex = "1.2")}
        onMouseLeave={e => (e.currentTarget.style.flex = "1")}
      >
        <img
          src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&h=1400&fit=crop&auto=format"
          alt="Luxury residential tower"
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }}
        />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(26,23,20,0.1) 0%, rgba(26,23,20,0.85) 100%)" }} />
        <div style={{ position: "relative", zIndex: 1, padding: "40px 40px 48px" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: "6px", padding: "5px 12px", background: "rgba(13,122,82,0.18)", border: "1px solid rgba(13,122,82,0.4)", borderRadius: "100px", marginBottom: "14px" }}>
            <span style={{ width: "5px", height: "5px", borderRadius: "50%", background: "#34D399", display: "block" }} />
            <span style={{ fontSize: "10px", fontWeight: 700, color: "#6EE7B7", letterSpacing: "0.1em", fontFamily: "Plus Jakarta Sans, sans-serif" }}>BUYERS & RENTERS</span>
          </div>
          <h2 style={{ fontSize: "36px", fontWeight: 400, color: "#FAF8F5", fontFamily: "Instrument Serif, serif", lineHeight: 1.15, letterSpacing: "-0.01em", marginBottom: "12px" }}>
            Client<br /><em>Experience</em>
          </h2>
          <p style={{ fontSize: "14px", color: "rgba(250,248,245,0.7)", lineHeight: 1.6, maxWidth: "300px", marginBottom: "22px" }}>
            Explore Meridian Residences — browse floor plans, view live availability, and secure your unit online.
          </p>
          <div style={{ display: "flex", gap: "7px", flexWrap: "wrap", marginBottom: "28px" }}>
            {["Unit Explorer", "Floor Stacking", "48hr Hold", "Digital Checkout"].map(f => (
              <span key={f} style={{ padding: "4px 10px", background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.18)", borderRadius: "100px", fontSize: "11px", color: "rgba(255,255,255,0.8)" }}>{f}</span>
            ))}
          </div>
          <button style={{
            display: "inline-flex", alignItems: "center", gap: "8px", padding: "12px 24px",
            background: "#C9943A", border: "none", borderRadius: "8px", color: "#1A1714",
            fontSize: "13px", fontWeight: 700, cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif",
          }}>
            Enter Client Portal →
          </button>
        </div>
      </div>

      {/* Divider */}
      <div style={{ width: "1px", background: "rgba(255,255,255,0.08)", flexShrink: 0, zIndex: 2 }} />

      {/* ── Admin Portal Panel ── */}
      <div style={card} onClick={() => onSelect("admin")}
        onMouseEnter={e => (e.currentTarget.style.flex = "1.2")}
        onMouseLeave={e => (e.currentTarget.style.flex = "1")}
      >
        <img
          src="https://images.unsplash.com/photo-1486325212027-8081e485255e?w=900&h=1400&fit=crop&auto=format"
          alt="Enterprise office building"
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", filter: "grayscale(30%)" }}
        />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(10,15,26,0.3) 0%, rgba(10,15,26,0.93) 100%)" }} />
        <div style={{ position: "relative", zIndex: 1, padding: "40px 40px 48px" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: "6px", padding: "5px 12px", background: "rgba(5,150,105,0.15)", border: "1px solid rgba(5,150,105,0.35)", borderRadius: "100px", marginBottom: "14px" }}>
            <span style={{ width: "5px", height: "5px", borderRadius: "50%", background: "#059669", display: "block" }} />
            <span style={{ fontSize: "10px", fontWeight: 700, color: "#34D399", letterSpacing: "0.1em", fontFamily: "Plus Jakarta Sans, sans-serif" }}>STAFF & AGENTS</span>
          </div>
          <h2 style={{ fontSize: "36px", fontWeight: 700, color: "#F1F5F9", fontFamily: "Plus Jakarta Sans, sans-serif", lineHeight: 1.15, letterSpacing: "-0.03em", marginBottom: "12px" }}>
            Management<br />Command
          </h2>
          <p style={{ fontSize: "14px", color: "rgba(241,245,249,0.6)", lineHeight: 1.6, maxWidth: "300px", marginBottom: "22px" }}>
            Full ERP + CRM — real-time inventory, lead pipeline, deposit ledger, and agent performance.
          </p>
          <div style={{ display: "flex", gap: "7px", flexWrap: "wrap", marginBottom: "28px" }}>
            {["CRM Pipeline", "ERP Inventory", "Financial Ledger", "Agent Tools"].map(f => (
              <span key={f} style={{ padding: "4px 10px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "100px", fontSize: "11px", color: "rgba(255,255,255,0.65)" }}>{f}</span>
            ))}
          </div>
          <button style={{
            display: "inline-flex", alignItems: "center", gap: "8px", padding: "12px 24px",
            background: "#059669", border: "none", borderRadius: "8px", color: "#fff",
            fontSize: "13px", fontWeight: 700, cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif",
          }}>
            Enter Admin Portal →
          </button>
        </div>
      </div>

      {/* Top brand bar */}
      <div style={{ position: "fixed", top: 0, left: 0, right: 0, display: "flex", alignItems: "center", justifyContent: "center", padding: "18px", zIndex: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px", background: "rgba(15,23,42,0.65)", backdropFilter: "blur(12px)", padding: "10px 20px", borderRadius: "100px", border: "1px solid rgba(255,255,255,0.1)" }}>
          <div style={{ width: "28px", height: "28px", borderRadius: "7px", background: "#059669", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ color: "#fff", fontWeight: 800, fontSize: "13px", fontFamily: "Plus Jakarta Sans, sans-serif" }}>J</span>
          </div>
          <span style={{ color: "#F1F5F9", fontSize: "15px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", letterSpacing: "-0.01em" }}>JACEstates</span>
          <span style={{ color: "rgba(255,255,255,0.3)", fontSize: "13px" }}>·</span>
          <span style={{ color: "rgba(255,255,255,0.5)", fontSize: "12px" }}>Select your portal</span>
        </div>
      </div>
    </div>
  );
}
