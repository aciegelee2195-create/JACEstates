import { useState } from "react";
import type { ClientUser } from "../contexts/ClientAuthContext";
import { useClientAuth } from "../contexts/ClientAuthContext";

export interface AdminUser {
  id: string;
  name: string;
  role: string;
  email: string;
  roleKey: "super_admin" | "broker" | "property_manager" | "finance";
  initials: string;
  color: string;
}

export type SessionType =
  | { type: "client"; user: ClientUser }
  | { type: "admin"; user: AdminUser };

interface Props { onLogin: (session: SessionType) => void; }

const ADMIN_ACCOUNTS: Array<AdminUser & { password: string }> = [
  { id: "ADM-001", name: "Super Admin",    role: "Super Administrator", email: "super@jacestates.com",    roleKey: "super_admin",      initials: "SA", color: "#7C3AED", password: "admin123"  },
  { id: "ADM-002", name: "Alexandra Chen", role: "Senior Broker",       email: "a.chen@jacestates.com",   roleKey: "broker",           initials: "AC", color: "#059669", password: "broker123" },
  { id: "ADM-003", name: "Marcus Torres",  role: "Property Manager",    email: "m.torres@jacestates.com", roleKey: "property_manager", initials: "MT", color: "#0284C7", password: "pm123"     },
  { id: "ADM-004", name: "Priya Singh",    role: "Finance Manager",     email: "p.singh@jacestates.com",  roleKey: "finance",          initials: "PS", color: "#D97706", password: "finance123"},
];

const FH = "Plus Jakarta Sans, sans-serif";
const FB = "Inter, sans-serif";
const FM = "JetBrains Mono, monospace";

const INP_STYLE: React.CSSProperties = {
  width: "100%", padding: "12px 14px", border: "1px solid #E2E8F0", borderRadius: "10px",
  background: "#fff", color: "#0F172A", fontSize: "14px", outline: "none",
  fontFamily: FB, boxSizing: "border-box", transition: "border-color 0.15s, box-shadow 0.15s",
};
const LBL_STYLE: React.CSSProperties = {
  display: "block", fontSize: "11px", fontWeight: 700, color: "#64748B",
  letterSpacing: "0.06em", marginBottom: "5px", fontFamily: FB,
};

function focusStyle(e: React.FocusEvent<HTMLInputElement>) {
  e.target.style.borderColor = "#059669";
  e.target.style.boxShadow = "0 0 0 3px rgba(5,150,105,0.1)";
}
function blurStyle(e: React.FocusEvent<HTMLInputElement>) {
  e.target.style.borderColor = "#E2E8F0";
  e.target.style.boxShadow = "none";
}

export default function LoginGate({ onLogin }: Props) {
  const { login, signup } = useClientAuth();
  const [tab, setTab] = useState<"client" | "admin">("client");
  const [mode, setMode] = useState<"login" | "signup">("login");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function resetFields() { setName(""); setEmail(""); setPhone(""); setPassword(""); setConfirm(""); setError(""); }

  function handleClientSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (mode === "signup") {
      if (password !== confirm) { setError("Passwords do not match."); return; }
      if (password.length < 6) { setError("Password must be at least 6 characters."); return; }
    }
    setLoading(true);
    setTimeout(() => {
      const result = mode === "login" ? login(email, password) : signup(name, email, password, phone);
      if (!result.ok || !result.user) { setError(result.error ?? "Login failed."); setLoading(false); return; }
      onLogin({ type: "client", user: result.user });
      setLoading(false);
    }, 400);
  }

  function handleAdminSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    setTimeout(() => {
      const found = ADMIN_ACCOUNTS.find(a => a.email.toLowerCase() === email.toLowerCase() && a.password === password);
      if (!found) { setError("Invalid credentials."); setLoading(false); return; }
      const { password: _, ...u } = found;
      onLogin({ type: "admin", user: u });
      setLoading(false);
    }, 400);
  }

  function fillDemo(e: string, p: string) { setEmail(e); setPassword(p); }

  return (
    <div style={{ minHeight: "100vh", display: "flex", fontFamily: FB, background: "#F8FAFC" }}>

      {/* ── Left brand panel ── */}
      <div style={{ width: "460px", flexShrink: 0, background: "#0F172A", display: "flex", flexDirection: "column", position: "relative", overflow: "hidden" }}>
        <img src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=920&h=1400&fit=crop&auto=format" alt="Meridian Residences"
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.2 }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(185deg, rgba(15,23,42,0.5) 0%, rgba(15,23,42,0.97) 100%)" }} />

        <div style={{ position: "relative", zIndex: 1, flex: 1, display: "flex", flexDirection: "column", padding: "44px 44px 40px" }}>
          {/* Logo */}
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "auto" }}>
            <div style={{ width: "38px", height: "38px", borderRadius: "9px", background: "#059669", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#fff", fontWeight: 800, fontSize: "16px", fontFamily: FH }}>J</span>
            </div>
            <span style={{ fontSize: "20px", fontWeight: 800, color: "#F1F5F9", fontFamily: FH, letterSpacing: "-0.02em" }}>JACEstates</span>
          </div>

          {/* Hero */}
          <div style={{ marginBottom: "44px" }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: "6px", padding: "4px 10px", background: "rgba(5,150,105,0.15)", border: "1px solid rgba(5,150,105,0.3)", borderRadius: "100px", marginBottom: "16px" }}>
              <div style={{ width: "5px", height: "5px", borderRadius: "50%", background: "#34D399" }} />
              <span style={{ fontSize: "10px", fontWeight: 700, color: "#34D399", letterSpacing: "0.08em", fontFamily: FB }}>NOW SELLING & RENTING</span>
            </div>
            <h1 style={{ fontSize: "40px", fontWeight: 800, color: "#F1F5F9", fontFamily: FH, lineHeight: 1.12, letterSpacing: "-0.03em", marginBottom: "16px" }}>
              Meridian<br />Residences
            </h1>
            <p style={{ fontSize: "14px", color: "rgba(241,245,249,0.55)", lineHeight: 1.7, fontFamily: FB, maxWidth: "310px" }}>
              86 premium units across 23 floors. Studio to Penthouse. Panoramic views, flexible payment plans.
            </p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "7px", marginTop: "20px" }}>
              {["Instant Reservation", "20% Deposit", "Flexible Terms", "24/7 Support"].map(f => (
                <span key={f} style={{ padding: "5px 12px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "100px", fontSize: "11px", color: "rgba(255,255,255,0.55)", fontFamily: FB }}>{f}</span>
              ))}
            </div>
          </div>

          {/* Stats row */}
          <div style={{ display: "flex", gap: "0", borderTop: "1px solid rgba(255,255,255,0.08)", paddingTop: "26px" }}>
            {[["86", "Units"], ["23", "Floors"], ["5", "Types"]].map(([n, l], i, arr) => (
              <div key={l} style={{ flex: 1, paddingRight: i < arr.length - 1 ? "16px" : 0, borderRight: i < arr.length - 1 ? "1px solid rgba(255,255,255,0.08)" : "none", marginRight: i < arr.length - 1 ? "16px" : 0 }}>
                <p style={{ fontSize: "28px", fontWeight: 800, color: "#F1F5F9", fontFamily: FH, letterSpacing: "-0.02em" }}>{n}</p>
                <p style={{ fontSize: "11px", color: "rgba(241,245,249,0.35)", fontFamily: FB }}>{l}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Right form panel ── */}
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 52px", overflowY: "auto" }}>
        <div style={{ width: "100%", maxWidth: "400px" }}>

          {/* Portal toggle */}
          <div style={{ display: "flex", background: "#F1F5F9", borderRadius: "12px", padding: "4px", marginBottom: "32px" }}>
            {(["client", "admin"] as const).map(t => (
              <button key={t} onClick={() => { setTab(t); setMode("login"); resetFields(); }}
                style={{ flex: 1, padding: "10px 16px", border: "none", borderRadius: "9px", background: tab === t ? "#fff" : "transparent", fontSize: "13px", fontWeight: tab === t ? 700 : 500, color: tab === t ? "#0F172A" : "#64748B", cursor: "pointer", fontFamily: FH, boxShadow: tab === t ? "0 1px 4px rgba(15,23,42,0.08)" : "none", transition: "all 0.15s" }}>
                {t === "client" ? "🏠  Client Access" : "⚙️  Staff / Admin"}
              </button>
            ))}
          </div>

          {/* Heading */}
          <div style={{ marginBottom: "24px" }}>
            <h2 style={{ fontSize: "26px", fontWeight: 800, color: "#0F172A", fontFamily: FH, letterSpacing: "-0.02em", marginBottom: "6px" }}>
              {tab === "client" ? (mode === "login" ? "Welcome back" : "Create account") : "Staff sign in"}
            </h2>
            <p style={{ fontSize: "14px", color: "#64748B", fontFamily: FB, lineHeight: 1.55 }}>
              {tab === "client" && mode === "login" && "Sign in to browse properties and manage your reservations."}
              {tab === "client" && mode === "signup" && "Join to start reserving or purchasing Meridian Residences units."}
              {tab === "admin" && "Access restricted to authorized JACEstates staff only."}
            </p>
          </div>

          {/* Demo hint */}
          <div style={{ padding: "12px 14px", background: "rgba(5,150,105,0.06)", border: "1px solid rgba(5,150,105,0.15)", borderRadius: "10px", marginBottom: "22px" }}>
            <p style={{ fontSize: "10px", fontWeight: 700, color: "#059669", letterSpacing: "0.07em", marginBottom: "8px", fontFamily: FB }}>DEMO — CLICK TO AUTOFILL</p>
            <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
              {(tab === "client"
                ? [["demo@meridian.com", "demo123", "Demo Client"]]
                : [["super@jacestates.com", "admin123", "Super Admin"], ["a.chen@jacestates.com", "broker123", "Broker"]]
              ).map(([em, pw, lbl]) => (
                <button key={em} type="button" onClick={() => fillDemo(em, pw)}
                  style={{ padding: "6px 10px", background: "#fff", border: "1px solid #E2E8F0", borderRadius: "7px", cursor: "pointer", textAlign: "left", transition: "border-color 0.15s" }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = "#059669")}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = "#E2E8F0")}>
                  <p style={{ fontSize: "11px", fontWeight: 700, color: "#0F172A", fontFamily: FH }}>{lbl}</p>
                  <p style={{ fontSize: "9px", color: "#94A3B8", fontFamily: FM }}>{em}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Form */}
          <form onSubmit={tab === "client" ? handleClientSubmit : handleAdminSubmit} style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
            {tab === "client" && mode === "signup" && (
              <div>
                <label style={LBL_STYLE}>FULL NAME *</label>
                <input value={name} onChange={e => setName(e.target.value)} required placeholder="Jane Smith" style={INP_STYLE} onFocus={focusStyle} onBlur={blurStyle} />
              </div>
            )}
            <div>
              <label style={LBL_STYLE}>EMAIL ADDRESS *</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder={tab === "admin" ? "admin@jacestates.com" : "jane@example.com"} style={INP_STYLE} onFocus={focusStyle} onBlur={blurStyle} />
            </div>
            {tab === "client" && mode === "signup" && (
              <div>
                <label style={LBL_STYLE}>PHONE NUMBER</label>
                <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+1 (305) 555-0000" style={INP_STYLE} onFocus={focusStyle} onBlur={blurStyle} />
              </div>
            )}
            <div>
              <label style={LBL_STYLE}>PASSWORD *</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} required placeholder={mode === "signup" ? "Min. 6 characters" : "Enter your password"} style={INP_STYLE} onFocus={focusStyle} onBlur={blurStyle} />
            </div>
            {tab === "client" && mode === "signup" && (
              <div>
                <label style={LBL_STYLE}>CONFIRM PASSWORD *</label>
                <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)} required placeholder="Repeat password" style={INP_STYLE} onFocus={focusStyle} onBlur={blurStyle} />
              </div>
            )}

            {error && (
              <div style={{ padding: "11px 14px", background: "rgba(220,38,38,0.06)", border: "1px solid rgba(220,38,38,0.18)", borderRadius: "9px", fontSize: "13px", color: "#DC2626", fontFamily: FB }}>
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} style={{ padding: "13px", background: "#059669", border: "none", borderRadius: "10px", fontSize: "15px", fontWeight: 700, color: "#fff", cursor: loading ? "not-allowed" : "pointer", fontFamily: FH, opacity: loading ? 0.8 : 1, transition: "background 0.15s", marginTop: "2px" }}
              onMouseEnter={e => { if (!loading) (e.currentTarget.style.background = "#047857"); }}
              onMouseLeave={e => { if (!loading) (e.currentTarget.style.background = "#059669"); }}>
              {loading ? "Please wait…" : tab === "client" ? (mode === "login" ? "Sign In →" : "Create Account →") : "Sign In to Admin →"}
            </button>
          </form>

          {/* Toggle login/signup for client */}
          {tab === "client" && (
            <p style={{ textAlign: "center", marginTop: "22px", fontSize: "14px", color: "#64748B", fontFamily: FB }}>
              {mode === "login" ? "Don't have an account? " : "Already registered? "}
              <button onClick={() => { setMode(m => m === "login" ? "signup" : "login"); resetFields(); }}
                style={{ background: "none", border: "none", color: "#059669", fontWeight: 700, cursor: "pointer", fontFamily: FB, fontSize: "14px" }}>
                {mode === "login" ? "Create one" : "Sign in here"}
              </button>
            </p>
          )}

        </div>
      </div>
    </div>
  );
}
