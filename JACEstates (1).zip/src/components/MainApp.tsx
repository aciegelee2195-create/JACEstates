import { useState, useEffect, useCallback } from "react";
import { useTheme } from "../contexts/ThemeContext";
import type { AppUser } from "../App";
import Dashboard from "./Dashboard";
import CRM from "./CRM";
import Properties from "./Properties";
import Deals from "./Deals";
import Financials from "./Financials";
import Agents from "./Agents";
import GlobalSearch from "./GlobalSearch";

const NAV_GROUPS = [
  {
    label: "WORKSPACE",
    items: [
      { id: "dashboard", label: "Overview", icon: <GridIcon />, badge: null },
      { id: "crm", label: "CRM Pipeline", icon: <PipeIcon />, badge: "38" },
      { id: "properties", label: "Properties", icon: <BuildingIcon />, badge: null },
      { id: "deals", label: "Transactions", icon: <DealIcon />, badge: "7" },
    ],
  },
  {
    label: "FINANCE",
    items: [
      { id: "financials", label: "Financials", icon: <ChartIcon />, badge: null },
      { id: "agents", label: "Team & Agents", icon: <TeamIcon />, badge: null },
    ],
  },
  {
    label: "SYSTEM",
    items: [
      { id: "settings", label: "Settings", icon: <SettingsIcon />, badge: null },
      { id: "audit", label: "Audit Log", icon: <AuditIcon />, badge: null },
    ],
  },
];

interface Props { user: AppUser; onLogout: () => void; }

export default function MainApp({ user, onLogout }: Props) {
  const { theme, toggle, isDark } = useTheme();
  const [active, setActive] = useState("dashboard");
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [newActionOpen, setNewActionOpen] = useState(false);

  const openSearch = useCallback(() => setSearchOpen(true), []);

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    }
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  const NOTIFS = [
    { id: 1, text: "New lead: Robert Kim assigned to A. Chen", time: "4m ago", unread: true, type: "lead" },
    { id: 2, text: "Deal D-2847 moved to Closing stage", time: "18m ago", unread: true, type: "deal" },
    { id: 3, text: "Tenant maintenance ticket #441 — Unit 4B overdue", time: "1h ago", unread: true, type: "alert" },
    { id: 4, text: "Q3 Financial Report ready for review", time: "3h ago", unread: false, type: "finance" },
    { id: 5, text: "Lease renewal: 12 Fairview Commons expires in 30d", time: "Yesterday", unread: false, type: "lease" },
  ];
  const unread = NOTIFS.filter(n => n.unread).length;

  const notifColor: Record<string, string> = { lead: "#059669", deal: "#2563EB", alert: "#D97706", finance: "#7C3AED", lease: "#0F172A" };

  function renderContent() {
    switch (active) {
      case "dashboard": return <Dashboard />;
      case "crm": return <CRM />;
      case "properties": return <Properties />;
      case "deals": return <Deals />;
      case "financials": return <Financials />;
      case "agents": return <Agents />;
      default: return (
        <div style={{ padding: "40px", color: "var(--text-muted)", fontSize: "14px" }}>
          <p style={{ color: "var(--text)", fontWeight: 600, fontSize: "16px", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "8px" }}>Coming soon</p>
          This section is under construction.
        </div>
      );
    }
  }

  const sb: React.CSSProperties = {
    width: "240px", flexShrink: 0, background: "#0F172A",
    borderRight: "1px solid #1E293B", display: "flex", flexDirection: "column",
    height: "100vh", overflow: "hidden",
  };

  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden" }}>
      {/* ── Sidebar ── */}
      <aside style={sb}>
        {/* Logo */}
        <div style={{ padding: "18px 20px 16px", borderBottom: "1px solid #1E293B" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#059669", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <span style={{ color: "#fff", fontWeight: 800, fontSize: "14px", fontFamily: "Plus Jakarta Sans, sans-serif" }}>J</span>
            </div>
            <div>
              <div style={{ color: "#F1F5F9", fontSize: "15px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", letterSpacing: "-0.01em", lineHeight: 1.2 }}>JACEstates</div>
              <div style={{ color: "#475569", fontSize: "11px", marginTop: "1px" }}>acme.jacestates.com</div>
            </div>
          </div>
        </div>

        {/* Search shortcut */}
        <div style={{ padding: "12px 12px 8px" }}>
          <button onClick={openSearch} style={{
            width: "100%", display: "flex", alignItems: "center", gap: "8px", padding: "7px 10px",
            background: "#1E293B", border: "1px solid #1E293B", borderRadius: "8px",
            cursor: "pointer", transition: "border-color 0.15s",
          }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = "#334155")}
            onMouseLeave={e => (e.currentTarget.style.borderColor = "#1E293B")}
          >
            <span style={{ fontSize: "12px", color: "#475569" }}>⌕</span>
            <span style={{ flex: 1, color: "#475569", fontSize: "13px", textAlign: "left" }}>Quick search…</span>
            <kbd style={{ background: "#0F172A", border: "1px solid #334155", borderRadius: "4px", padding: "1px 5px", fontSize: "10px", color: "#475569", fontFamily: "JetBrains Mono, monospace" }}>⌘K</kbd>
          </button>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, overflowY: "auto", padding: "4px 0 16px" }}>
          {NAV_GROUPS.map(group => (
            <div key={group.label} style={{ marginBottom: "4px" }}>
              <p style={{ padding: "10px 20px 6px", fontSize: "10px", fontWeight: 700, color: "#334155", letterSpacing: "0.07em", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{group.label}</p>
              {group.items.map(item => {
                const isActive = active === item.id;
                return (
                  <button key={item.id} onClick={() => setActive(item.id)} style={{
                    width: "100%", display: "flex", alignItems: "center", gap: "10px",
                    padding: "7px 20px 7px 16px", background: isActive ? "rgba(5,150,105,0.12)" : "transparent",
                    border: "none", borderLeft: `2px solid ${isActive ? "#059669" : "transparent"}`,
                    cursor: "pointer", transition: "all 0.12s",
                  }}
                    onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
                    onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = "transparent"; }}
                  >
                    <span style={{ color: isActive ? "#059669" : "#475569", flexShrink: 0, display: "flex", alignItems: "center" }}>{item.icon}</span>
                    <span style={{ flex: 1, fontSize: "13.5px", fontWeight: isActive ? 600 : 400, color: isActive ? "#F1F5F9" : "#94A3B8", textAlign: "left", fontFamily: "Inter, sans-serif" }}>{item.label}</span>
                    {item.badge && (
                      <span style={{ background: isActive ? "#059669" : "#1E293B", color: isActive ? "#fff" : "#64748B", fontSize: "10px", fontWeight: 600, padding: "1px 6px", borderRadius: "100px", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{item.badge}</span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* User card */}
        <div style={{ padding: "12px", borderTop: "1px solid #1E293B" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px", background: "#1E293B", borderRadius: "8px" }}>
            <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#059669", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: "12px", fontWeight: 700, color: "#fff", fontFamily: "Plus Jakarta Sans, sans-serif" }}>
              {user.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: "13px", fontWeight: 600, color: "#F1F5F9", fontFamily: "Plus Jakarta Sans, sans-serif", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{user.name}</div>
              <div style={{ fontSize: "11px", color: "#475569", marginTop: "1px" }}>{user.role}</div>
            </div>
            <button onClick={onLogout} title="Sign out" style={{ background: "none", border: "none", cursor: "pointer", color: "#334155", padding: "4px", borderRadius: "4px", fontSize: "14px" }}
              onMouseEnter={e => (e.currentTarget.style.color = "#94A3B8")}
              onMouseLeave={e => (e.currentTarget.style.color = "#334155")}
            >→</button>
          </div>
        </div>
      </aside>

      {/* ── Main area ── */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }} data-theme={theme}>
        {/* Top header */}
        <header style={{
          height: "56px", display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 24px", background: "var(--bg-card)", borderBottom: "1px solid var(--border)",
          flexShrink: 0, gap: "12px",
        }}>
          {/* Page title */}
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <span style={{ fontSize: "13px", color: "var(--text-muted)" }}>JACEstates</span>
            <span style={{ color: "var(--border-strong)", fontSize: "13px" }}>/</span>
            <span style={{ fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", textTransform: "capitalize" }}>
              {active === "dashboard" ? "Overview" : active === "crm" ? "CRM Pipeline" : active}
            </span>
          </div>

          {/* Header right */}
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            {/* Search */}
            <button onClick={openSearch} style={{
              display: "flex", alignItems: "center", gap: "8px", padding: "6px 12px",
              background: "var(--bg-subtle)", border: "1px solid var(--border)", borderRadius: "8px",
              cursor: "pointer", transition: "border-color 0.15s",
            }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = "var(--border-strong)")}
              onMouseLeave={e => (e.currentTarget.style.borderColor = "var(--border)")}
            >
              <span style={{ fontSize: "13px", color: "var(--text-muted)" }}>⌕</span>
              <span style={{ fontSize: "13px", color: "var(--text-dim)", minWidth: "140px" }}>Search properties, clients…</span>
              <kbd style={{ background: "var(--bg-card)", border: "1px solid var(--border-strong)", borderRadius: "4px", padding: "1px 5px", fontSize: "10px", color: "var(--text-dim)", fontFamily: "JetBrains Mono, monospace" }}>⌘K</kbd>
            </button>

            {/* + New action */}
            <div style={{ position: "relative" }}>
              <button onClick={() => setNewActionOpen(!newActionOpen)} style={{
                display: "flex", alignItems: "center", gap: "6px", padding: "7px 14px",
                background: "#059669", border: "none", borderRadius: "8px",
                cursor: "pointer", fontSize: "13px", fontWeight: 600, color: "#fff",
                fontFamily: "Plus Jakarta Sans, sans-serif",
              }}
                onMouseEnter={e => (e.currentTarget.style.background = "#047857")}
                onMouseLeave={e => (e.currentTarget.style.background = "#059669")}
              >
                <span style={{ fontSize: "16px", lineHeight: 1 }}>+</span> New
              </button>
              {newActionOpen && (
                <div style={{ position: "absolute", right: 0, top: "40px", width: "180px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", boxShadow: "var(--shadow-lg)", overflow: "hidden", zIndex: 100 }}>
                  {["New Deal", "Add Property", "New Lead", "Add Tenant", "Log Activity"].map(a => (
                    <button key={a} onClick={() => setNewActionOpen(false)} style={{
                      width: "100%", padding: "9px 14px", textAlign: "left", background: "none", border: "none",
                      fontSize: "13px", color: "var(--text-2)", cursor: "pointer", display: "block",
                    }}
                      onMouseEnter={e => (e.currentTarget.style.background = "var(--bg-hover)")}
                      onMouseLeave={e => (e.currentTarget.style.background = "none")}
                    >{a}</button>
                  ))}
                </div>
              )}
            </div>

            {/* Notifications */}
            <div style={{ position: "relative" }}>
              <button onClick={() => setNotifOpen(!notifOpen)} style={{
                position: "relative", width: "36px", height: "36px", borderRadius: "8px",
                background: "var(--bg-subtle)", border: "1px solid var(--border)",
                cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "16px",
              }}>
                🔔
                {unread > 0 && <span style={{ position: "absolute", top: "5px", right: "5px", width: "8px", height: "8px", background: "#DC2626", borderRadius: "50%", border: "1.5px solid var(--bg-card)" }} />}
              </button>
              {notifOpen && (
                <div style={{ position: "absolute", right: 0, top: "44px", width: "320px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "12px", boxShadow: "var(--shadow-lg)", zIndex: 100, overflow: "hidden" }}>
                  <div style={{ padding: "14px 16px 10px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid var(--border)" }}>
                    <span style={{ fontSize: "13px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>Notifications</span>
                    <button style={{ fontSize: "12px", color: "#059669", background: "none", border: "none", cursor: "pointer", fontWeight: 500 }}>Mark all read</button>
                  </div>
                  {NOTIFS.map(n => (
                    <div key={n.id} style={{ padding: "11px 16px", borderBottom: "1px solid var(--border)", display: "flex", gap: "10px", background: n.unread ? "var(--bg-subtle)" : "transparent" }}>
                      <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: notifColor[n.type], marginTop: "5px", flexShrink: 0, opacity: n.unread ? 1 : 0 }} />
                      <div style={{ flex: 1 }}>
                        <p style={{ fontSize: "12.5px", color: "var(--text-2)", lineHeight: 1.5 }}>{n.text}</p>
                        <p style={{ fontSize: "11px", color: "var(--text-dim)", marginTop: "3px" }}>{n.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Theme toggle */}
            <button onClick={toggle} title={`Switch to ${isDark ? "light" : "dark"} mode`} style={{
              width: "36px", height: "36px", borderRadius: "8px", background: "var(--bg-subtle)",
              border: "1px solid var(--border)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "15px",
            }}>
              {isDark ? "☀️" : "🌙"}
            </button>

            {/* Avatar */}
            <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "#059669", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "12px", fontWeight: 700, color: "#fff", fontFamily: "Plus Jakarta Sans, sans-serif", cursor: "pointer", flexShrink: 0 }}>
              {user.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
            </div>
          </div>
        </header>

        {/* Page content */}
        <main style={{ flex: 1, overflowY: "auto", background: "var(--bg)" }}>
          {renderContent()}
        </main>
      </div>

      {/* Overlays */}
      {(notifOpen || newActionOpen) && <div style={{ position: "fixed", inset: 0, zIndex: 90 }} onClick={() => { setNotifOpen(false); setNewActionOpen(false); }} />}
      {searchOpen && <GlobalSearch onClose={() => setSearchOpen(false)} />}
    </div>
  );
}

/* ── Icon components ── */
function GridIcon() { return <svg width="15" height="15" fill="none" viewBox="0 0 15 15"><rect x="1" y="1" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.5"/><rect x="9" y="1" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.5"/><rect x="1" y="9" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.5"/><rect x="9" y="9" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.5"/></svg>; }
function PipeIcon() { return <svg width="15" height="15" fill="none" viewBox="0 0 15 15"><path d="M2 7.5h11M7.5 2l5.5 5.5-5.5 5.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>; }
function BuildingIcon() { return <svg width="15" height="15" fill="none" viewBox="0 0 15 15"><path d="M2 13V4l5.5-2L13 4v9M2 13h11M6 13V9h3v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>; }
function DealIcon() { return <svg width="15" height="15" fill="none" viewBox="0 0 15 15"><path d="M1 8l4-4 3 3 6-6M10 2h3v3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M1 13h13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>; }
function ChartIcon() { return <svg width="15" height="15" fill="none" viewBox="0 0 15 15"><path d="M1 13V9h3v4H1zm5 0V5h3v8H6zm5 0V1h3v12h-3z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/></svg>; }
function TeamIcon() { return <svg width="15" height="15" fill="none" viewBox="0 0 15 15"><circle cx="5" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.5"/><circle cx="11" cy="4.5" r="2" stroke="currentColor" strokeWidth="1.5"/><path d="M1 13c0-2.21 1.79-4 4-4s4 1.79 4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><path d="M11 9c1.66 0 3 1.34 3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>; }
function SettingsIcon() { return <svg width="15" height="15" fill="none" viewBox="0 0 15 15"><circle cx="7.5" cy="7.5" r="2" stroke="currentColor" strokeWidth="1.5"/><path d="M7.5 1v1.5M7.5 12.5V14M1 7.5h1.5M12.5 7.5H14M3.05 3.05l1.06 1.06M10.89 10.89l1.06 1.06M3.05 11.95l1.06-1.06M10.89 4.11l1.06-1.06" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>; }
function AuditIcon() { return <svg width="15" height="15" fill="none" viewBox="0 0 15 15"><rect x="2" y="1" width="11" height="13" rx="1.5" stroke="currentColor" strokeWidth="1.5"/><path d="M5 5h5M5 7.5h5M5 10h3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>; }
