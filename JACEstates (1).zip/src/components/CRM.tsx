import { useState } from "react";

type Stage = "New Lead" | "Tour Scheduled" | "Offer Submitted" | "Under Contract" | "Closed Won";

interface Lead {
  id: string;
  name: string;
  email: string;
  property: string;
  propType: "Residential" | "Commercial" | "Industrial";
  value: number;
  score: number;
  agent: string;
  agentInitials: string;
  agentColor: string;
  lastContacted: string;
  stage: Stage;
  dealSize: "Small" | "Mid" | "Large";
}

const LEADS: Lead[] = [
  { id: "L-0841", name: "Sophia Reeves", email: "s.reeves@meridiangroup.com", property: "8 Harbor Point Terrace", propType: "Residential", value: 4250000, score: 94, agent: "Alexandra Chen", agentInitials: "AC", agentColor: "#059669", lastContacted: "Today", stage: "Under Contract", dealSize: "Large" },
  { id: "L-0840", name: "Robert & Lisa Kim", email: "rkim@kimventures.co", property: "301 Meridian Tower #42B", propType: "Residential", value: 2850000, score: 77, agent: "Marcus Torres", agentInitials: "MT", agentColor: "#2563EB", lastContacted: "Yesterday", stage: "Tour Scheduled", dealSize: "Large" },
  { id: "L-0839", name: "Harlan Frost LLC", email: "hfrost@frostcapital.com", property: "Westbrook Estate", propType: "Commercial", value: 7100000, score: 88, agent: "James Carter", agentInitials: "JC", agentColor: "#7C3AED", lastContacted: "2d ago", stage: "Offer Submitted", dealSize: "Large" },
  { id: "L-0838", name: "Dana Osei", email: "dana.osei@gmail.com", property: "12 Fairview Commons", propType: "Residential", value: 680000, score: 65, agent: "Priya Singh", agentInitials: "PS", agentColor: "#D97706", lastContacted: "3d ago", stage: "Closed Won", dealSize: "Small" },
  { id: "L-0837", name: "Nguyen Family Trust", email: "trust@nguyenlaw.com", property: "47 Crestwood Blvd", propType: "Residential", value: 1320000, score: 42, agent: "Alexandra Chen", agentInitials: "AC", agentColor: "#059669", lastContacted: "1w ago", stage: "New Lead", dealSize: "Mid" },
  { id: "L-0836", name: "Marcus Elliott Partners", email: "melliot@hbcre.com", property: "Parkside Office Complex", propType: "Commercial", value: 11400000, score: 71, agent: "James Carter", agentInitials: "JC", agentColor: "#7C3AED", lastContacted: "5d ago", stage: "Tour Scheduled", dealSize: "Large" },
  { id: "L-0835", name: "Claire Vandenberg", email: "c.vanden@outlook.com", property: "Sunset Lofts Unit 3C", propType: "Residential", value: 495000, score: 30, agent: "Lena Brauer", agentInitials: "LB", agentColor: "#0891B2", lastContacted: "Today", stage: "New Lead", dealSize: "Small" },
  { id: "L-0834", name: "Sun Capital LLC", email: "invest@suncapital.io", property: "Industrial Park Lot 12", propType: "Industrial", value: 9400000, score: 82, agent: "Derek Okafor", agentInitials: "DO", agentColor: "#DC2626", lastContacted: "2d ago", stage: "Offer Submitted", dealSize: "Large" },
  { id: "L-0833", name: "Victor Almeida", email: "v.almeida@grupo.mx", property: "Dev Land Parcel 4A", propType: "Commercial", value: 3200000, score: 59, agent: "Marcus Torres", agentInitials: "MT", agentColor: "#2563EB", lastContacted: "4d ago", stage: "New Lead", dealSize: "Large" },
];

const STAGES: Stage[] = ["New Lead", "Tour Scheduled", "Offer Submitted", "Under Contract", "Closed Won"];

const STAGE_META: Record<Stage, { color: string; bg: string }> = {
  "New Lead": { color: "#64748B", bg: "rgba(100,116,139,0.1)" },
  "Tour Scheduled": { color: "#2563EB", bg: "rgba(37,99,235,0.1)" },
  "Offer Submitted": { color: "#D97706", bg: "rgba(217,119,6,0.1)" },
  "Under Contract": { color: "#7C3AED", bg: "rgba(124,58,237,0.1)" },
  "Closed Won": { color: "#059669", bg: "rgba(5,150,105,0.1)" },
};

function fmtVal(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  return `$${(n / 1_000).toFixed(0)}K`;
}

function ScoreBadge({ score }: { score: number }) {
  const color = score >= 80 ? "#059669" : score >= 60 ? "#D97706" : "#DC2626";
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: "3px", padding: "2px 7px", borderRadius: "100px", background: `${color}15`, border: `1px solid ${color}30`, fontSize: "11px", fontWeight: 700, color, fontFamily: "JetBrains Mono, monospace" }}>
      {score}
    </span>
  );
}

export default function CRM() {
  const [view, setView] = useState<"kanban" | "table">("kanban");
  const [propTypeFilter, setPropTypeFilter] = useState<"All" | "Residential" | "Commercial" | "Industrial">("All");
  const [agentFilter, setAgentFilter] = useState("All");
  const [dealSizeFilter, setDealSizeFilter] = useState<"All" | "Small" | "Mid" | "Large">("All");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [dragId, setDragId] = useState<string | null>(null);
  const [leads, setLeads] = useState<Lead[]>(LEADS);

  const agents = ["All", ...Array.from(new Set(LEADS.map(l => l.agent)))];

  const filtered = leads.filter(l =>
    (propTypeFilter === "All" || l.propType === propTypeFilter) &&
    (agentFilter === "All" || l.agent === agentFilter) &&
    (dealSizeFilter === "All" || l.dealSize === dealSizeFilter)
  );

  const toggleSelect = (id: string) => {
    setSelectedIds(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  function handleDrop(stage: Stage) {
    if (!dragId) return;
    setLeads(ls => ls.map(l => l.id === dragId ? { ...l, stage } : l));
    setDragId(null);
  }

  const fS: React.CSSProperties = { padding: "6px 12px", border: "1px solid var(--border)", borderRadius: "8px", background: "var(--bg-card)", fontSize: "12.5px", color: "var(--text-2)", cursor: "pointer", fontFamily: "Inter, sans-serif" };
  const fSA = (active: boolean): React.CSSProperties => ({ ...fS, background: active ? "rgba(5,150,105,0.1)" : "var(--bg-card)", color: active ? "#059669" : "var(--text-2)", borderColor: active ? "rgba(5,150,105,0.3)" : "var(--border)" });

  return (
    <div style={{ padding: "24px", display: "flex", flexDirection: "column", gap: "16px", height: "100%", boxSizing: "border-box" }}>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: "20px", fontWeight: 700, fontFamily: "Plus Jakarta Sans, sans-serif", color: "var(--text)", letterSpacing: "-0.02em" }}>CRM Pipeline</h1>
          <p style={{ fontSize: "13px", color: "var(--text-muted)", marginTop: "2px" }}>{filtered.length} leads · Total pipeline: <strong style={{ color: "var(--text)" }}>{fmtVal(filtered.reduce((s, l) => s + l.value, 0))}</strong></p>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          {/* View toggle */}
          <div style={{ display: "flex", border: "1px solid var(--border)", borderRadius: "8px", overflow: "hidden" }}>
            {(["kanban", "table"] as const).map(v => (
              <button key={v} onClick={() => setView(v)} style={{
                padding: "7px 14px", background: view === v ? "var(--bg-subtle)" : "var(--bg-card)",
                border: "none", cursor: "pointer", fontSize: "12px", fontWeight: 600,
                color: view === v ? "var(--text)" : "var(--text-muted)", textTransform: "capitalize",
                fontFamily: "Plus Jakarta Sans, sans-serif",
              }}>
                {v === "kanban" ? "⊞ Board" : "≡ Table"}
              </button>
            ))}
          </div>
          <button style={{ padding: "7px 14px", background: "#059669", border: "none", borderRadius: "8px", fontSize: "13px", fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: "Plus Jakarta Sans, sans-serif" }}>+ Add Lead</button>
        </div>
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", alignItems: "center" }}>
        <span style={{ fontSize: "12px", color: "var(--text-dim)", fontWeight: 600, letterSpacing: "0.05em" }}>FILTER:</span>
        {(["All", "Residential", "Commercial", "Industrial"] as const).map(t => (
          <button key={t} onClick={() => setPropTypeFilter(t)} style={fSA(propTypeFilter === t)}>{t}</button>
        ))}
        <div style={{ width: "1px", height: "20px", background: "var(--border)" }} />
        <select value={agentFilter} onChange={e => setAgentFilter(e.target.value)} style={fS}>
          {agents.map(a => <option key={a} value={a}>{a === "All" ? "All Agents" : a}</option>)}
        </select>
        {(["All", "Small", "Mid", "Large"] as const).map(s => (
          <button key={s} onClick={() => setDealSizeFilter(s)} style={fSA(dealSizeFilter === s)}>
            {s === "All" ? "All Sizes" : s === "Small" ? "< $1M" : s === "Mid" ? "$1M–$3M" : "> $3M"}
          </button>
        ))}
      </div>

      {/* Bulk action bar */}
      {selectedIds.size > 0 && (
        <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px 16px", background: "#0F172A", borderRadius: "8px" }}>
          <span style={{ fontSize: "13px", fontWeight: 600, color: "#fff", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{selectedIds.size} selected</span>
          <div style={{ flex: 1 }} />
          {["Export CSV", "Assign Agent", "Send Notice", "Change Stage"].map(a => (
            <button key={a} style={{ padding: "6px 12px", background: "#1E293B", border: "1px solid #334155", borderRadius: "6px", fontSize: "12px", color: "#CBD5E1", cursor: "pointer" }}>{a}</button>
          ))}
          <button onClick={() => setSelectedIds(new Set())} style={{ padding: "6px 12px", background: "none", border: "1px solid #334155", borderRadius: "6px", fontSize: "12px", color: "#64748B", cursor: "pointer" }}>✕ Clear</button>
        </div>
      )}

      {/* Kanban board */}
      {view === "kanban" && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: "12px", flex: 1, overflowX: "auto", minHeight: 0 }}>
          {STAGES.map(stage => {
            const stageLeads = filtered.filter(l => l.stage === stage);
            const meta = STAGE_META[stage];
            return (
              <div key={stage}
                onDragOver={e => e.preventDefault()}
                onDrop={() => handleDrop(stage)}
                style={{ display: "flex", flexDirection: "column", gap: "8px", minWidth: "200px" }}
              >
                {/* Column header */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 10px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "8px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                    <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: meta.color }} />
                    <span style={{ fontSize: "12px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{stage}</span>
                  </div>
                  <span style={{ fontSize: "11px", fontWeight: 700, padding: "1px 6px", borderRadius: "100px", background: meta.bg, color: meta.color }}>{stageLeads.length}</span>
                </div>
                {/* Lead cards */}
                <div style={{ display: "flex", flexDirection: "column", gap: "8px", flex: 1, overflowY: "auto", paddingBottom: "4px" }}>
                  {stageLeads.map(lead => (
                    <div key={lead.id} draggable
                      onDragStart={() => setDragId(lead.id)}
                      onDragEnd={() => setDragId(null)}
                      style={{
                        background: "var(--bg-card)", border: `1px solid ${dragId === lead.id ? meta.color : "var(--border)"}`,
                        borderRadius: "8px", padding: "12px", cursor: "grab", transition: "all 0.12s",
                        boxShadow: dragId === lead.id ? "var(--shadow-md)" : "var(--shadow)",
                        opacity: dragId === lead.id ? 0.6 : 1,
                      }}
                      onMouseEnter={e => { if (dragId !== lead.id) (e.currentTarget as HTMLElement).style.borderColor = meta.color; }}
                      onMouseLeave={e => { if (dragId !== lead.id) (e.currentTarget as HTMLElement).style.borderColor = "var(--border)"; }}
                    >
                      {/* Top row */}
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "8px" }}>
                        <span style={{ fontSize: "12px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", lineHeight: 1.3 }}>{lead.name}</span>
                        <ScoreBadge score={lead.score} />
                      </div>
                      {/* Property tag */}
                      <div style={{ display: "inline-flex", alignItems: "center", gap: "4px", marginBottom: "10px", padding: "3px 7px", background: "var(--bg-subtle)", borderRadius: "5px" }}>
                        <span style={{ fontSize: "9px" }}>🏢</span>
                        <span style={{ fontSize: "11px", color: "var(--text-muted)", fontWeight: 500, maxWidth: "130px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{lead.property}</span>
                      </div>
                      {/* Value */}
                      <div style={{ fontSize: "15px", fontWeight: 700, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif", marginBottom: "10px" }}>{fmtVal(lead.value)}</div>
                      {/* Footer */}
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                          <div style={{ width: "20px", height: "20px", borderRadius: "6px", background: lead.agentColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "8px", fontWeight: 700, color: "#fff", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{lead.agentInitials}</div>
                          <span style={{ fontSize: "11px", color: "var(--text-muted)" }}>{lead.agent.split(" ")[0]}</span>
                        </div>
                        <span style={{ fontSize: "10px", color: "var(--text-dim)" }}>{lead.lastContacted}</span>
                      </div>
                    </div>
                  ))}
                  {stageLeads.length === 0 && (
                    <div style={{ padding: "20px 12px", textAlign: "center", border: "1px dashed var(--border)", borderRadius: "8px", color: "var(--text-dim)", fontSize: "12px" }}>Drop here</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Table view */}
      {view === "table" && (
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "10px", overflow: "hidden", flex: 1 }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ borderBottom: "1px solid var(--border)" }}>
                <th style={{ padding: "10px 16px", width: "36px" }}>
                  <input type="checkbox" style={{ cursor: "pointer" }}
                    onChange={e => setSelectedIds(e.target.checked ? new Set(filtered.map(l => l.id)) : new Set())}
                    checked={selectedIds.size === filtered.length && filtered.length > 0}
                  />
                </th>
                {["Lead", "Property", "Value", "Score", "Stage", "Agent", "Last Contact"].map(h => (
                  <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: "10px", fontWeight: 700, color: "var(--text-dim)", letterSpacing: "0.06em", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((l, i) => {
                const meta = STAGE_META[l.stage];
                const isSelected = selectedIds.has(l.id);
                return (
                  <tr key={l.id} style={{ borderBottom: i < filtered.length - 1 ? "1px solid var(--border)" : "none", background: isSelected ? "rgba(5,150,105,0.04)" : "transparent", cursor: "pointer", transition: "background 0.12s" }}
                    onMouseEnter={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)"; }}
                    onMouseLeave={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = "transparent"; }}
                  >
                    <td style={{ padding: "10px 16px" }}><input type="checkbox" checked={isSelected} onChange={() => toggleSelect(l.id)} style={{ cursor: "pointer" }} onClick={e => e.stopPropagation()} /></td>
                    <td style={{ padding: "10px 14px" }}>
                      <div style={{ fontSize: "13px", fontWeight: 600, color: "var(--text)", fontFamily: "Plus Jakarta Sans, sans-serif" }}>{l.name}</div>
                      <div style={{ fontSize: "11px", color: "var(--text-dim)", fontFamily: "JetBrains Mono, monospace" }}>{l.id}</div>
                    </td>
                    <td style={{ padding: "10px 14px" }}>
                      <div style={{ fontSize: "12.5px", color: "var(--text-2)" }}>{l.property}</div>
                      <span style={{ fontSize: "10px", padding: "1px 6px", borderRadius: "4px", background: "var(--bg-subtle)", color: "var(--text-muted)", fontWeight: 500 }}>{l.propType}</span>
                    </td>
                    <td style={{ padding: "10px 14px", fontSize: "13px", fontWeight: 700, color: "var(--text)", fontFamily: "JetBrains Mono, monospace" }}>{fmtVal(l.value)}</td>
                    <td style={{ padding: "10px 14px" }}><ScoreBadge score={l.score} /></td>
                    <td style={{ padding: "10px 14px" }}>
                      <span style={{ padding: "3px 8px", borderRadius: "100px", fontSize: "11px", fontWeight: 600, background: meta.bg, color: meta.color, fontFamily: "Plus Jakarta Sans, sans-serif" }}>{l.stage}</span>
                    </td>
                    <td style={{ padding: "10px 14px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                        <div style={{ width: "24px", height: "24px", borderRadius: "6px", background: l.agentColor, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "9px", fontWeight: 700, color: "#fff" }}>{l.agentInitials}</div>
                        <span style={{ fontSize: "12.5px", color: "var(--text-2)" }}>{l.agent}</span>
                      </div>
                    </td>
                    <td style={{ padding: "10px 14px", fontSize: "12px", color: "var(--text-dim)" }}>{l.lastContacted}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
